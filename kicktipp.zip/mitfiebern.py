"""A small TV watchlist with random fan roles, never bets or stake advice."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
from zoneinfo import ZoneInfo
import fcntl
import hashlib
import html
import json
import os
import re
import tempfile
import unicodedata

import requests
import streamlit as st

BERLIN = ZoneInfo('Europe/Berlin')
ROOT = Path(__file__).resolve().parent
STORE = Path(os.environ.get('KICKTIPP_OUTPUT_DIR', str(ROOT/'output')))/'watch_days'
BASE = 'https://site.api.espn.com/apis/site/v2/sports/'
LEAGUES = {
    'soccer/ger.1': ('Bundesliga', '⚽', 120),
    'soccer/ger.2': ('2. Bundesliga', '⚽', 120),
    'soccer/eng.1': ('Premier League', '⚽', 120),
    'soccer/esp.1': ('LaLiga', '⚽', 120),
    'soccer/ita.1': ('Serie A', '⚽', 120),
    'soccer/fra.1': ('Ligue 1', '⚽', 120),
    'football/nfl': ('NFL', '🏈', 210),
    'basketball/nba': ('NBA', '🏀', 150),
    'hockey/nhl': ('NHL', '🏒', 150),
    'tennis/atp': ('ATP', '🎾', 150),
    'tennis/wta': ('WTA', '🎾', 150),
}
SKY = {
    'soccer/eng.1': 'https://www.sky.de/sport/fussball/premier-league/sendeplan',
    'football/nfl': 'https://www.sky.de/sport/nfl/sendeplan',
    'basketball/nba': 'https://www.sky.de/sport/nba/sendeplan',
    'hockey/nhl': 'https://www.sky.de/sport/nhl/sendeplan',
}
TV_GUIDE = 'https://www.sky.de/tvguide'
DAZN_RIGHTS = 'https://dazngroup.com/press-room/dazn-startet-in-die-bundesliga-saison-2026-27-mit-konferenz-sonntagsspielen/'
MONTHS = {s: i+1 for i, s in enumerate(('januar','februar','marz','april','mai','juni','juli','august','september','oktober','november','dezember'))}


def now_berlin():
    return datetime.now(BERLIN)


def watch_day(now):
    # NFL/NBA evenings continue after midnight. Do not discard a running plan.
    return (now.astimezone(BERLIN)-timedelta(hours=5)).date()


def selected_days(values):
    """Canonical safe storage key, independent of selection order."""
    if not isinstance(values,(list,tuple)) or not 1<=len(values)<=3:
        raise ValueError('Bitte ein bis drei Tage auswählen')
    days=sorted(date.fromisoformat(v).isoformat() for v in values)
    if len(set(days))!=len(days): raise ValueError('Doppelte Tage')
    return days


def planning_days(now, values=None):
    if now.tzinfo is None: raise ValueError('Zeitzone fehlt')
    days=selected_days(values if values is not None else [watch_day(now).isoformat()])
    first=watch_day(now); last=now.astimezone(BERLIN).date()+timedelta(days=3)
    if any(not first<=date.fromisoformat(d)<=last for d in days):
        raise ValueError('Bitte höchstens drei Tage im Voraus auswählen')
    return days


def plan_filename(days):
    days=selected_days(days)
    return (days[0] if len(days)==1 else 'group-'+'_'.join(days))+'.json'


def date_label(value, now):
    day=date.fromisoformat(value); offset=(day-now.astimezone(BERLIN).date()).days
    prefix='Heute' if offset==0 else 'Morgen' if offset==1 else 'Laufender Abend' if offset<0 else ('Mo','Di','Mi','Do','Fr','Sa','So')[day.weekday()]
    return prefix+' · '+day.strftime('%d.%m.')


def timestamp(value):
    try:
        dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return dt.astimezone(BERLIN) if dt.tzinfo is not None else None
    except (ValueError, TypeError):
        return None


def normalized(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', str(value)).lower() if not unicodedata.combining(c))
    return re.sub(r'[^a-z0-9]', '', value)


def team_name(value):
    # Explicit aliases only. Never fuzzy-match a broadcast to a different team.
    value = normalized(value)
    aliases = {'fceverton':'everton','fchelsea':'chelsea','fcarsenal':'arsenal','fcfulham':'fulham',
               'fcbrentford':'brentford','afcsunderland':'sunderland','lalakers':'losangeleslakers'}
    return aliases.get(value, value)


class Tables(HTMLParser):
    def __init__(self):
        super().__init__(); self.rows=[]; self.row=None; self.cell=None

    def handle_starttag(self, tag, attrs):
        if tag=='tr': self.row=[]
        elif tag in ('td','th') and self.row is not None: self.cell=[]

    def handle_data(self, data):
        if self.cell is not None: self.cell.append(data)

    def handle_endtag(self, tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(' '.join(' '.join(self.cell).split())); self.cell=None
        elif tag=='tr' and self.row is not None:
            self.rows.append(self.row); self.row=None


def parse_program(text, today):
    parser=Tables(); parser.feed(text); result=[]
    for row in parser.rows:
        if len(row)<2: continue
        match=re.fullmatch(r'(\d{1,2})\.\s+(\w+)(?:\s+(\d{4}))?\s*(?:,|um)\s*(\d{1,2}):(\d{2})\s+Uhr', row[0])
        if not match: continue
        day, month, year, hour, minute=match.groups(); month=MONTHS.get(normalized(month))
        if month is None: continue
        # A yearless guide entry is usable only near the requested date.
        candidates=[]
        for y in ([int(year)] if year else [today.year-1,today.year,today.year+1]):
            try: candidates.append(datetime(y,month,int(day),int(hour),int(minute),tzinfo=BERLIN))
            except ValueError: pass
        if not candidates: continue
        start=min(candidates,key=lambda d:abs((d.date()-today).days))
        if abs((start.date()-today).days)>8: continue
        parts=re.split(r'\s+(?:@|vs\.?|-|–)\s+',row[1])
        if len(parts)!=2 or any(normalized(s) in ('tba','tbd','') for s in parts): continue
        names=frozenset(team_name(v) for v in parts)
        if len(names)!=2: continue
        channel=next((v for v in reversed(row[2:]) if v.startswith('Sky Sport')), 'Sky Sport')
        result.append({'date':start.isoformat(),'teams':sorted(names),'channel':channel})
    return result


def get_public(url, params=None):
    # Fixed official hosts/paths only; no credentials, cookies or paid services.
    with requests.get(url,params=params,timeout=(3,9),stream=True) as response:
        response.raise_for_status(); chunks=[]; length=0
        for chunk in response.iter_content(65536):
            length+=len(chunk)
            if length>6_000_000: raise ValueError('Antwort zu groß')
            chunks.append(chunk)
        return b''.join(chunks).decode('utf-8')


@st.cache_data(ttl=60,show_spinner=False)
def fetch_board(league, day):
    if league not in LEAGUES: raise ValueError('Unbekannte Liga')
    date.fromisoformat(day)
    checked=now_berlin().isoformat()
    try:
        data=json.loads(get_public(BASE+league+'/scoreboard',{'dates':day.replace('-',''),'limit':100}))
        if not isinstance(data.get('events'),list): raise ValueError('Unbekanntes Format')
        return {'ok':True,'events':data['events'],'checked':checked}
    except (requests.RequestException,ValueError,TypeError,KeyError):
        return {'ok':False,'events':[],'checked':checked}


@st.cache_data(ttl=1800,show_spinner=False)
def fetch_program(league, day):
    if league in ('soccer/ger.1','soccer/ger.2'):
        return fetch_rights(day)
    if league not in SKY: return {'ok':False,'rows':[]}
    try:
        return {'ok':True,'rows':parse_program(get_public(SKY[league]),date.fromisoformat(day))}
    except (requests.RequestException,ValueError,TypeError):
        return {'ok':False,'rows':[]}


@st.cache_data(ttl=1800,show_spinner=False)
def fetch_rights(day):
    date.fromisoformat(day); rights={}
    for key,url in [('sky',TV_GUIDE),('dazn',DAZN_RIGHTS)]:
        try:
            text=normalized(html.unescape(re.sub(r'<[^>]+>',' ',get_public(url))))
            if key=='sky' and 'bis2029' in text:
                if 'allebundesligafreitagsundsamstagsspiele' in text: rights['bl_sky']=True
                if 'diekomplette2bundesliga' in text: rights['bl2_sky']=True
            if key=='dazn' and 'saison202627' in text and 'allesonntagsspielelive' in text: rights['bl_dazn']=True
        except (requests.RequestException,ValueError,TypeError): pass
    return {'ok':bool(rights),'rows':[],'rights':rights}


def score_value(value):
    if isinstance(value,dict): value=value.get('value')
    return int(value) if re.fullmatch(r'\d{1,3}',str(value)) else None


def parse_matches(league, events):
    matches=[]
    for event in events:
        competitions=event.get('competitions',[])
        if league.startswith('tennis/'):
            competitions=[c for g in event.get('groupings',[]) if g.get('grouping',{}).get('slug') in ('mens-singles','womens-singles') for c in g.get('competitions',[])]
        for comp in competitions:
            try:
                sides={c['homeAway']:c for c in comp['competitors']}
                if len(comp['competitors'])!=2 or set(sides)!={'home','away'}: continue
                start=timestamp(comp.get('date') or event.get('date'))
                if start is None or comp.get('timeValid') is not True: continue
                status=comp.get('status') or event.get('status') or {}; typ=status.get('type',{})
                state=typ.get('state','unknown'); name=str(typ.get('name','')).upper()
                if any(w in name for w in ('POSTPON','CANCEL','DELAY','SUSPEND','ABANDON','WALKOVER','RETIRE')): state='unknown'
                if state=='post' and typ.get('completed') is not True: state='unknown'
                if state not in ('pre','in','post'): state='unknown'
                people={}; scores={}
                for side, c in sides.items():
                    team=c.get('team') or c.get('athlete') or {}
                    label=team.get('displayName'); identity=str(team.get('id') or c.get('id') or '')
                    if not label or not identity: raise ValueError('Teilnehmer fehlt')
                    people[side]={'id':identity,'name':label,'logo':team.get('logo') or team.get('flag',{}).get('href','')}
                    # Tennis: count sets won from linescores, not games as sets.
                    scores[side]=sum(s.get('winner') is True for s in c.get('linescores',[])) if league.startswith('tennis/') and c.get('linescores') else score_value(c.get('score'))
                    if state=='pre': scores[side]=None
                identity=str(comp.get('id') or '')
                if not identity or people['home']['id']==people['away']['id']: continue
                matches.append({'key':league+':'+identity,'id':identity,'league':league,'date':start.isoformat(),
                    'state':state,'home':people['home'],'away':people['away'],'scores':scores,
                    'clock':str(status.get('displayClock','')),'period':status.get('period'),
                    'tournament':event.get('name') if league.startswith('tennis/') else None})
            except (ValueError,TypeError,KeyError): continue
    # Duplicated conflicting identities must not become two viewing suggestions.
    unique={}; conflict=set()
    for item in matches:
        key=item['key']
        if key in unique and unique[key]!=item: conflict.add(key)
        else: unique[key]=item
    return [v for k,v in unique.items() if k not in conflict]


def broadcast(match, program):
    names=sorted(team_name(match[s]['name']) for s in ('home','away'))
    start=timestamp(match['date'])
    rights=program.get('rights',{})
    if date(2025,7,1)<=start.date()<=date(2029,6,30):
        sky=(match['league']=='soccer/ger.2' and rights.get('bl2_sky')) or (match['league']=='soccer/ger.1' and start.weekday() in (4,5) and rights.get('bl_sky'))
        if sky: return {'label':'Sky · Ligarechte bestätigt','url':TV_GUIDE,'confirmed':True,'basis':'rights'}
    if date(2026,7,1)<=start.date()<=date(2027,6,30) and match['league']=='soccer/ger.1' and start.weekday()==6 and rights.get('bl_dazn'):
        return {'label':'DAZN · Sonntagsrechte bestätigt','url':DAZN_RIGHTS,'confirmed':True,'basis':'rights'}
    rows=[r for r in program.get('rows',[]) if r['teams']==names and timestamp(r['date']).date()==start.date()
          and abs((timestamp(r['date'])-start).total_seconds())<=3600]
    if len(rows)!=1: return None
    return {'label':rows[0]['channel'],'url':SKY[match['league']],'confirmed':True}


def choose_matches(matches, now, limit=4, day=None):
    day=watch_day(now) if day is None else date.fromisoformat(day)
    start_hour=10 if day.weekday()>=4 else 17
    window_start=datetime(day.year,day.month,day.day,start_hour,tzinfo=BERLIN)
    candidates=[]
    for m in matches:
        start=timestamp(m['date'])
        if not start or start.date()!=day or m['state'] not in ('pre','in'): continue
        if not (m.get('tv') or {}).get('confirmed'): continue
        if m['state']=='pre' and (start<now or start.hour<start_hour): continue
        if m['state']=='in' and (start>now or now<window_start or now-start>timedelta(hours=6)): continue
        candidates.append(m)
    chosen=[]
    while candidates and len(chosen)<min(limit,4):
        def rank(m):
            start=timestamp(m['date']); same=sum(c['league']==m['league'] for c in chosen)
            overlap=sum(abs((start-timestamp(c['date'])).total_seconds())<5400 for c in chosen)
            known=all(v is not None for v in m['scores'].values())
            unit=7 if m['league']=='football/nfl' else 8 if m['league']=='basketball/nba' else 1
            close=known and abs(m['scores']['home']-m['scores']['away'])<=unit
            value=(25 if m['state']=='in' else 0)+(8 if close and m['state']=='in' else 0)-same*22-overlap*14
            return (-value,start,m['key'])
        candidates.sort(key=rank); picked=candidates.pop(0)
        if sum(c['league']==picked['league'] for c in chosen)>=2: continue
        chosen.append(picked)
    return sorted(chosen,key=lambda m:(timestamp(m['date']),m['key']))


def make_plan(now, days=None):
    days=planning_days(now,days)
    def collect(key):
        league,day=key
        board=fetch_board(league,day); program=fetch_program(league,day)
        rows=[m for m in parse_matches(league,board['events']) if timestamp(m['date']).date().isoformat()==day]
        for row in rows: row['tv']=broadcast(row,program) if league in SKY or league in ('soccer/ger.1','soccer/ger.2') else None
        return league,day,board['ok'],program['ok'],rows
    keys=[(league,day) for day in days for league in LEAGUES]
    with ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(collect,keys))
    matches=[m for *_,rows in results for m in rows]
    # Round-robin days, then fill remaining places. Still at most four games in
    # total and two per league, never four games for EACH selected date.
    per_day=[choose_matches(matches,now,day=day) for day in days]; picked=[]; seen=set()
    while len(picked)<4:
        added=False
        for rows in per_day:
            eligible=next((m for m in rows if m['key'] not in seen and sum(p['league']==m['league'] for p in picked)<2),None)
            if eligible is None or len(picked)>=4: continue
            picked.append(eligible); seen.add(eligible['key']); added=True
        if not added: break
    picked.sort(key=lambda m:(m['date'],m['key']))
    for m in picked:
        match_day=timestamp(m['date']).date().isoformat()
        bit=hashlib.sha256((match_day+m['key']).encode()).digest()[0]%2
        m['fan']='home' if bit else 'away'
    return {'version':1,'day':days[0],'days':days,'created':now.isoformat(),'matches':picked,
            'coverage':[{'league':l,'day':d,'scores':ok,'program':pok} for l,d,ok,pok,_ in results],
            'without_tv':sum(m['state'] in ('pre','in') and timestamp(m['date']).date().isoformat() in days and not m.get('tv') for m in matches)}


def read_plan(day, folder=None):
    return read_selection([day],folder)


def read_selection(days, folder=None):
    folder=STORE if folder is None else Path(folder)
    try:
        days=selected_days(days); plan=json.loads((folder/plan_filename(days)).read_text())
        if plan['version']!=1 or plan['day']!=days[0] or not 1<=len(plan['matches'])<=4: return None
        if selected_days(plan.get('days',[plan['day']]))!=days: return None
        if len({m['key'] for m in plan['matches']})!=len(plan['matches']): return None
        return plan
    except (OSError,ValueError,TypeError,KeyError): return None


def save_plan(plan, folder=None):
    folder=STORE if folder is None else Path(folder); folder.mkdir(parents=True,exist_ok=True)
    days=selected_days(plan.get('days',[plan['day']]))
    if plan['day']!=days[0]: raise ValueError('Falscher Planbeginn')
    if not plan['matches']: return plan
    with (folder/'.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        existing=read_selection(days,folder)
        if existing: return existing
        fd,name=tempfile.mkstemp(dir=folder,prefix='.watch-',suffix='.tmp')
        try:
            with os.fdopen(fd,'w') as file: json.dump(plan,file,ensure_ascii=False,allow_nan=False)
            os.replace(name,folder/plan_filename(days))
        finally: Path(name).unlink(missing_ok=True)
    return plan


def live_rows(plan):
    # Fetch only selected sports/dates during refresh. Keep original identities,
    # fan roles and all finished games. A failed response never resets a score.
    keys=sorted({(m['league'],timestamp(m['date']).date().isoformat()) for m in plan['matches']})
    def collect(key):
        league,day=key; board=fetch_board(league,day)
        return key,board,{m['key']:m for m in parse_matches(league,board['events'])}
    with ThreadPoolExecutor(max_workers=3) as pool: boards=dict((k,(b,rows)) for k,b,rows in pool.map(collect,keys))
    output=[]
    for saved in plan['matches']:
        board,lookup=boards[(saved['league'],timestamp(saved['date']).date().isoformat())]
        current=lookup.get(saved['key']); row=dict(saved); row['fresh']=False; row['checked']=board['checked']
        if current and all(current[s]['id']==saved[s]['id'] for s in ('home','away')):
            # A provider temporarily dropping the final flag cannot unfinish it.
            if saved['state']!='post' or current['state']=='post':
                row.update(current)
                row['fresh']=True
        output.append(row)
    return output


def row_status(row):
    if not row['fresh']: return 'Stand unbestätigt','neutral'
    if row['state']=='unknown': return 'Verschoben / Status offen','neutral'
    if row['state']=='pre': return 'Demnächst','neutral'
    if row['state']=='post': return ('Endstand fehlt' if any(v is None for v in row['scores'].values()) else 'Beendet'),'neutral'
    values=row['scores']; unit=7 if row['league']=='football/nfl' else 8 if row['league']=='basketball/nba' else 1
    close=all(v is not None for v in values.values()) and abs(values['home']-values['away'])<=unit
    return ('Enges Spiel' if close else 'Live'),'yellow' if close else 'green'


def fan_result(row):
    if not row['fresh'] or row['state']!='post' or any(v is None for v in row['scores'].values()): return None
    diff=row['scores'][row['fan']]-row['scores']['away' if row['fan']=='home' else 'home']
    return 'gewonnen' if diff>0 else 'unentschieden' if diff==0 else 'verloren'


def fan_status(row):
    result=fan_result(row)
    if result: return result.capitalize(),{'gewonnen':'green','verloren':'red','unentschieden':'neutral'}[result]
    if not row['fresh'] or row['state'] in ('unknown','post'): return 'Nicht auswertbar','neutral'
    return ('Noch offen' if row['state']=='in' else 'Offen'),'neutral'


def card(row):
    from sportbet import safe_logo
    esc=lambda v:html.escape(str(v),quote=True)
    label,color=row_status(row); start=timestamp(row['date']); league,icon,_=LEAGUES[row['league']]
    score='– : –' if any(v is None for v in row['scores'].values()) else f"{row['scores']['home']} : {row['scores']['away']}"
    def side(which):
        person=row[which]; logo=safe_logo(person['logo'])
        return ('<img src="'+esc(logo)+'" alt="">' if logo else '')+'<span>'+esc(person['name'])+'</span>'
    clock=''
    if row['state']=='in':
        prefix=('Q'+str(row['period'])+' · ') if row['league'] in ('football/nfl','basketball/nba') else ('Drittel '+str(row['period'])+' · ') if row['league']=='hockey/nhl' else ''
        clock=prefix+row['clock']
    outcome,outcome_color=fan_status(row)
    return '<div class="sb-card"><div class="sb-compact-top"><span>'+icon+' '+esc(league)+' · '+start.strftime('%d.%m. · %H:%M')+'</span><span>'+esc(clock or label)+'</span></div><div class="sb-compact-game"><div class="sb-compact-team">'+side('home')+'</div><strong>'+esc(score)+'</strong><div class="sb-compact-team sb-right">'+side('away')+'</div></div><div class="watch-fan"><small>Zufällige Fanrolle</small><strong>'+esc(row[row['fan']]['name'])+'</strong><span class="sb-status '+outcome_color+'">'+esc(outcome)+'</span></div><div class="watch-footer"><span>'+esc(row['tv']['label'])+'</span><span>'+esc('Sätze' if row['league'].startswith('tennis/') else label)+'</span></div></div>'


@st.fragment(run_every=60)
def render_plan(plan):
    rows=live_rows(plan)
    # Store verified progress only in this session; identity/fan roles remain fixed.
    for row in rows:
        if row['fresh']:
            saved=next(m for m in plan['matches'] if m['key']==row['key'])
            for key in ('state','scores','clock','period'): saved[key]=row[key]
    live=sum(r['fresh'] and r['state']=='in' for r in rows); done=sum(fan_result(r) is not None for r in rows)
    st.markdown(f'<div class="watch-counts"><div><b>{len(rows)}</b><small>im Plan</small></div><div><b>{live}</b><small>jetzt live</small></div><div><b>{done}</b><small>beendet</small></div></div>',unsafe_allow_html=True)
    ordered=sorted(rows,key=lambda r:(0 if r['fresh'] and r['state']=='in' else 2 if r['state']=='post' else 1,0 if row_status(r)[0]=='Enges Spiel' else 1,r['date']))
    for row in ordered: st.markdown(card(row),unsafe_allow_html=True)
    if done:
        results=[fan_result(r) for r in rows]; wins=results.count('gewonnen'); draws=results.count('unentschieden')
        st.markdown('**Dein Tagesrückblick**' if len(plan.get('days',[plan['day']]))==1 else '**Dein Rückblick**')
        st.write(f'{done} von {len(rows)} Spielen beendet. Deine zugelosten Teams: {wins} Siege, {draws} Unentschieden, {results.count("verloren")} Niederlagen.')
        st.caption('Fanrollen sind Zufall, keine Prognosen. Diese Bilanz misst keinen Modellvorteil.')
    st.caption('Spielstände: Abruf jede Minute, solange diese Seite geöffnet ist. Anbieter können verzögert liefern. Stand '+now_berlin().strftime('%H:%M')+' Uhr.')
    if any(not r['fresh'] for r in rows): st.info('Einige Spielstände sind gerade nicht bestätigt. Der letzte bekannte Stand bleibt sichtbar.')


def clear_archive():
    st.session_state.pop('watch_archive_view',None)


def archive_entries():
    entries={}
    for path in STORE.glob('*.json'):
        key=path.stem
        days=key[6:].split('_') if key.startswith('group-') else [key]
        plan=read_selection(days)
        if plan: entries[key]=plan
    return dict(sorted(entries.items(),key=lambda item:item[1]['created'],reverse=True)[:7])


def period_label(plan):
    return ' / '.join(date.fromisoformat(day).strftime('%d.%m.') for day in plan.get('days',[plan['day']]))


def render():
    st.markdown('''<style>.watch-counts{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:20px 0}.watch-counts>div{padding:13px;border:1px solid var(--kt-border);border-radius:13px;background:var(--kt-card)}.watch-counts b{font-size:1.8rem;display:block}.watch-counts small{font-size:.7rem;color:var(--kt-muted)}.watch-fan{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px 8px;align-items:center;font-size:.8rem;margin-top:16px;padding-top:12px;border-top:1px solid var(--kt-border)}.watch-fan small{font-size:.65rem;color:var(--kt-muted)}.watch-fan strong{grid-column:1;overflow-wrap:anywhere}.watch-fan .sb-status{grid-column:2;grid-row:1/3;margin:0}.watch-footer{display:flex;justify-content:space-between;align-items:center;gap:8px;font-size:.67rem;color:var(--kt-muted);margin-top:10px}.watch-footer .sb-status{margin:0}.watch-hero{font-size:.95rem;color:var(--kt-muted);line-height:1.5}</style>''',unsafe_allow_html=True)
    st.markdown('<div class="eyebrow">DEIN SPORTABEND · OHNE GELDEINSATZ</div>',unsafe_allow_html=True)
    st.title('Mitfiebern.')
    st.markdown('<p class="watch-hero">Wähle deine Sporttage.<br>Bis zu vier Spiele – alles live im Blick.</p>',unsafe_allow_html=True)
    now=now_berlin(); first=watch_day(now); last=now.date()+timedelta(days=3)
    options=[(first+timedelta(days=i)).isoformat() for i in range((last-first).days+1)]
    if 'watch_dates' in st.session_state:
        old=st.session_state['watch_dates']; valid=[d for d in old if d in options]
        if valid!=old: st.session_state['watch_dates']=valid or [first.isoformat()]
    dates=st.multiselect('Sporttage · maximal 3',options,default=[first.isoformat()],format_func=lambda v:date_label(v,now),max_selections=3,key='watch_dates',on_change=clear_archive)
    key=tuple(selected_days(dates)) if dates else ()
    plans=st.session_state.setdefault('watch_plans',{})
    legacy=st.session_state.get('watch_plan')
    if legacy and tuple(legacy.get('days',[legacy['day']]))==key: plans.setdefault(key,legacy)
    plan=plans.get(key) or (read_selection(dates) if dates else None)
    clicked=st.button('Auswahl laden / aktualisieren',key='watch_go',type='primary',width='stretch',disabled=not dates)
    if clicked:
        clear_archive()
        if not plan:
            with st.spinner('Spiele und deutsche Übertragungen prüfen …'):
                generated=make_plan(now,dates)
                try: plan=save_plan(generated)
                except OSError:
                    plan=generated; st.caption('Der Plan bleibt in dieser Sitzung; Cloud-Speicherung gerade nicht verfügbar.')
            if not plan['matches']:
                st.session_state['watch_empty']={'key':key,'without_tv':plan['without_tv'],'failed':sum(not r['scores'] for r in plan.get('coverage',[]))}
                plan=None
        if plan:
            plans[key]=plan; st.session_state['watch_plan']=plan
            st.session_state.pop('watch_empty',None)
    displayed=st.session_state.get('watch_archive_view') or plan
    empty=st.session_state.get('watch_empty')
    if displayed:
        archive=st.session_state.get('watch_archive_view')
        st.caption(('Archiv · ' if archive else 'Dein Plan · ')+period_label(displayed)+' · bleibt beim Anpfiff erhalten')
        render_plan(displayed)
    elif empty and empty['key']==key:
        st.info('Für diese Tage gibt es aktuell keine passenden laufenden oder kommenden Spiele mit bestätigter Übertragung in den angebundenen Sendeplänen. Du kannst andere Tage wählen oder später erneut prüfen.')
        st.caption(f"{empty['without_tv']} Partien ohne bestätigte Übertragung · {empty['failed']} Spielplan-Abfragen fehlgeschlagen.")
    else:
        st.caption('Bis zu 3 Tage voraus · insgesamt maximal 4 Spiele · deutsche Uhrzeit')
    with st.expander('Auswahl & Übertragungen'):
        st.write('Alle Anbieter sind als verfügbar vorgemerkt. Einzelne Spiele aus den offiziellen Sky-Sendeplänen für Premier League, NFL, NBA und NHL werden nach Paarung, Datum und Uhrzeit abgeglichen. Für Bundesliga am Freitag/Samstag und 2. Bundesliga werden die aktuell veröffentlichten Sky-Ligarechte geprüft; für Bundesliga am Sonntag die DAZN-Saisonrechte 2026/27. Das ist auf der Karte als Ligarechte gekennzeichnet, kein Einzelprogramm-Abgleich. Die Rechte-Regeln laufen spätestens zum Ende ihres belegten Zeitraums aus. Dein konkretes Abo und die Kommentarsprache sind damit nicht geprüft.')
        st.write('Spielpläne werden außerdem für LaLiga, Serie A, Ligue 1 und ATP/WTA geprüft. Hier fehlen noch automatisch abgeglichene deutsche Einzelübertragungen; diese Partien werden noch nicht als bestätigte TV-Auswahl ausgegeben. RTL+ und MagentaSport sind noch keine automatischen Programmquellen.')
        st.write('Wähle ein bis drei Sporttage, höchstens drei Kalendertage im Voraus. Insgesamt bis zu vier Spiele für die gesamte Auswahl: laufende enge Partien, unterschiedliche Sportarten und zeitlich verteilte Starts werden bevorzugt. Geeignete Spiele werden über die gewählten Tage verteilt, höchstens zwei aus derselben Liga. Mo–Do neue Starts ab 17 Uhr, Fr–So ab 10 Uhr. Gibt es weniger passende Partien, bleibt der Plan kleiner. Keine Gewinnkombination und keine vorhergesagten Endstände.')
        st.write('Ein Sportabend läuft bis 5 Uhr am Folgetag weiter. Dadurch verschwinden laufende US-Spiele nicht um Mitternacht. Neue Partien für die Auswahl müssen im angegebenen Tagesfenster beginnen.')
        st.write('Die Fanrolle wird zufällig vergeben und bleibt für dasselbe Spiel über alle Datumswahlen unverändert. Kein Wettmodell, keine Gewinnchance, keine Einsatzempfehlung. Offen oder Noch offen bedeutet: kein bestätigtes Endergebnis. Gewonnen, Unentschieden oder Verloren bezieht sich nur auf das zugeloste Team nach bestätigtem Spielende und bekanntem Endstand. Bei fehlenden oder unbestätigten Daten: Nicht auswertbar. Keine Buchmacherabrechnung. Es läuft kein ML-Training auf deinem Handy oder Mac.')
        st.write('Der Tagesplan wird als gemeinsame Auswahl dieser App gespeichert, ohne persönliche Eingaben. Er übersteht normale Code-Updates; nach einem Austausch des Cloud-Servers kann er verloren gehen. Spielstände aktualisieren sich nur bei geöffneter Seite; fehlende Daten werden gekennzeichnet.')
        st.markdown('[Sky-Programm](https://www.sky.de/tvguide) · [DAZN-Programm](https://www.dazn.com/de-DE/schedule) · [MagentaSport-Programm](https://www.magentasport.de/programm)')
    entries=archive_entries()
    if entries:
        with st.expander('Gespeicherte Sporttage'):
            selected=st.selectbox('Gespeicherter Plan',list(entries),format_func=lambda k:period_label(entries[k]),key='watch_archive_day')
            if st.button('Diesen Abend ansehen',key='watch_archive_open'):
                st.session_state['watch_archive_view']=entries[selected]; st.rerun()
