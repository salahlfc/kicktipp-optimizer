"""Lightweight Kickbase player-point estimates for the next Bundesliga matchday."""
from __future__ import annotations

import math
import re
import unicodedata
from html import unescape
from html.parser import HTMLParser

import numpy as np
import requests
import streamlit as st

BASE = 'https://api.kbstats.de/api/v1'
OFFICIAL_CLUBS = {
    'augsburg': 'fc-augsburg', 'bayern': 'fc-bayern-munchen', 'bremen': 'sv-werder-bremen',
    'dortmund': 'borussia-dortmund', 'elversberg': 'sv-elversberg', 'frankfurt': 'eintracht-frankfurt',
    'freiburg': 'sc-freiburg', 'gladbach': 'borussia-monchengladbach', 'hamburg': 'hamburger-sv',
    'hoffenheim': 'tsg-hoffenheim', 'koln': '1-fc-koln', 'leipzig': 'rb-leipzig',
    'leverkusen': 'bayer-04-leverkusen', 'mainz': '1-fsv-mainz-05', 'paderborn': 'sc-paderborn-07',
    'schalke': 'fc-schalke-04', 'stuttgart': 'vfb-stuttgart', 'union berlin': '1-fc-union-berlin',
}


class _SquadParser(HTMLParser):
    """Read names and positions from the official Bundesliga club squad page."""
    ROLES = {
        'goalkeeper': 1, 'goalkeepers': 1, 'torhüter': 1, 'torhuter': 1,
        'defender': 2, 'defenders': 2, 'defence': 2, 'defense': 2, 'verteidigung': 2,
        'midfielder': 3, 'midfielders': 3, 'mittelfeld': 3,
        'forward': 4, 'forwards': 4, 'striker': 4, 'strikers': 4, 'angriff': 4,
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.roster = []
        self.role = 0
        self.heading_tag = None
        self.heading_text = []
        self.player_text = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            self.heading_tag, self.heading_text = tag, []
        if tag == 'a' and '/en/player/' in str(attrs.get('href', '')):
            self.player_text = []

    def handle_data(self, data):
        if self.heading_tag:
            self.heading_text.append(data)
        if self.player_text is None:
            heading = ' '.join(data.casefold().split())
            for role, position in self.ROLES.items():
                if heading == role or heading.startswith(role):
                    self.role = position
                    break
        if self.player_text is not None:
            self.player_text.append(data)

    def handle_endtag(self, tag):
        if self.heading_tag == tag:
            heading = ' '.join(' '.join(self.heading_text).casefold().split())
            for role, position in self.ROLES.items():
                if heading == role or heading.startswith(role):
                    self.role = position
                    break
            self.heading_tag, self.heading_text = None, []
        if tag == 'a' and self.player_text is not None:
            name = ' '.join(' '.join(self.player_text).split())
            if name:
                self.roster.append({'name': name[:80], 'position': self.role})
            self.player_text = None


def _club_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    value = re.sub(r'[^a-z0-9 ]', ' ', value)
    value = ' '.join(value.split())
    aliases = {
        'bayern munich': 'bayern', 'fc bayern munchen': 'bayern', 'bayern munchen': 'bayern',
        'bayer leverkusen': 'leverkusen', 'bayer 04 leverkusen': 'leverkusen',
        'borussia dortmund': 'dortmund', 'mgladbach': 'gladbach',
        'borussia monchengladbach': 'gladbach', 'bor monchengladbach': 'gladbach', 'm gladbach': 'gladbach',
        'sv werder bremen': 'bremen', 'werder bremen': 'bremen',
        'tsg hoffenheim': 'hoffenheim', 'tsg 1899 hoffenheim': 'hoffenheim',
        'rb leipzig': 'leipzig', 'rasenballsport leipzig': 'leipzig',
        '1 fc union berlin': 'union berlin', 'union': 'union berlin',
        '1 fc koln': 'koln', 'fc koln': 'koln', 'cologne': 'koln',
        'eintracht frankfurt': 'frankfurt', 'ein frankfurt': 'frankfurt',
        'hamburger sv': 'hamburg', 'hsv': 'hamburg',
        'sc paderborn 07': 'paderborn', 'sv elversberg': 'elversberg',
        'mainz 05': 'mainz', '1 fsv mainz 05': 'mainz', 'fc augsburg': 'augsburg',
        'sc freiburg': 'freiburg', 'vfb stuttgart': 'stuttgart',
        'fc schalke 04': 'schalke', 'schalke 04': 'schalke',
    }
    return aliases.get(value, value)


def _name_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    return ' '.join(re.sub(r'[^a-z0-9 ]', ' ', value).split())


@st.cache_data(ttl=14400, show_spinner=False)
def _load_data():
    """Fetch one cached player pool and team map; never requires Kickbase login."""
    try:
        players_response = requests.get(BASE + '/players', headers={'Accept': 'application/json'}, timeout=(3, 12))
        players_response.raise_for_status()
        players = players_response.json()
        if isinstance(players, dict):
            players = players.get('players', players.get('items', players.get('data', [])))
        # Partial public responses are still useful for filling an incomplete XI
        # and estimating players whose own point history is not available.
        if not isinstance(players, list) or not players:
            return [], {}
        teams_response = requests.get(BASE + '/teams', headers={'Accept': 'application/json'}, timeout=(3, 8))
        teams_response.raise_for_status()
        teams = teams_response.json()
        if isinstance(teams, dict):
            teams = teams.get('teams', teams.get('items', teams.get('data', [])))
        team_names = {str(t.get('id')): _club_key(t.get('name')) for t in teams if isinstance(t, dict)}
        return players, team_names
    except (requests.RequestException, ValueError, TypeError, AttributeError):
        return [], {}


@st.cache_data(ttl=86400, show_spinner=False)
def _official_squad(team):
    """Fallback roster for incomplete player-points feeds; cached once per team/day."""
    slug = OFFICIAL_CLUBS.get(_club_key(team))
    if not slug:
        return []
    try:
        response = requests.get(
            f'https://www.bundesliga.com/en/bundesliga/clubs/{slug}/squad',
            headers={'User-Agent': 'Mozilla/5.0 (compatible; KickTippOptimizer/1.0)'}, timeout=(3, 8),
        )
        if response.status_code != 200 or len(response.content) > 8_000_000:
            return []
        parser = _SquadParser()
        parser.feed(response.text)
        roster = list(parser.roster)
        if len(roster) < 11:
            pattern = re.compile(r'<a\b[^>]*href=["\'][^"\']*/en/player/[^"\']*["\'][^>]*>(.*?)</a>', re.I | re.S)
            seen = {_name_key(row['name']) for row in roster}
            for match in pattern.finditer(response.text):
                name = ' '.join(re.sub(r'<[^>]+>', ' ', unescape(match.group(1))).split())
                if name and _name_key(name) not in seen:
                    roster.append({'name': name[:80], 'position': 0})
                    seen.add(_name_key(name))
        return roster if len(roster) >= 11 else []
    except (requests.RequestException, ValueError, TypeError):
        return []


def _number(value, default=None):
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _start_probability(raw):
    # Kickbase/KBStats enum is best-first: 0 = confirmed, higher = less likely.
    return {0: .99, 1: .93, 2: .80, 3: .62, 4: .40, 5: .20, 6: .06}.get(int(_number(raw, 6)), .45)


def _recent_average(player):
    history = player.get('history') or []
    scores = []
    for item in history:
        if not isinstance(item, dict) or not item.get('hasPlayed'):
            continue
        points = _number(item.get('points'))
        if points is not None:
            scores.append(points)
    if not scores:
        return None, 0
    # API lists the newest matchday first; give recent form more weight.
    weights = np.asarray([0.72 ** i for i in range(len(scores))], dtype=float)
    return float(np.average(scores, weights=weights)), len(scores)


def _pool_indexes(players, team_names):
    by_team_name = {}
    position_scores = {1: [], 2: [], 3: [], 4: []}
    for row in players:
        if not isinstance(row, dict):
            continue
        team = team_names.get(str(row.get('teamId')), '')
        name = _name_key(row.get('name') or f"{row.get('firstName', '')} {row.get('lastName', '')}")
        if not team or not name:
            continue
        by_team_name.setdefault((team, name), []).append(row)
        avg = _number(row.get('averagePoints'))
        played = _number(row.get('gamesPlayed'), 0) or 0
        pos = int(_number(row.get('position'), 0) or 0)
        if avg is not None and played >= 3 and pos in position_scores:
            position_scores[pos].append(avg)
    baselines = {pos: float(np.median(values)) if values else 55.0 for pos, values in position_scores.items()}
    return by_team_name, baselines


def _resolve_player(team, lineup_player, indexes):
    by_team_name, _ = indexes
    team_key = _club_key(team)
    name = str(lineup_player.get('name') or '').strip()
    key = _name_key(name)
    candidates = by_team_name.get((team_key, key), [])
    if len(candidates) == 1:
        return candidates[0]
    # Some lineup feeds abbreviate first names; permit a unique same-team last-name/initial match.
    words = key.split()
    if len(words) == 1:
        surname = [row for (tkey, pname), rows in by_team_name.items()
                   if tkey == team_key and pname.split() and pname.split()[-1] == words[0]
                   for row in rows]
        if len(surname) == 1:
            return surname[0]
    if len(words) >= 2:
        wanted = (words[0][:1], ' '.join(words[1:]))
        short = []
        for (tkey, pname), rows in by_team_name.items():
            pwords = pname.split()
            if tkey == team_key and len(pwords) >= 2 and (pwords[0][:1], ' '.join(pwords[1:])) == wanted:
                short.extend(rows)
        if len(short) == 1:
            return short[0]
    return None


def _player_projection(player, lineup_player, projected, own_lambda, opponent_lambda, position_baselines):
    pos = int(_number(player.get('position'), 0) or 0)
    games = _number(player.get('gamesPlayed'), 0) or 0
    season_avg = _number(player.get('averagePoints'))
    baseline = position_baselines.get(pos, 55.0)
    recent, recent_games = _recent_average(player)
    if season_avg is None:
        base = baseline
    else:
        # Blend the current season with recent matchdays, shrinking short records to the season mean.
        recent_weight = min(.38, recent_games / (recent_games + 6)) if recent is not None else 0.0
        base = (1 - recent_weight) * season_avg + recent_weight * recent
        if games < 4:
            prior_weight = (4 - games) / 4 * .40
            base = (1 - prior_weight) * base + prior_weight * baseline

    kb_start = _start_probability(player.get('startProbability'))
    lineup_start = 1.0 if not projected else .78
    start_prob = kb_start if not projected else .55 * lineup_start + .45 * kb_start
    if not projected:
        start_prob = 1.0
    avg_minutes = None
    total_seconds = _number(player.get('totalPlaytimeS'))
    if total_seconds and games > 0:
        avg_minutes = total_seconds / 60 / games
    expected_minutes = start_prob * 82 + (1 - start_prob) * 18
    minute_factor = float(np.clip(expected_minutes / avg_minutes, .38, 1.18)) if avg_minutes and avg_minutes > 0 else .74 + .26 * start_prob

    # Small matchup adjustment from the app's expected goals; player history remains the main signal.
    attacking = pos in (3, 4)
    matchup_delta = (own_lambda - 1.35) if attacking else (1.35 - opponent_lambda)
    matchup_factor = float(np.clip(1 + .045 * matchup_delta, .92, 1.08))
    expected = max(0.0, base * minute_factor * matchup_factor)
    spread = _number(player.get('pointsStdDev'), 0) or 0
    spread = max(spread, 22.0 if games < 4 else 0.0)
    interval = max(15.0, .72 * spread * math.sqrt(max(.4, minute_factor)))
    return {
        **lineup_player,
        'kb_player_name': str(player.get('name') or '').strip()[:80],
        'kb_expected_points': round(expected),
        'kb_points_low': round(max(0, expected - interval)),
        'kb_points_high': round(expected + interval),
        'kb_start_probability': round(start_prob * 100),
        'kb_history_average': round(season_avg) if season_avg is not None else None,
        'kb_recent_average': round(recent) if recent is not None else None,
        'kb_matchday_count': int(games),
        'kb_position': pos,
    }


def _formation_counts(value):
    counts = [int(x) for x in re.findall(r'\d+', str(value or ''))]
    return counts if len(counts) in (3, 4) and sum(counts) == 10 else [4, 3, 3]


def _candidate_rank(player):
    start = _start_probability(player.get('startProbability'))
    minutes = _number(player.get('totalPlaytimeS'), 0) or 0
    points = _number(player.get('averagePoints'), 0) or 0
    return (start, minutes, points)


def _expand_joined_names(team, lineup, by_team_name):
    """Split a feed entry only when every token uniquely identifies a squad player."""
    expanded = []
    team_key = _club_key(team)
    for item in lineup:
        if not isinstance(item, dict) or _resolve_player(team, item, (by_team_name, {})):
            expanded.append(item)
            continue
        words = _name_key(item.get('name')).split()
        if len(words) < 2 or len(words) > 3:
            expanded.append(item)
            continue
        matches = []
        for word in words:
            found = {}
            for (candidate_team, candidate_name), rows in by_team_name.items():
                parts = candidate_name.split()
                if candidate_team == team_key and parts and parts[-1] == word:
                    for row in rows:
                        key = _name_key(row.get('name'))
                        if key:
                            found[key] = row
            if len(found) != 1:
                matches = []
                break
            matches.append(next(iter(found.values())))
        if len(matches) == len(words) and len({_name_key(row.get('name')) for row in matches}) == len(matches):
            for row in matches:
                player = dict(item)
                player['name'] = str(row.get('name') or '')
                position = int(_number(row.get('position'), 0) or 0)
                if position in (1, 2, 3, 4):
                    player['position'] = {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}[position]
                    player['kb_position'] = position
                expanded.append(player)
        else:
            expanded.append(item)
    return expanded


def _line_group(position, formation, mid_counts):
    if position == 1:
        return -1
    if position == 2:
        return 0
    if position == 4:
        return len(formation) - 1
    if position == 3:
        for index, capacity in enumerate(formation[1:-1], start=1):
            if mid_counts[index] < capacity:
                mid_counts[index] += 1
                return index
        return max(1, len(formation) - 2)
    return -1


def add_kickbase_estimates(prediction):
    """Estimate points and complete short lineups from the public Kickbase player pool."""
    players, team_names = _load_data()
    indexed = _pool_indexes(players, team_names)
    context = prediction.get('team_context') or {}
    lineup_data = context.get('lineups') or {}
    projected = bool(lineup_data.get('is_projected'))
    sides = (
        ('home', prediction.get('home', ''), float(prediction.get('lambda_home', 1.35)), float(prediction.get('lambda_away', 1.35))),
        ('away', prediction.get('away', ''), float(prediction.get('lambda_away', 1.35)), float(prediction.get('lambda_home', 1.35))),
    )
    by_team_name, baselines = indexed
    for side, team, own_lambda, opponent_lambda in sides:
        side_data = lineup_data.setdefault(side, {})
        current = _expand_joined_names(team, side_data.get('starting') or [], by_team_name)
        formation = _formation_counts(side_data.get('formation'))
        wanted = {1: 1, 2: formation[0], 3: sum(formation[1:-1]), 4: formation[-1]}
        absences = (context.get('absences_by_team') or {}).get(side) or []
        unavailable = {
            _name_key(item.get('name')) for item in absences
            if isinstance(item, dict)
            and any(flag in str(item.get('status') or '').casefold() for flag in ('ausfall', 'out', 'injured', 'suspended'))
        }
        estimated = []
        used = set()
        existing_by_position = {pos: 0 for pos in wanted}
        for lineup_player in current:
            matched = _resolve_player(team, lineup_player, indexed)
            if matched is None:
                estimated.append(dict(lineup_player))
                source_pos = int(_number(lineup_player.get('kb_position'), 0) or 0)
                if source_pos not in wanted:
                    role = str(lineup_player.get('position') or '').casefold()
                    source_pos = (1 if any(x in role for x in ('keeper', 'goalkeeper', 'torwart')) else
                                  2 if any(x in role for x in ('defend', 'verteidig')) else
                                  4 if any(x in role for x in ('forward', 'attacker', 'stürm')) else
                                  3 if any(x in role for x in ('midfield', 'mittelfeld')) else 0)
                if source_pos in wanted:
                    existing_by_position[source_pos] += 1
                name = _name_key(lineup_player.get('name'))
                if name:
                    used.add(name)
                continue
            pos = int(_number(matched.get('position'), 0) or 0)
            projected_player = _player_projection(matched, lineup_player, projected, own_lambda, opponent_lambda, baselines)
            if not projected_player.get('position') and pos in (1, 2, 3, 4):
                projected_player['position'] = {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}[pos]
            estimated.append(projected_player)
            if pos in wanted:
                existing_by_position[pos] += 1
            used.add(_name_key(matched.get('name')))

        roster = [row for rows in by_team_name.values() for row in rows
                  if isinstance(row, dict) and team_names.get(str(row.get('teamId')), '') == _club_key(team)
                  and _name_key(row.get('name')) not in used
                  and _name_key(row.get('name')) not in unavailable]
        roster.sort(key=_candidate_rank, reverse=True)
        selected = []
        for pos in (1, 2, 3, 4):
            missing = max(0, wanted[pos] - existing_by_position[pos])
            candidates = [row for row in roster if int(_number(row.get('position'), 0) or 0) == pos]
            for row in candidates[:missing]:
                selected.append((row, pos))
                used.add(_name_key(row.get('name')))
                roster.remove(row)

        # When the points feed has no remaining candidate, use the official
        # current squad as a name-and-position-only fallback instead of leaving
        # the XI blank. Known absences and already listed players stay excluded.
        if len(estimated) + len(selected) < 11:
            official = _official_squad(team)
            official_candidates = [row for row in official
                                   if _name_key(row.get('name')) not in used
                                   and _name_key(row.get('name')) not in unavailable]
            remaining_places = max(0, 11 - len(estimated) - len(selected))
            for pos in (1, 2, 3, 4):
                if remaining_places <= 0:
                    break
                missing = max(0, wanted[pos] - existing_by_position[pos]
                              - sum(1 for row, selected_pos in selected if selected_pos == pos))
                missing = min(missing, remaining_places)
                candidates = [row for row in official_candidates if row['position'] == pos]
                for candidate in candidates[:missing]:
                    name = candidate['name']
                    matched = _resolve_player(team, {'name': name}, indexed)
                    if matched:
                        projected_player = _player_projection(matched, {
                            'name': name,
                            'position': {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}[pos],
                            'image': '',
                        }, True, own_lambda, opponent_lambda, baselines)
                    else:
                        projected_player = {
                            'name': name,
                            'position': {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}[pos],
                            'kb_position': pos,
                            'image': '',
                        }
                    selected.append(({'_projected': projected_player}, pos))
                    remaining_places -= 1
                    used.add(_name_key(name))
                    official_candidates = [row for row in official_candidates
                                           if _name_key(row.get('name')) != _name_key(name)]
            while remaining_places > 0 and official_candidates:
                candidate = official_candidates.pop(0)
                name = candidate['name']
                matched = _resolve_player(team, {'name': name}, indexed)
                pos = int(_number(matched.get('position'), 0) or 0) if matched else int(candidate.get('position') or 0)
                if pos not in wanted or existing_by_position.get(pos, 0) >= wanted.get(pos, 0):
                    pos = next((role for role in (2, 3, 4)
                                if existing_by_position.get(role, 0) < wanted.get(role, 0)), 3)
                line = {
                    'name': name,
                    'position': {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}[pos],
                    'kb_position': pos,
                    'image': '',
                }
                projected_player = (_player_projection(matched, line, True, own_lambda, opponent_lambda, baselines)
                                    if matched else line)
                selected.append(({'_projected': projected_player}, pos))
                remaining_places -= 1
                existing_by_position[pos] = existing_by_position.get(pos, 0) + 1
                used.add(_name_key(name))

        # If a team roster lacks a listed position, still make the best remaining XI guess.
        while len(estimated) + len(selected) < 11 and roster:
            row = roster.pop(0)
            pos = int(_number(row.get('position'), 0) or 0)
            if pos not in wanted:
                pos = next((candidate for candidate in (2, 3, 4) if existing_by_position[candidate] < wanted[candidate]), 3)
            selected.append((row, pos))
            existing_by_position[pos] = existing_by_position.get(pos, 0) + 1

        mid_counts = {index: 0 for index in range(1, len(formation) - 1)}
        for player in estimated:
            if int(_number(player.get('kb_position'), 0) or 0) == 3:
                group = int(_number(player.get('line_group'), -1))
                if group in mid_counts:
                    mid_counts[group] += 1
        for player in estimated:
            if int(_number(player.get('kb_position'), 0) or 0) == 3 and int(_number(player.get('line_group'), -1)) not in mid_counts:
                player['line_group'] = _line_group(3, formation, mid_counts)
            elif int(_number(player.get('kb_position'), 0) or 0) in (1, 2, 4) and player.get('line_group') is None:
                pos = int(player['kb_position'])
                player['line_group'] = {1: -1, 2: 0, 4: len(formation) - 1}[pos]
        for row, pos in selected:
            if '_projected' in row:
                line = dict(row['_projected'])
                line['line_group'] = _line_group(pos, formation, mid_counts)
                estimated.append(line)
                continue
            line = {'name': str(row.get('name') or '').strip()[:80], 'position': {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}.get(pos, ''), 'image': ''}
            line['line_group'] = _line_group(pos, formation, mid_counts)
            matched_line = _player_projection(row, line, True, own_lambda, opponent_lambda, baselines)
            estimated.append(matched_line)
        if selected:
            # The added places are estimates even if the source listing was confirmed but incomplete.
            side_data['formation'] = '-'.join(map(str, formation))
            lineup_data['is_projected'] = True
        side_data['starting'] = estimated[:11]
    context['lineups'] = lineup_data
    prediction['team_context'] = context
    return prediction
