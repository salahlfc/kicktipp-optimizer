"""Lightweight Kickbase player-point estimates for the next Bundesliga matchday."""
from __future__ import annotations

import math
import re
import unicodedata

import numpy as np
import requests
import streamlit as st

BASE = 'https://api.kbstats.de/api/v1'


def _club_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    value = re.sub(r'[^a-z0-9 ]', ' ', value)
    value = ' '.join(value.split())
    aliases = {
        'bayern munich': 'bayern', 'fc bayern munchen': 'bayern', 'bayern munchen': 'bayern',
        'bayer leverkusen': 'leverkusen', 'bayer 04 leverkusen': 'leverkusen',
        'borussia dortmund': 'dortmund', 'mgladbach': 'gladbach',
        'borussia monchengladbach': 'gladbach', 'bor monchengladbach': 'gladbach', 'm gladbach': 'gladbach',
        'sv werder bremen': 'bremen', 'werder bremen': 'bremen',
        'tsg hoffenheim': 'hoffenheim', 'tsg 1899 hoffenheim': 'hoffenheim',
        'rb leipzig': 'leipzig', 'rasenballsport leipzig': 'leipzig',
        '1 fc union berlin': 'union berlin', 'union': 'union berlin',
        '1 fc koln': 'koln', 'fc koln': 'koln', 'cologne': 'koln',
        'eintracht frankfurt': 'frankfurt', 'ein frankfurt': 'frankfurt',
        'hamburger sv': 'hamburg', 'hsv': 'hamburg',
        'sc paderborn 07': 'paderborn', 'sv elversberg': 'elversberg',
        'mainz 05': 'mainz', '1 fsv mainz 05': 'mainz', 'fc augsburg': 'augsburg',
        'sc freiburg': 'freiburg', 'vfb stuttgart': 'stuttgart',
        'fc schalke 04': 'schalke', 'schalke 04': 'schalke',
    }
    return aliases.get(value, value)


def _name_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    return ' '.join(re.sub(r'[^a-z0-9 ]', ' ', value).split())


@st.cache_data(ttl=14400, show_spinner=False)
def _load_data():
    """Fetch one cached player pool and team map; never requires Kickbase login."""
    try:
        players_response = requests.get(BASE + '/players', headers={'Accept': 'application/json'}, timeout=(3, 12))
        players_response.raise_for_status()
        players = players_response.json()
        if isinstance(players, dict):
            players = players.get('players', players.get('items', players.get('data', [])))
        if not isinstance(players, list) or len(players) < 100:
            return [], {}
        teams_response = requests.get(BASE + '/teams', headers={'Accept': 'application/json'}, timeout=(3, 8))
        teams_response.raise_for_status()
        teams = teams_response.json()
        if isinstance(teams, dict):
            teams = teams.get('teams', teams.get('items', teams.get('data', [])))
        team_names = {str(t.get('id')): _club_key(t.get('name')) for t in teams if isinstance(t, dict)}
        return players, team_names
    except (requests.RequestException, ValueError, TypeError, AttributeError):
        return [], {}


def _number(value, default=None):
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def _start_probability(raw):
    # Kickbase/KBStats enum is best-first: 0 = confirmed, higher = less likely.
    return {0: .99, 1: .93, 2: .80, 3: .62, 4: .40, 5: .20, 6: .06}.get(int(_number(raw, 6)), .45)


def _recent_average(player):
    history = player.get('history') or []
    scores = []
    for item in history:
        if not isinstance(item, dict) or not item.get('hasPlayed'):
            continue
        points = _number(item.get('points'))
        if points is not None:
            scores.append(points)
    if not scores:
        return None, 0
    # API lists the newest matchday first; give recent form more weight.
    weights = np.asarray([0.72 ** i for i in range(len(scores))], dtype=float)
    return float(np.average(scores, weights=weights)), len(scores)


def _pool_indexes(players, team_names):
    by_team_name = {}
    position_scores = {1: [], 2: [], 3: [], 4: []}
    for row in players:
        if not isinstance(row, dict):
            continue
        team = team_names.get(str(row.get('teamId')), '')
        name = _name_key(row.get('name') or f"{row.get('firstName', '')} {row.get('lastName', '')}")
        if not team or not name:
            continue
        by_team_name.setdefault((team, name), []).append(row)
        avg = _number(row.get('averagePoints'))
        played = _number(row.get('gamesPlayed'), 0) or 0
        pos = int(_number(row.get('position'), 0) or 0)
        if avg is not None and played >= 3 and pos in position_scores:
            position_scores[pos].append(avg)
    baselines = {pos: float(np.median(values)) if values else 55.0 for pos, values in position_scores.items()}
    return by_team_name, baselines


def _resolve_player(team, lineup_player, indexes):
    by_team_name, _ = indexes
    team_key = _club_key(team)
    name = str(lineup_player.get('name') or '').strip()
    key = _name_key(name)
    candidates = by_team_name.get((team_key, key), [])
    if len(candidates) == 1:
        return candidates[0]
    # Some lineup feeds abbreviate first names; permit a unique same-team last-name/initial match.
    words = key.split()
    if len(words) == 1:
        surname = [row for (tkey, pname), rows in by_team_name.items()
                   if tkey == team_key and pname.split() and pname.split()[-1] == words[0]
                   for row in rows]
        if len(surname) == 1:
            return surname[0]
    if len(words) >= 2:
        wanted = (words[0][:1], ' '.join(words[1:]))
        short = []
        for (tkey, pname), rows in by_team_name.items():
            pwords = pname.split()
            if tkey == team_key and len(pwords) >= 2 and (pwords[0][:1], ' '.join(pwords[1:])) == wanted:
                short.extend(rows)
        if len(short) == 1:
            return short[0]
    return None


def _player_projection(player, lineup_player, projected, own_lambda, opponent_lambda, position_baselines):
    pos = int(_number(player.get('position'), 0) or 0)
    games = _number(player.get('gamesPlayed'), 0) or 0
    season_avg = _number(player.get('averagePoints'))
    baseline = position_baselines.get(pos, 55.0)
    recent, recent_games = _recent_average(player)
    if season_avg is None:
        base = baseline
    else:
        # Blend the current season with recent matchdays, shrinking short records to the season mean.
        recent_weight = min(.38, recent_games / (recent_games + 6)) if recent is not None else 0.0
        base = (1 - recent_weight) * season_avg + recent_weight * recent
        if games < 4:
            prior_weight = (4 - games) / 4 * .40
            base = (1 - prior_weight) * base + prior_weight * baseline

    kb_start = _start_probability(player.get('startProbability'))
    lineup_start = 1.0 if not projected else .78
    start_prob = kb_start if not projected else .55 * lineup_start + .45 * kb_start
    if not projected:
        start_prob = 1.0
    avg_minutes = None
    total_seconds = _number(player.get('totalPlaytimeS'))
    if total_seconds and games > 0:
        avg_minutes = total_seconds / 60 / games
    expected_minutes = start_prob * 82 + (1 - start_prob) * 18
    minute_factor = float(np.clip(expected_minutes / avg_minutes, .38, 1.18)) if avg_minutes and avg_minutes > 0 else .74 + .26 * start_prob

    # Small matchup adjustment from the app's expected goals; player history remains the main signal.
    attacking = pos in (3, 4)
    matchup_delta = (own_lambda - 1.35) if attacking else (1.35 - opponent_lambda)
    matchup_factor = float(np.clip(1 + .045 * matchup_delta, .92, 1.08))
    expected = max(0.0, base * minute_factor * matchup_factor)
    spread = _number(player.get('pointsStdDev'), 0) or 0
    spread = max(spread, 22.0 if games < 4 else 0.0)
    interval = max(15.0, .72 * spread * math.sqrt(max(.4, minute_factor)))
    return {
        **lineup_player,
        'kb_player_name': str(player.get('name') or '').strip()[:80],
        'kb_expected_points': round(expected),
        'kb_points_low': round(max(0, expected - interval)),
        'kb_points_high': round(expected + interval),
        'kb_start_probability': round(start_prob * 100),
        'kb_history_average': round(season_avg) if season_avg is not None else None,
        'kb_recent_average': round(recent) if recent is not None else None,
        'kb_matchday_count': int(games),
        'kb_position': pos,
    }


def _formation_counts(value):
    counts = [int(x) for x in re.findall(r'\d+', str(value or ''))]
    return counts if len(counts) in (3, 4) and sum(counts) == 10 else [4, 3, 3]


def _candidate_rank(player):
    start = _start_probability(player.get('startProbability'))
    minutes = _number(player.get('totalPlaytimeS'), 0) or 0
    points = _number(player.get('averagePoints'), 0) or 0
    return (start, minutes, points)


def _line_group(position, formation, mid_counts):
    if position == 1:
        return -1
    if position == 2:
        return 0
    if position == 4:
        return len(formation) - 1
    if position == 3:
        for index, capacity in enumerate(formation[1:-1], start=1):
            if mid_counts[index] < capacity:
                mid_counts[index] += 1
                return index
        return max(1, len(formation) - 2)
    return -1


def add_kickbase_estimates(prediction):
    """Estimate points and complete short lineups from the public Kickbase player pool."""
    players, team_names = _load_data()
    if not players:
        return prediction
    indexed = _pool_indexes(players, team_names)
    context = prediction.get('team_context') or {}
    lineup_data = context.get('lineups') or {}
    projected = bool(lineup_data.get('is_projected'))
    sides = (
        ('home', prediction.get('home', ''), float(prediction.get('lambda_home', 1.35)), float(prediction.get('lambda_away', 1.35))),
        ('away', prediction.get('away', ''), float(prediction.get('lambda_away', 1.35)), float(prediction.get('lambda_home', 1.35))),
    )
    by_team_name, baselines = indexed
    for side, team, own_lambda, opponent_lambda in sides:
        side_data = lineup_data.setdefault(side, {})
        current = side_data.get('starting') or []
        formation = _formation_counts(side_data.get('formation'))
        wanted = {1: 1, 2: formation[0], 3: sum(formation[1:-1]), 4: formation[-1]}
        absences = (context.get('absences_by_team') or {}).get(side) or []
        unavailable = {
            _name_key(item.get('name')) for item in absences
            if isinstance(item, dict)
            and any(flag in str(item.get('status') or '').casefold() for flag in ('ausfall', 'out', 'injured', 'suspended'))
        }
        estimated = []
        used = set()
        existing_by_position = {pos: 0 for pos in wanted}
        for lineup_player in current:
            matched = _resolve_player(team, lineup_player, indexed)
            if matched is None:
                estimated.append(dict(lineup_player))
                source_pos = int(_number(lineup_player.get('kb_position'), 0) or 0)
                if source_pos not in wanted:
                    role = str(lineup_player.get('position') or '').casefold()
                    source_pos = (1 if any(x in role for x in ('keeper', 'goalkeeper', 'torwart')) else
                                  2 if any(x in role for x in ('defend', 'verteidig')) else
                                  4 if any(x in role for x in ('forward', 'attacker', 'stürm')) else
                                  3 if any(x in role for x in ('midfield', 'mittelfeld')) else 0)
                if source_pos in wanted:
                    existing_by_position[source_pos] += 1
                name = _name_key(lineup_player.get('name'))
                if name:
                    used.add(name)
                continue
            estimated.append(_player_projection(matched, lineup_player, projected, own_lambda, opponent_lambda, baselines))
            pos = int(_number(matched.get('position'), 0) or 0)
            if pos in wanted:
                existing_by_position[pos] += 1
            used.add(_name_key(matched.get('name')))

        roster = [row for rows in by_team_name.values() for row in rows
                  if isinstance(row, dict) and team_names.get(str(row.get('teamId')), '') == _club_key(team)
                  and _name_key(row.get('name')) not in used
                  and _name_key(row.get('name')) not in unavailable]
        roster.sort(key=_candidate_rank, reverse=True)
        selected = []
        for pos in (1, 2, 3, 4):
            missing = max(0, wanted[pos] - existing_by_position[pos])
            candidates = [row for row in roster if int(_number(row.get('position'), 0) or 0) == pos]
            for row in candidates[:missing]:
                selected.append((row, pos))
                used.add(_name_key(row.get('name')))
                roster.remove(row)

        # If a team roster lacks a listed position, still make the best remaining XI guess.
        while len(estimated) + len(selected) < 11 and roster:
            row = roster.pop(0)
            pos = int(_number(row.get('position'), 0) or 0)
            if pos not in wanted:
                pos = next((candidate for candidate in (2, 3, 4) if existing_by_position[candidate] < wanted[candidate]), 3)
            selected.append((row, pos))
            existing_by_position[pos] = existing_by_position.get(pos, 0) + 1

        mid_counts = {index: 0 for index in range(1, len(formation) - 1)}
        for player in estimated:
            if int(_number(player.get('kb_position'), 0) or 0) == 3:
                group = int(_number(player.get('line_group'), -1) or -1)
                if group in mid_counts:
                    mid_counts[group] += 1
        for row, pos in selected:
            line = {'name': str(row.get('name') or '').strip()[:80], 'position': {1: 'Goalkeeper', 2: 'Defender', 3: 'Midfielder', 4: 'Forward'}.get(pos, ''), 'image': ''}
            line['line_group'] = _line_group(pos, formation, mid_counts)
            matched_line = _player_projection(row, line, True, own_lambda, opponent_lambda, baselines)
            estimated.append(matched_line)
        if selected:
            # The added places are estimates even if the source listing was confirmed but incomplete.
            side_data['formation'] = '-'.join(map(str, formation))
            lineup_data['is_projected'] = True
        side_data['starting'] = estimated[:11]
    context['lineups'] = lineup_data
    prediction['team_context'] = context
    return prediction
