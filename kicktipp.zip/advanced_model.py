"""Weekly out-of-time model comparison, probability ensemble and audit metadata.

Selection uses 2021/22 through 2024/25 proper score loss only. The separate 2025/26
report is computed after the configuration is frozen; it never chooses weights.
"""
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from engine import (ModelSpec, make_candidates, predictions, optimal_from_matrix,
                    add_rest, metric, bootstrap_difference, score, MAX_GOALS)


def signature(games):
    digest=hashlib.sha256(pd.util.hash_pandas_object(games[['date','home','away','hg','ag']],index=False).values.tobytes())
    for file in ('engine.py','advanced_model.py'):
        digest.update((Path(__file__).parent/file).read_bytes())
    return digest.hexdigest()


def evaluate_matrices(games,seasons,spec,constant=False):
    records=[];matrices=[]
    test=games[games.season.isin(seasons)]
    for _,chunk in test.groupby(test.date.dt.to_period('W-THU'),sort=True):
        cutoff=chunk.date.min()
        train=games[(games.date<cutoff)&(games.date>=cutoff-pd.Timedelta(days=spec.lookback))]
        if len(train)<120:raise ValueError('Insufficient pre-cutoff training data')
        train,fixtures=add_rest(train,chunk[['date','home','away']])
        preds=predictions(train,fixtures,spec,mode='constant' if constant else 'model')
        for p,r in zip(preds,chunk.itertuples()):
            matrices.append(p['_p_matrix'])
            records.append({'date':str(r.date.date()),'home':r.home,'away':r.away,'hg':int(r.hg),'ag':int(r.ag)})
    return pd.DataFrame(records),np.asarray(matrices)


def scored(records,matrices):
    rows=[]
    for r,matrix in zip(records.to_dict('records'),matrices):
        o=optimal_from_matrix(matrix);tip=tuple(map(int,o['tip'].split(':')))
        h,a=r['hg'],r['ag'];actual=0 if h>a else 1 if h==a else 2
        probs=[o['prob_home'],o['prob_draw'],o['prob_away']]
        rows.append({**r,'tip':o['tip'],'points':score(tip,(h,a)),'exact':int(tip==(h,a)),
                     'score_log_loss':-float(np.log(max(matrix[h,a] if h<=MAX_GOALS and a<=MAX_GOALS else 1e-12,1e-12))),
                     'brier_1x2':float(sum((v-int(k==actual))**2 for k,v in enumerate(probs)))})
    return pd.DataFrame(rows)


def deep_candidates():
    candidates=make_candidates(False)
    candidates += [ModelSpec(half_life=h,ridge=r) for h in (90,270,540) for r in (1.,4.,16.)]
    candidates += [ModelSpec(half_life=h,ridge=r,family='dc') for h in (180,730) for r in (2.,8.)]
    candidates += [ModelSpec(half_life=h,ridge=4.,family='nb',dispersion=d) for h in (180,730) for d in (3.,12.)]
    candidates += [ModelSpec(family='elo',elo_k=k,elo_beta=b) for k,b in [(16,.35),(16,.55),(24,.55),(40,.35),(40,.55)]]
    return list(dict.fromkeys(candidates))


def calibrate(matrices,temperature):
    if not np.isfinite(temperature) or temperature<=0:raise ValueError('Invalid temperature')
    if temperature==1.:return np.asarray(matrices).copy()
    p=np.asarray(matrices,dtype=float)
    log=np.log(np.clip(p,1e-300,None))/temperature
    log-=np.max(log,axis=(-2,-1),keepdims=True)
    adjusted=np.exp(log)
    return adjusted/adjusted.sum(axis=(-2,-1),keepdims=True)


def choose_model(games,outdir,progress=lambda s:None,force=False):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    key=signature(games);path=outdir/'advanced_report.json'
    try:
        cached=json.loads(path.read_text())
        if not force and cached['signature']==key:return cached['bundle'],cached
    except (OSError,ValueError,KeyError):pass
    # Validate every season before treating it as historical evidence.
    for y in range(2015,2026):
        part=games[games.season==y]
        if len(part)!=306 or len(set(part.home)|set(part.away))!=18 or part.duplicated(['home','away']).any():
            raise ValueError(f'Saison {y}/{y+1}: ungültiger historischer Spielplan')
        for t in set(part.home)|set(part.away):
            if ((part.home==t).sum(),(part.away==t).sum())!=(17,17):raise ValueError('Unbalanced historical schedule')
    candidates=deep_candidates();runs=[];cache={};reference=None;rejected=[]
    validation_seasons=[2021,2022,2023,2024]
    expected_validation=306*len(validation_seasons)
    for i,spec in enumerate(candidates):
        progress(f'Historische Prüfung {i+1}/{len(candidates)} · {spec.family} · wöchentlicher Wissensstand …')
        try:
            records,matrices=evaluate_matrices(games,validation_seasons,spec)
            if len(records)!=expected_validation:raise ValueError('Missing validation forecasts')
            if reference is not None and not records.equals(reference):raise ValueError('Misaligned validation fixtures')
            evaluation=scored(records,matrices)
        except (ValueError,RuntimeError) as exc:
            rejected.append({'index':i,'spec':asdict(spec),'reason':str(exc)})
            progress(f'Modellvariante {i+1} verworfen: {exc}')
            continue
        reference=records
        runs.append({'index':i,**asdict(spec),**metric(evaluation)})
        cache[i]=matrices
    if not runs:raise RuntimeError('No valid model candidates')
    ranking=sorted(runs,key=lambda r:(r['score_log_loss'],r['brier_1x2'],r['index']))
    top=ranking[:3];best=top[0]
    blend=np.mean([cache[r['index']] for r in top],axis=0)
    ensemble_metrics=metric(scored(reference,blend))
    # Calibrate only the best single model and the top-3 ensemble, using past validation.
    pipelines=[]
    for kind,selected,matrices in [('single',[best],cache[best['index']]),('ensemble',top,blend)]:
        for temperature in (.85,1.,1.15):
            trial=scored(reference,calibrate(matrices,temperature))
            pipelines.append({'kind':kind,'selected':selected,'temperature':temperature,'metrics':metric(trial)})
    winner=min(pipelines,key=lambda p:(p['metrics']['score_log_loss'],p['metrics']['brier_1x2'],abs(p['temperature']-1),p['kind']))
    chosen=winner['selected']
    bundle={'kind':winner['kind'],'temperature':winner['temperature'],
            'models':[{'spec':asdict(candidates[r['index']]),'weight':1/len(chosen)} for r in chosen]}
    val=scored(reference,calibrate(np.mean([cache[r['index']] for r in chosen],axis=0),bundle['temperature']))
    progress('Konfiguration fixiert · separaten Testzeitraum 2025/26 auswerten …')
    held_records=None;held_matrices=[]
    for item in bundle['models']:
        records,matrices=evaluate_matrices(games,[2025],ModelSpec(**item['spec']))
        if held_records is not None and not records.equals(held_records):raise ValueError('Misaligned test fixtures')
        held_records=records;held_matrices.append(item['weight']*matrices)
    holdout=scored(held_records,calibrate(np.sum(held_matrices,axis=0),bundle['temperature']))
    b_records,b_matrices=evaluate_matrices(games,[2025],ModelSpec(),constant=True)
    baseline=scored(b_records,b_matrices)
    if len(holdout)!=306 or len(baseline)!=306:raise ValueError('Incomplete separate test season')
    report={'signature':key,'calculated_at_utc':datetime.now(timezone.utc).isoformat(),
            'bundle':bundle,'selection_criterion':'weekly 2021-2024 validation score log loss; compare best single/top-3 ensemble with temperatures 0.85/1/1.15',
            'validation_chosen':metric(val),'holdout_chosen':metric(holdout),'holdout_baseline':metric(baseline),
            'holdout_delta_ci':bootstrap_difference(holdout,baseline),'candidates':ranking,
            'ensemble_validation':ensemble_metrics,'single_validation':{k:best[k] for k in ('score_log_loss','points_per_game')},
            'candidate_count':len(candidates),'rejected_candidates':rejected,
            'validation_seasons':validation_seasons,
            'calibration_comparison':[{'kind':p['kind'],'temperature':p['temperature'],**p['metrics']} for p in pipelines],
            'validation_games':expected_validation,'test_games':306,'frequency':'W-THU','dataset_games':len(games)}
    holdout.to_csv(outdir/'advanced_test_predictions.csv',index=False)
    pd.DataFrame(ranking).to_csv(outdir/'advanced_validation_comparison.csv',index=False)
    from leanflow import atomic_json
    atomic_json(path,report)
    return bundle,report


def ensemble_predictions(games,fixtures,bundle):
    parts=[]
    for item in bundle['models']:
        spec=ModelSpec(**item['spec'])
        train,dated=add_rest(games,fixtures)
        preds=predictions(train,dated,spec)
        parts.append((item,preds))
    result=[]
    for i in range(len(fixtures)):
        matrix=sum(item['weight']*preds[i]['_p_matrix'] for item,preds in parts)
        matrix=calibrate(matrix,bundle.get('temperature',1.))
        base=parts[0][1][i];o=optimal_from_matrix(matrix)
        components=[{'weight':item['weight'],'spec':item['spec'],'lambda_home':preds[i]['lambda_home'],
                     'lambda_away':preds[i]['lambda_away'],'rho':preds[i]['rho']} for item,preds in parts]
        result.append({'date':base['date'],'home':base['home'],'away':base['away'],**o,
                       'lambda_home':float(np.dot(np.arange(len(matrix)),matrix.sum(axis=1))),
                       'lambda_away':float(np.dot(np.arange(len(matrix)),matrix.sum(axis=0))),
                       'rho':base['rho'],'family':parts[0][0]['spec']['family'],
                       'dispersion':parts[0][0]['spec']['dispersion'],'components':components,
                       'probability_matrix':matrix.tolist()})
    return result
