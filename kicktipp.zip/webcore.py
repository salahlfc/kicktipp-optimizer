"""Side-effect-light service layer for the local Streamlit Bundesliga optimizer."""
from __future__ import annotations
import csv
import io
import json
import math
import shutil
import zipfile
from pathlib import Path
from datetime import date
import numpy as np
import pandas as pd

from engine import (MAX_GOALS, MAX_TIP, SCORE_GRID, TIPS, ModelSpec, canonical,
                    score_prob_matrix, optimal_from_matrix, score, load_data, normalize,
                    validate_select, load_fixtures, predictions, predict_rates,
                    add_rest, season_of, sensitivity)
from openfootball_import import convert_one
from import_archive import import_zip

ROOT = Path(__file__).resolve().parent
DATA = ROOT/'data'
OUTPUT = ROOT/'output'
DATA.mkdir(parents=True,exist_ok=True)
OUTPUT.mkdir(parents=True,exist_ok=True)

LABELS = {'hsv':'HSV', 'gladbach':'Gladbach', 'dortmund':'Dortmund', 'elversberg':'Elversberg',
 'leipzig':'RB Leipzig', 'augsburg':'Augsburg', 'mainz':'Mainz', 'bayern':'Bayern',
 'paderborn':'Paderborn', 'frankfurt':'Frankfurt', 'stuttgart':'Stuttgart',
 'bremen':'Werder Bremen', 'koln':'Köln', 'leverkusen':'Leverkusen',
 'freiburg':'Freiburg', 'union':'Union Berlin','hoffenheim':'Hoffenheim','schalke':'Schalke',
 'wolfsburg':'Wolfsburg', 'bochum':'Bochum','heidenheim':'Heidenheim',
 'st pauli':'St. Pauli'}

def pretty(s):
    return LABELS.get(canonical(s),str(s))

def read_status():
    years={}
    for year in range(2015,2027):
        p=DATA/f'D1_{year}_{year+1}.csv'
        if p.exists():
            try:
                df=pd.read_csv(p)
                years[year]={'count':int(len(df)),'ok':len(df)==306 if year<=2025 else bool(len(df)),
                             'file':p.name}
            except Exception as exc:
                years[year]={'count':0,'ok':False,'error':str(exc)}
    report=OUTPUT/'report.json'
    return {'years':years,'n_hist':sum(1 for y in range(2015,2026) if years.get(y,{}).get('ok')),
            'report':json.loads(report.read_text(encoding='utf-8')) if report.exists() else None,
            'has_spec':(OUTPUT/'chosen_spec.json').exists()}

def download_archive_years(first=2015,last=2025,progress=None):
    summary=[]
    for idx,y in enumerate(range(first,last+1)):
        target=DATA/f'D1_{y}_{y+1}.csv'
        if target.exists() and len(pd.read_csv(target))==306:
            summary.append(f'{y}/{str(y+1)[-2:]}: vorhanden (306)')
        else:
            try:
                path,n=convert_one(y,DATA,download=True,strict=True)
                summary.append(f'{y}/{str(y+1)[-2:]}: geladen ({n})')
            except Exception as e:
                summary.append(f'{y}/{str(y+1)[-2:]}: FEHLER: {e}')
        if progress: progress((idx+1)/(last-first+1),summary[-1])
    return summary

def import_archive_bytes(content:bytes, first=2015, last=2025):
    """ZIP from github, convert strictly before writing completed seasons."""
    tmp=ROOT/'.upload_history.zip'
    if len(content)>60_000_000: raise ValueError('ZIP zu groß (>60 MB).')
    try:
        tmp.write_bytes(content)
        return import_zip(tmp,DATA,first=first,last=last)
    finally:
        tmp.unlink(missing_ok=True)

def import_results_csv(content:bytes, year:int):
    """Import authenticated dated results; strict schema/date/unique-fixture checks.

    Caller is responsible for verifying the real-world authenticity of the file.
    """
    if len(content)>8_000_000: raise ValueError('CSV zu groß.')
    raw=pd.read_csv(io.BytesIO(content),encoding='utf-8-sig')
    if not {'date','home','away','hg','ag'}.issubset(raw) and not {'Date','HomeTeam','AwayTeam','FTHG','FTAG'}.issubset(raw):
        raise ValueError('CSV braucht date,home,away,hg,ag (oder Date,HomeTeam,AwayTeam,FTHG,FTAG).')
    df=normalize(raw,source='uploaded CSV')
    if len(df)!=len(raw):
        raise ValueError(f'Ungültige Zeilen: {len(raw)} hochgeladen, {len(df)} erkannt. Nichts gespeichert.')
    if df.duplicated(['date','home','away']).any():
        raise ValueError('Doppelte Begegnungen mit demselben Datum.')
    if (df.season!=year).any():
        raise ValueError(f'Nicht alle Datumswerte gehören zur Saison {year}/{year+1}.')
    if (df.date.dt.date>date.today()).any():
        raise ValueError('CSV enthält bereits Ergebnisse in der Zukunft. Diese dürfen nicht als bekannt gespeichert werden.')
    if year<=2025:
        if len(df)!=306:raise ValueError('Historische abgeschlossene Bundesliga-Saison braucht genau 306 Ergebnisse.')
        clubs=pd.concat([df.home,df.away]).value_counts()
        if len(clubs)!=18 or (clubs!=34).any():raise ValueError('Ungültiger historischer Spielplan (18 Vereine × 34 Spiele erforderlich).')
    target=DATA/f'D1_{year}_{year+1}.csv'
    tmp=target.with_suffix('.tmp')
    df[['date','home','away','hg','ag']].to_csv(tmp,index=False)
    tmp.replace(target)
    return target,len(df),str(df.date.min().date()),str(df.date.max().date())

def import_fixtures_csv(content:bytes):
    if len(content)>2_000_000: raise ValueError('CSV zu groß.')
    raw=pd.read_csv(io.BytesIO(content),encoding='utf-8-sig')
    if not {'date','home','away'}.issubset(raw):raise ValueError('CSV braucht date,home,away.')
    if len(raw)<1 or len(raw)>100:raise ValueError('Bitte 1 bis 100 Partien hochladen.')
    from engine import parse_dates
    valid=parse_dates(raw.date)
    if valid.isna().any():raise ValueError('Ungültige Datumsangabe.')
    if raw.duplicated(['date','home','away']).any():raise ValueError('Doppelte Begegnungen.')
    target=DATA/'fixtures_custom.csv'
    target.write_bytes(content)
    return len(raw),target

def manual_optimize(lh,la,family='poisson',rho=0,dispersion=8):
    p=score_prob_matrix(lh,la,family=family,rho=rho,dispersion=dispersion)
    answer=optimal_from_matrix(p)
    result_tip=tuple(map(int,answer['tip'].split(':')))
    prob_tendency=answer['prob_home'] if result_tip[0]>result_tip[1] else answer['prob_draw'] if result_tip[0]==result_tip[1] else answer['prob_away']
    outcome=[]
    for i in range(min(MAX_GOALS+1,7)):
        for j in range(min(MAX_GOALS+1,7)):
            outcome.append({'Ergebnis':f'{i}:{j}','Wahrscheinlichkeit':float(p[i,j]),'Wahrscheinlichkeit (%)':round(float(p[i,j]*100),2)})
    outcome=sorted(outcome,key=lambda r:r['Wahrscheinlichkeit'],reverse=True)
    return {'prediction':answer,'p_tendency':prob_tendency,'matrix':p,'top_scores':outcome[:12]}

def forecast_from_engine(asof:date,fixtures_file:Path=None,min_matches=1):
    specfile=OUTPUT/'chosen_spec.json'
    if not specfile.exists():raise RuntimeError('Bitte zuerst einen erfolgreichen echten historischen Backtest durchführen.')
    fixtures_file=fixtures_file or DATA/'fixtures_st9_2026.csv'
    games,missing=load_data(DATA,first=2015,last=2026,allow_download=False)
    games,_=add_rest(games)
    dates=load_fixtures(fixtures_file)
    dates=dates[dates.date>=pd.Timestamp(asof)].copy()
    if dates.empty: raise RuntimeError('Keine anstehenden Begegnungen ab dem gewählten Stichtag.')
    past=games[games.date <pd.Timestamp(asof)].copy()
    cur_year=season_of(pd.Timestamp(asof))
    n_recent=int((past.season==cur_year).sum())
    if n_recent<min_matches:
        raise RuntimeError(f'Nur {n_recent} datierte Ergebnisse der aktuellen Saison vorhanden. '
                           'Aktuelle Saison via CSV mit ECHTEN Spieldaten importieren; die 72 Matchday-Zeilen haben bewusst keine erfundenen Datumswerte.')
    if len(past)<120: raise RuntimeError('Mindestens 120 frühere Ergebnisse erforderlich.')
    spec=ModelSpec(**json.loads(specfile.read_text(encoding='utf-8')))
    results=[]
    # Freeze information at the requested analysis cutoff. Never consume games that happen after asof.
    past= past[past.date<pd.Timestamp(asof)].copy()
    # don't refit with future same-week results; all predictions share an identical as-of cutoff
    for _,chunk in dates.groupby('date'):
        prediction=predictions(past,chunk,spec)
        for p in prediction:
            p.pop('_p_matrix')
            p['sensitivity_10pct']=sensitivity(p['lambda_home'],p['lambda_away'],spec,p['rho'])
            tip_h,tip_a=map(int,p['tip'].split(':'))
            p['prob_tendency']=(p['prob_home'] if tip_h>tip_a else p['prob_draw'] if tip_h==tip_a else p['prob_away'])
            results.append(p)
    # Store timestamped as-of snapshot; do not silently overwrite older saved copies.
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT/f'predictions_asof_{asof.isoformat()}.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    return results,n_recent,missing

def run_validation(fast=False):
    games,missing=load_data(DATA,first=2015,last=2025,allow_download=False)
    return validate_select(games,OUTPUT,fast=fast)

def result_frame(results):
    rows=[]
    for p in results:
        stable=p.get('sensitivity_10pct',{}).get('same_in_9_scenarios',None)
        tendency=p.get('prob_tendency')
        if tendency is None:
            h,a=map(int,p['tip'].split(':'))
            tendency=p['prob_home'] if h>a else p['prob_draw'] if h==a else p['prob_away']
        rows.append({'Datum':p['date'],'Partie':f"{pretty(p['home'])} – {pretty(p['away'])}",
                     'Tipp':p['tip'],'Ampel': '🟢' if tendency>=.60 else '🟡' if tendency>=.45 else '🔴',
                     'Tendenz %':round(100*tendency,1),'Exakt %':round(100*p['prob_exact'],1),
                     'EP':round(p['ep'],3),'P Heim %':round(100*p['prob_home'],1),
                     'P Remis %':round(100*p['prob_draw'],1),'P Auswärts %':round(100*p['prob_away'],1),
                     'Tipp stabil ±10%': 'Ja' if stable else 'Nein' if stable is not None else 'n. v.',
                     'Nächster Tipp': (p.get('alternatives') or [{}])[1].get('tip','–') if len(p.get('alternatives') or [])>1 else '–'})
    return pd.DataFrame(rows)


def parse_current_season_schedule(raw:str, season:int=2026):
    """Extract fixture dates (including unplayed games) from OpenFootball 'home v away' format.

    Result/date association is grounded in the public schedule; no guessed dates.
    """
    import re
    from datetime import datetime
    from openfootball_import import DATE
    rows=[]; current=None
    for line in raw.splitlines():
        m=DATE.match(line)
        if m:
            month=datetime.strptime(m.group(1),'%b').month
            yy=int(m.group(3)) if m.group(3) else (season if month>=7 else season+1)
            current=date(yy,month,int(m.group(2)))
            continue
        if current is None or not re.search(r'\s+v\s+',line):continue
        line=re.sub(r'^\s*\d{1,2}:\d{2}\s+','',line).strip()
        spl=re.split(r'\s+v\s+',line,maxsplit=1)
        if len(spl)!=2:continue
        home,rest=spl
        score=re.match(r'^(.+?)\s+(\d+)-(\d+)(?:\s+\(\d+-\d+\))?\s*$',rest)
        if score:
            away=score.group(1).strip();hg=int(score.group(2));ag=int(score.group(3))
        else:
            away=rest.strip();hg=ag=None
        if not home or not away:continue
        rows.append({'date':current.isoformat(),'home':canonical(home),'away':canonical(away),
                     'hg_online':hg,'ag_online':ag})
    result=pd.DataFrame(rows)
    if result.empty:raise ValueError('Keine Begegnungen im öffentlich abgerufenen Spielplan erkannt.')
    if result.duplicated(['home','away']).any():raise ValueError('Öffentlicher Spielplan enthält doppelte Heim-/Auswärts-Kombinationen.')
    if (result.home==result.away).any():raise ValueError('Ungültige Paarung im Spielplan.')
    return result


def reconcile_current_2026(raw:str, asof:date=None):
    """Create current-season results using grounded schedule dates and bundled known scores.

    This function does NOT invent results, dates or substitute future fixtures.
    It validates a fixture join against both the bundled scores and online scores.
    """
    asof=asof or date.today()
    schedule=parse_current_season_schedule(raw,2026)
    supplied=pd.read_csv(DATA/'md1_8_results_no_dates.csv')
    for col in ('home','away'):supplied[col]=supplied[col].map(canonical)
    if len(supplied)!=72 or supplied.duplicated(['home','away']).any():
        raise ValueError('Gebündelter 72-Spiele-Snapshot ist nicht intakt.')
    merged=supplied.merge(schedule,on=['home','away'],how='left',validate='one_to_one',indicator=True)
    if (merged['_merge']!='both').any():
        missing=merged.loc[merged['_merge']!='both',['home','away']].to_dict('records')
        raise ValueError(f'Spielplan stimmt nicht mit den 72 Resultaten überein: {missing[:5]}')
    merged['date']=pd.to_datetime(merged['date'])
    if (merged.date.dt.date>asof).any():
        raise ValueError('Historischer 72-Spiele-Snapshot enthält ein Ergebnis nach dem Analyse-Stichtag.')
    has_online=merged.hg_online.notna()
    inconsistent=(has_online & ((merged.hg!=merged.hg_online)|(merged.ag!=merged.ag_online)))
    if inconsistent.any():
        raise ValueError('Online-Spielplan und Ergebnis-Snapshot widersprechen sich. Keine Speicherung.')
    seen=supplied[['home','away']].copy()
    newer=schedule[schedule.hg_online.notna()].merge(seen,on=['home','away'],how='left',indicator=True)
    newer=newer[(newer['_merge']=='left_only') & (pd.to_datetime(newer.date).dt.date<=asof)].copy()
    recent=newer[['date','home','away','hg_online','ag_online']].rename(columns={'hg_online':'hg','ag_online':'ag'})
    out=merged[['date','home','away','hg','ag']].copy()
    if len(recent):
        recent['date']=pd.to_datetime(recent.date)
        recent[['hg','ag']]=recent[['hg','ag']].astype(int)
        out=pd.concat([out,recent],ignore_index=True)
    out=out.sort_values(['date','home','away']).reset_index(drop=True)
    if out.duplicated(['home','away']).any():raise ValueError('Doppelte Paarung erkannt.')
    if (out.date.dt.date>asof).any():raise ValueError('Zukünftiges Ergebnis erkannt.')
    target=DATA/'D1_2026_2027.csv'
    if target.exists():
        existing=normalize(pd.read_csv(target),source='current season')
        # preserve every previously imported real result; never overwrite conflicting entries
        compared=existing.merge(out,on=['home','away'],how='inner',suffixes=('_old','_new'))
        if ((compared.hg_old!=compared.hg_new)|(compared.ag_old!=compared.ag_new)|(compared.date_old!=compared.date_new)).any():
            raise ValueError('Widerspruch zu lokal gespeicherten Daten. Bitte manuell prüfen; nichts überschrieben.')
        extra=existing.merge(out[['home','away']],on=['home','away'],how='left',indicator=True)
        extra=extra[extra['_merge']=='left_only'][['date','home','away','hg','ag']]
        out=pd.concat([out,extra],ignore_index=True).sort_values(['date','home','away'])
    temp=target.with_suffix('.tmp')
    out.to_csv(temp,index=False)
    temp.replace(target)
    return len(out),str(pd.to_datetime(out.date).max().date()),target


def download_and_reconcile_current_2026():
    import requests
    url='https://raw.githubusercontent.com/openfootball/deutschland/master/2026-27/1-bundesliga.txt'
    res=requests.get(url,timeout=30,headers={'User-Agent':'Kicktipp-Optimizer/1.0'})
    res.raise_for_status()
    content=res.content.decode('utf-8-sig')
    return reconcile_current_2026(content)
