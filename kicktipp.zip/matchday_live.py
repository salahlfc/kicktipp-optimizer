"""Read-only matchday display and retrospective checks of frozen forecasts."""
from copy import deepcopy
import pandas as pd
from weekly_review import archive_runs, assess_round, local_time


def matchday_result(folder, season, rnd, schedule, now):
    """Keep the last eligible PRE-kickoff forecast for each fixture across runs."""
    runs = archive_runs(folder, season, rnd, now)
    if not runs:
        return None
    review = assess_round(schedule, folder, season, rnd, now, persist=False)
    result = deepcopy(runs[-1][1])
    predictions = []
    for row in review['rows']:
        if row['saved_at'] is None:
            continue
        for created, run in reversed(runs):
            if created.isoformat() != row['saved_at']:
                continue
            for p in run['results']:
                if (p['home'], p['away'], p['tip']) == (row['home'], row['away'], row['tip']):
                    predictions.append(dict(p, forecast_created_at=created.isoformat()))
                    break
            break
    result['results'] = predictions
    return result if predictions else None


def match_state(prediction, schedule, now):
    now = local_time(now)
    game = next((r for r in (schedule or []) if (r['home'], r['away']) == (prediction['home'], prediction['away'])), None)
    if game is None:
        return {'label': 'Spielstand nicht verfügbar', 'score': '–', 'finished': False, 'game': None}
    started = local_time(game['kickoff']) <= now
    if started and game['finished']:
        return {'label': 'Abpfiff', 'score': f"{game['hg']}:{game['ag']}", 'finished': True, 'game': game}
    if not started:
        return {'label': 'Noch nicht angepfiffen', 'score': '–', 'finished': False, 'game': game}
    if game.get('live_hg') is not None and game.get('live_ag') is not None:
        return {'label': 'Live · Zwischenstand', 'score': f"{game['live_hg']}:{game['live_ag']}", 'finished': False, 'game': game}
    return {'label': 'Live-Daten noch nicht gemeldet', 'score': '–', 'finished': False, 'game': game}


def match_assessment(row, game=None):
    if not row or row.get('points') is None:
        return None
    h, a = map(int, row['actual'].split(':'))
    th, ta = map(int, row['tip'].split(':'))
    if row['exact']:
        verdict = 'Spielrichtung und Spielstand getroffen. Der prognostizierte Spielausgang und die Torverteilung sind eingetreten.'
    elif row['tendency_correct']:
        verdict = 'Die Spielrichtung war richtig, die Torverteilung wich ab.'
    else:
        verdict = 'Die erwartete Spielrichtung hat sich nicht bestätigt.'
    if game and game.get('ht_hg') is not None and game.get('ht_ag') is not None:
        verdict += f" Zur Pause stand es {game['ht_hg']}:{game['ht_ag']}, am Ende {h}:{a}."
    predicted_goals = row.get('lambda_home', th) + row.get('lambda_away', ta)
    diff = h + a - predicted_goals
    if diff >= 1.5:
        signal = 'Die Partie war deutlich torreicher als erwartet. Prüfpunkt: Werden offene Spiele dieser Teams wiederholt zu vorsichtig eingeschätzt?'
    elif diff <= -1.5:
        signal = 'Die Partie blieb deutlich torärmer als erwartet. Prüfpunkt: Werden bei diesen Teams wiederholt zu viele Tore erwartet?'
    elif not row['tendency_correct']:
        signal = 'Prüfpunkt: Wiederholt sich die Fehleinschätzung der Spielrichtung bei diesen Teams? Ein einzelner Ausreißer reicht nicht für eine neue Gewichtung.'
    else:
        signal = 'Die Spielrichtung wurde hier gut eingeschätzt. Das ist ein positiver Prüfpunkt; erst viele Spiele zeigen, ob die Chancen zuverlässig kalibriert sind.'
    return {'verdict': verdict, 'signal': signal,
            'points': f"Tipp {row['tip']} → Ergebnis {row['actual']} · {row['points']} Punkte · Expected Points {row['ep']:.2f} · Abweichung {row['delta_points']:+.2f}",
            'limit': 'Aus dem Spielstand allein lassen sich Verletzungen, Rotation, Chancenverwertung oder Platzverweise nicht als Ursache belegen. Das ist eine Auswertung, keine automatische Änderung der Modellgewichte.'}


def round_assessment(review):
    if not review or not review['evaluated']:
        return None
    complete = review['games'] > 0 and review['finished'] == review['games']
    n = review['evaluated']
    delta = review['delta_points']
    direction = 'über' if delta >= 0 else 'unter'
    text = (f"{n} vorab gespeicherte Tipps ausgewertet: {review['exact']} exakte Treffer und "
            f"{review['tendency_correct']} richtige Tendenzen insgesamt. {review['points']} Punkte gegenüber "
            f"{review['expected_points']:.2f} Expected Points – {abs(delta):.2f} Punkte {direction} dem Erwartungswert.")
    rows = [r for r in review['rows'] if r.get('points') is not None]
    high = sum(int(r['actual'].split(':')[0]) + int(r['actual'].split(':')[1]) - r.get('lambda_home',0) - r.get('lambda_away',0) >= 1.5 for r in rows if 'lambda_home' in r)
    signal = (f"{high} der bewerteten Spiele waren deutlich torreicher als vorab erwartet. Diese Abweichung wird als Prüfpunkt festgehalten." if high else
              'Treffer und Fehlprognosen werden gemeinsam geprüft; eine gute Punktausbeute allein beweist noch keine verlässlichen Wahrscheinlichkeiten.')
    if not complete:
        text += f" Der Spieltag läuft noch ({review['finished']}/{review['games']} beendet); das ist eine Zwischenbilanz."
    elif n < review['games']:
        text += ' Für Spiele ohne gültig gespeicherten Vorabtipp wird keine Modellleistung nachträglich erfunden.'
    return {'title': 'Gesamteinschätzung · Spieltag abgeschlossen' if complete else 'Gesamteinschätzung · Zwischenbilanz',
            'text': text, 'signal': signal,
            'learning': 'Abgeschlossene Ergebnisse fließen bei einer späteren Optimierung nach dem geltenden Datenstichtag ins Training ein. Diese Rückschau verändert die ursprünglichen Tipps nicht. Modellgewichte werden durch sie nicht automatisch nachjustiert.'}


def render_round_assessment(st, review):
    assessment = round_assessment(review)
    if not assessment:
        return
    st.subheader(assessment['title'])
    st.write(assessment['text'])
    st.markdown('**Was wir mitnehmen:** ' + assessment['signal'])
    st.caption(assessment['learning'])


def render_match_assessment(st, row, game=None):
    assessment = match_assessment(row, game)
    if not assessment:
        return
    st.markdown('**Einschätzung nach Abpfiff:** ' + assessment['verdict'])
    st.caption(assessment['points'])
    st.markdown('**Was wir daraus mitnehmen:** ' + assessment['signal'])
    st.caption(assessment['limit'])
