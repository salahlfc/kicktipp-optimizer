#!/usr/bin/env python3
"""Bundesliga 4/2/1 scoreline predictor: leak-safe, reproducible and backtestable.

Runs on public-domain OpenFootball historical results and existing D1 CSVs.
No odds, tipster picks or future results enter model training.
"""
from __future__ import annotations
import argparse
import hashlib
from datetime import datetime, timezone
import json
import math
import re
import unicodedata
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
from scipy.optimize import minimize, minimize_scalar
from scipy.stats import poisson, nbinom

MAX_GOALS = 13
MAX_TIP = MAX_GOALS
SOURCE = 'https://raw.githubusercontent.com/openfootball/deutschland/master/{season}/1-bundesliga.txt'
ALIASES = {
    '1 fc heidenheim 1846':'heidenheim','vfl bochum 1848':'bochum',
    '1 fc nurnberg':'nurnberg','hertha bsc':'hertha',
    'fc ingolstadt 04':'ingolstadt','hannover 96':'hannover',
    'spvgg greuther furth 1903':'furth','greuther furth':'furth',
    'sv darmstadt 98':'darmstadt','holstein kiel':'kiel',
    'bayern munich':'bayern', 'fc bayern munchen':'bayern', 'bayern munchen':'bayern',
    'borussia dortmund':'dortmund', 'b dortmund':'dortmund',
    'bayer leverkusen':'leverkusen', 'bayer 04 leverkusen':'leverkusen',
    'vfb stuttgart':'stuttgart','fc augsburg':'augsburg',
    'sc freiburg':'freiburg','sport club freiburg':'freiburg',
    'mgladbach':'gladbach','borussia monchengladbach':'gladbach',
    'bor monchengladbach':'gladbach','borussia m gladbach':'gladbach',
    'werder bremen':'bremen','sv werder bremen':'bremen',
    'hoffenheim':'hoffenheim','tsg hoffenheim':'hoffenheim',
    'tsg 1899 hoffenheim':'hoffenheim','1899 hoffenheim':'hoffenheim',
    'schalke 04':'schalke','fc schalke 04':'schalke',
    'rb leipzig':'leipzig','rasenballsport leipzig':'leipzig',
    'union berlin':'union','1 fc union berlin':'union',
    'fc koln':'koln','1 fc koln':'koln','cologne':'koln',
    'ein frankfurt':'frankfurt','eintracht frankfurt':'frankfurt',
    'hamburg':'hsv','hamburger sv':'hsv',
    'paderborn':'paderborn','sc paderborn 07':'paderborn',
    'elversberg':'elversberg','sv elversberg':'elversberg',
    'mainz':'mainz','mainz 05':'mainz','1 fsv mainz 05':'mainz',
    'wolfsburg':'wolfsburg','vfl wolfsburg':'wolfsburg',
    'bochum':'bochum','vfl bochum':'bochum',
    'heidenheim':'heidenheim','1 fc heidenheim':'heidenheim',
    'hertha':'hertha','hertha berlin':'hertha',
    'fortuna dusseldorf':'dusseldorf','dusseldorf':'dusseldorf',
    'arminia bielefeld':'bielefeld','bielefeld':'bielefeld',
    'nurnberg':'nurnberg','fc nurnberg':'nurnberg',
    'bayern munchen':'bayern','bor m gladbach':'gladbach',
    'sv 07 elversberg':'elversberg','sc paderborn 07':'paderborn',
    'st pauli':'st pauli','fc st pauli':'st pauli',
    'fc st pauli 1910':'st pauli',
}

def canonical(text):
    t=unicodedata.normalize('NFKD',str(text)).encode('ascii','ignore').decode().lower()
    t=re.sub(r'[^a-z0-9 ]',' ',t)
    t=' '.join(t.split())
    return ALIASES.get(t,t)

def season_of(d):
    d=pd.Timestamp(d)
    return int(d.year if d.month>=7 else d.year-1)

def parse_dates(values):
    """Treat YYYY-MM-DD as ISO and DD/MM/YYYY as European dates; avoid locale swaps."""
    series=pd.Series(values).astype(str).str.strip()
    result=pd.Series(pd.NaT,index=series.index,dtype='datetime64[ns]')
    iso=series.str.match(r'^\d{4}-\d{2}-\d{2}$')
    result.loc[iso]=pd.to_datetime(series.loc[iso],format='%Y-%m-%d',errors='coerce')
    if (~iso).any():
        result.loc[~iso]=pd.to_datetime(series.loc[~iso],dayfirst=True,errors='coerce',format='mixed')
    return result.dt.normalize()


def score(tip, result):
    a,b=tip;x,y=result
    if (a,b)==(x,y): return 4
    if a-b==x-y: return 2
    if np.sign(a-b)==np.sign(x-y): return 1
    return 0

TIPS=[(i,j) for i in range(MAX_TIP+1) for j in range(MAX_TIP+1)]
OUTCOMES=[(i,j) for i in range(MAX_GOALS+1) for j in range(MAX_GOALS+1)]
SCORE_GRID=np.array([[score(t,o) for o in OUTCOMES] for t in TIPS],dtype=float)

def score_prob_matrix(lh, la, family='poisson', rho=0, dispersion=np.inf):
    if family=='elo':family='poisson'
    if family not in ('poisson','dc','nb'):raise ValueError('Unknown score distribution')
    if not all(np.isfinite(v) for v in (lh,la,rho)) or lh<=0 or la<=0:
        raise ValueError('Goal rates must be finite and positive')
    lh=float(np.clip(lh,0.05,5.5)); la=float(np.clip(la,0.05,5.5))
    k=np.arange(MAX_GOALS+1)
    if family=='nb':
        if not np.isfinite(dispersion) or dispersion<=0: raise ValueError('NB dispersion must be positive')
        ph=nbinom.pmf(k,dispersion,dispersion/(dispersion+lh))
        pa=nbinom.pmf(k,dispersion,dispersion/(dispersion+la))
    else:
        ph=poisson.pmf(k,lh); pa=poisson.pmf(k,la)
    p=np.outer(ph,pa)
    if family=='dc':
        # Dixon-Coles: low-score correction. This modifies 0:0, 0:1, 1:0, 1:1.
        tau=[1-lh*la*rho, 1+lh*rho, 1+la*rho, 1-rho]
        if min(tau)<=0: raise ValueError('Invalid low-score correlation')
        p[0,0]*=tau[0];p[0,1]*=tau[1];p[1,0]*=tau[2];p[1,1]*=tau[3]
    p=np.maximum(p,0)
    p/=p.sum()
    return p

def prediction_matrix(record):
    if 'probability_matrix' in record:
        p=np.asarray(record['probability_matrix'],dtype=float)
        validate_matrix(p)
        return p
    return score_prob_matrix(record['lambda_home'],record['lambda_away'],record['family'],record['rho'],record['dispersion'])

def validate_matrix(p):
    if p.shape!=(MAX_GOALS+1,MAX_GOALS+1) or not np.isfinite(p).all() or (p<0).any() or not np.isclose(p.sum(),1,atol=1e-10):
        raise ValueError('Invalid score probability matrix')

def optimal_from_matrix(p):
    p=np.asarray(p,dtype=float)
    validate_matrix(p)
    # Exact 4/2/1 expectation, using diagonal sums rather than a dense matrix product.
    tendencies=[float(np.triu(p,1).sum()),float(np.trace(p)),float(np.tril(p,-1).sum())]
    differences={d:float(np.diagonal(p,offset=-d).sum()) for d in range(-MAX_GOALS,MAX_GOALS+1)}
    eps=np.array([tendencies[int(np.sign(a-b))+1]+differences[a-b]+2*p[a,b] for a,b in TIPS])
    index=int(np.argmax(eps))
    a,b=TIPS[index]
    probs={'home':float(np.tril(p,-1).sum()),'draw':float(np.trace(p)),
           'away':float(np.triu(p,1).sum())}
    order=np.lexsort((np.arange(len(eps)),-eps))[:5]
    second=float(np.sort(eps)[-2])
    return {'tip':f'{a}:{b}', 'ep':float(eps[index]), 'ep_margin':float(eps[index]-second),
            'prob_exact':float(p[a,b]),'prob_home':probs['home'],
            'prob_draw':probs['draw'],'prob_away':probs['away'],
            'alternatives': [{'tip':f'{TIPS[i][0]}:{TIPS[i][1]}','ep':round(float(eps[i]),4)} for i in order]}


def normalize(df, source='unknown'):
    names={'Date':'date','HomeTeam':'home','AwayTeam':'away','FTHG':'hg','FTAG':'ag',
           'xg_home':'xgh','xg_away':'xga','XGH':'xgh','XGA':'xga'}
    df=df.rename(columns=names).copy()
    needed={'date','home','away','hg','ag'}
    if not needed.issubset(df):raise ValueError(f'{source}: missing columns {needed-set(df)}')
    df['date']=parse_dates(df['date'])
    df['home']=df['home'].map(canonical); df['away']=df['away'].map(canonical)
    for c in ('hg','ag','xgh','xga'):
        if c in df: df[c]=pd.to_numeric(df[c],errors='coerce')
    df=df.dropna(subset=['date','home','away','hg','ag']).copy()
    df=df[(df.hg>=0)&(df.ag>=0)&(df.hg%1==0)&(df.ag%1==0)].copy()
    if (df.home==df.away).any():raise ValueError(f'{source}: home and away duplicate')
    df['season']=df.date.map(season_of)
    return df


def load_data(data_dir, first=2015, last=2026, allow_download=False):
    data_dir=Path(data_dir); data_dir.mkdir(parents=True,exist_ok=True)
    frames=[]; missing=[]
    for year in range(first,last+1):
        name=f'D1_{year}_{year+1}.csv'; path=data_dir/name
        if not path.exists():
            # Prefer public-domain OpenFootball match results (no betting odds).
            # Cached TXT also works offline, even when --download is absent.
            from openfootball_import import convert_one
            txt=data_dir/f'openfootball_{year}_{year+1}.txt'
            if txt.exists() or allow_download:
                try:
                    convert_one(year,data_dir,download=allow_download,strict=year<=2025)
                except Exception as exc:
                    print(f'OpenFootball import unavailable {year}/{year+1}: {str(exc)[:180]}')
        if path.exists():
            try:
                raw=pd.read_csv(path, on_bad_lines='skip',encoding='utf-8-sig')
                d=normalize(raw,source=name)
                d=d[d.season==year]
                if len(d):frames.append(d)
                print(f'OK {name}: {len(d)} games')
            except Exception as exc:
                raise ValueError(f'Unusable file {path}: {exc}') from exc
        else: missing.append(name)
    if not frames: raise FileNotFoundError('No historical CSV files. Run with --download on a computer with internet or put source CSVs in data/.')
    all_games=pd.concat(frames,ignore_index=True)
    extra=data_dir/'verified_results.csv'
    if extra.exists():
        add=normalize(pd.read_csv(extra),str(extra));all_games=pd.concat([all_games,add],ignore_index=True)
    all_games=all_games.sort_values(['date','home','away']).drop_duplicates(['date','home','away'],keep='last').reset_index(drop=True)
    if all_games.duplicated(['date','home','away']).any():raise AssertionError('Duplicated match')
    return all_games,missing


def add_xg_if_available(games,data_dir):
    p=Path(data_dir)/'match_xg.csv'
    if not p.exists():return games
    df=pd.read_csv(p)
    df=df.rename(columns={'Date':'date','HomeTeam':'home','AwayTeam':'away','xg_home':'xgh','xg_away':'xga'})
    for col in ('date','home','away','xgh','xga'):
        if col not in df:raise ValueError(f'match_xg.csv missing {col}')
    df['date']=parse_dates(df.date)
    for k in ('home','away'):df[k]=df[k].map(canonical)
    for k in ('xgh','xga'):df[k]=pd.to_numeric(df[k],errors='coerce')
    if df.duplicated(['date','home','away']).any():raise ValueError('Duplicate xG rows')
    # No arbitrary season-level aggregates; xG belongs to the actual finished match.
    games=games.drop(columns=['xgh','xga'],errors='ignore').merge(
        df[['date','home','away','xgh','xga']],on=['date','home','away'],how='left',validate='one_to_one')
    return games


def calc_rest(games,fixtures=None):
    """Days since previous LEAGUE match. Excludes cups unless they are supplied separately."""
    history={}; rows=[]
    combined=games[['date','home','away']].copy().assign(kind='played')
    if fixtures is not None:
        upcoming=fixtures[['date','home','away']].copy().assign(kind='fixture')
        combined=pd.concat([combined,upcoming],ignore_index=True)
    combined=combined.sort_values(['date','kind'],ascending=[True,False])
    for r in combined.itertuples(index=False):
        h,a=r.home,r.away;day=r.date
        rh=(day-history[h]).days if h in history else np.nan
        ra=(day-history[a]).days if a in history else np.nan
        rows.append({'date':day,'home':h,'away':a,'rest_home':rh,'rest_away':ra})
        if r.kind=='played': history[h]=day;history[a]=day
    out=pd.DataFrame(rows)
    # Duplicates (games in fixtures) are not expected, but keep fixture values if same identity.
    return out.drop_duplicates(['date','home','away'],keep='last')


def add_rest(games,fixtures=None):
    rests=calc_rest(games,fixtures)
    games=games.drop(columns=['rest_home','rest_away'],errors='ignore').merge(
        rests,on=['date','home','away'],how='left',validate='one_to_one')
    if fixtures is None:return games,None
    fixtures=fixtures.merge(rests,on=['date','home','away'],how='left',validate='one_to_one')
    return games,fixtures


@dataclass(frozen=True)
class ModelSpec:
    half_life: int=365
    ridge: float=3.0
    family: str='poisson'
    dispersion: float=8.0
    xg_blend: float=0.0
    rest_coef: float=0.0
    promotion_penalty: float=0.0
    lookback: int=1095
    elo_k: float=24.0
    elo_beta: float=.48


def weighted_fit(train, teams, at_date, half_life, ridge, target_home='hg',target_away='ag'):
    n=len(teams); lookup={t:i for i,t in enumerate(teams)}
    hi=np.array([lookup[x] for x in train.home]);ai=np.array([lookup[x] for x in train.away])
    yh=train[target_home].to_numpy(dtype=float);ya=train[target_away].to_numpy(dtype=float)
    valid=np.isfinite(yh)&np.isfinite(ya)
    hi=hi[valid];ai=ai[valid];yh=yh[valid];ya=ya[valid]
    ages=np.maximum((at_date-train.date).dt.days.to_numpy()[valid],0)
    weights=np.exp(-np.log(2)*ages/half_life)
    def obj(z):
        att=z[:n]-np.mean(z[:n]);defe=z[n:2*n]-np.mean(z[n:2*n])
        base,home=z[-2:]
        eh=np.clip(base+home+att[hi]-defe[ai],-4,2.2)
        ea=np.clip(base+att[ai]-defe[hi],-4,2.2)
        lh=np.exp(eh);la=np.exp(ea)
        rh=weights*(lh-yh);ra=weights*(la-ya)
        nll=np.sum(weights*(lh-yh*eh+la-ya*ea))
        reg=0.5*ridge*(att@att+defe@defe)+0.1*ridge*home**2
        gatt=np.bincount(hi,weights=rh,minlength=n)+np.bincount(ai,weights=ra,minlength=n)
        gdef=-np.bincount(ai,weights=rh,minlength=n)-np.bincount(hi,weights=ra,minlength=n)
        gatt=gatt-gatt.mean()+ridge*att
        gdef=gdef-gdef.mean()+ridge*defe
        grad=np.r_[gatt,gdef,np.sum(rh+ra),np.sum(rh)+0.2*ridge*home]
        return nll+reg,grad
    z=np.zeros(2*n+2);z[-2]=np.log(max(np.mean(np.r_[yh,ya]),0.5));z[-1]=0.2
    fitted=minimize(obj,z,jac=True,method='L-BFGS-B', options={'maxiter':250,'ftol':1e-9})
    if not fitted.success and np.max(np.abs(fitted.jac))>0.1:
        raise RuntimeError(f'Optimizer failed: {fitted.message}')
    p=fitted.x
    return {'teams':lookup,'att':p[:n]-np.mean(p[:n]),'def':p[n:2*n]-np.mean(p[n:2*n]),
            'base':p[-2],'home':p[-1]}


def rates_from_fit(fit,fixtures):
    idx=fit['teams'];att=fit['att'];de=fit['def'];base=fit['base'];home=fit['home']
    def strength(t,kind):
        j=idx.get(t)
        return 0.0 if j is None else float((att if kind=='att' else de)[j])
    hs=[];as_=[]
    for r in fixtures.itertuples(index=False):
        hs.append(math.exp(float(np.clip(base+home+strength(r.home,'att')-strength(r.away,'def'),-3,1.7))))
        as_.append(math.exp(float(np.clip(base+strength(r.away,'att')-strength(r.home,'def'),-3,1.7))))
    return np.array(hs),np.array(as_)


def fit_dc_rho(train, rates_home, rates_away, at_date, half_life):
    actual_h=train.hg.to_numpy(dtype=int);actual_a=train.ag.to_numpy(dtype=int)
    recent=np.exp(-np.log(2)*np.maximum((at_date-train.date).dt.days.to_numpy(),0)/half_life)
    def loss(rho):
        tau=np.ones(len(train))
        x,y=actual_h,actual_a
        m=(x==0)&(y==0);tau[m]=1-rho*rates_home[m]*rates_away[m]
        m=(x==0)&(y==1);tau[m]=1+rho*rates_home[m]
        m=(x==1)&(y==0);tau[m]=1+rho*rates_away[m]
        m=(x==1)&(y==1);tau[m]=1-rho
        if np.any(tau<=0):return 1e12
        return -float(np.sum(recent*np.log(tau)))
    result=minimize_scalar(loss,method='bounded',bounds=(-.12,.12),options={'xatol':1e-4})
    return float(result.x)


def promoted_set(train, at_date):
    """Infer teams without previous-season Bundesliga appearance (not D2 strength)."""
    y=season_of(at_date)
    previous=set(train.loc[train.season==y-1,'home'])|set(train.loc[train.season==y-1,'away'])
    current=set(train.loc[train.season==y,'home'])|set(train.loc[train.season==y,'away'])
    return current-previous if len(previous)>=14 else set()



def elo_rates(train,fixtures,at_date,spec):
    """Result-only Elo alternative; match outcomes are read exclusively before cutoff."""
    ratings={}
    h_base=max(float(train.hg.mean()),.3); a_base=max(float(train.ag.mean()),.3)
    for r in train.sort_values(['date','home','away']).itertuples(index=False):
        h=ratings.get(r.home,1500.);a=ratings.get(r.away,1500.)
        advantage=65.
        exp_h=1/(1+10**((a-h-advantage)/400))
        actual=1. if r.hg>r.ag else (.5 if r.hg==r.ag else 0.)
        update=spec.elo_k*(1+math.log1p(abs(int(r.hg)-int(r.ag))))*(actual-exp_h)
        ratings[r.home]=h+update;ratings[r.away]=a-update
    lh=[];la=[]
    for r in fixtures.itertuples(index=False):
        diff=(ratings.get(r.home,1500.)-ratings.get(r.away,1500.))/400
        lh.append(h_base*math.exp(spec.elo_beta*diff))
        la.append(a_base*math.exp(-spec.elo_beta*diff))
    return np.clip(lh,.05,5.5),np.clip(la,.05,5.5),0.,False

def predict_rates(train, fixtures, spec):
    if len(train)<120:raise ValueError('Need >=120 past matches')
    at_date=pd.Timestamp(fixtures.date.min())
    if (train.date>=at_date).any():raise AssertionError('DATA LEAKAGE: training includes forecast date/future!')
    train=train[train.date>=at_date-pd.Timedelta(days=spec.lookback)].copy()
    if spec.family=='elo': return elo_rates(train,fixtures,at_date,spec)
    teams=sorted(set(train.home)|set(train.away)|set(fixtures.home)|set(fixtures.away))
    fit=weighted_fit(train,teams,at_date,spec.half_life,spec.ridge)
    lh,la=rates_from_fit(fit,fixtures)
    rho=0.
    if spec.family=='dc':
        th,ta=rates_from_fit(fit,train)
        rho=fit_dc_rho(train,th,ta,at_date,spec.half_life)
    xg_used=False
    if spec.xg_blend>0 and not {'xgh','xga'}.issubset(train):
        raise ValueError('xG blend requested but per-match xG file is missing')
    if spec.xg_blend>0 and {'xgh','xga'}.issubset(train):
        available=train[['xgh','xga']].notna().all(axis=1).mean()
        if available>=.80:
            f_xg=weighted_fit(train,teams,at_date,spec.half_life,spec.ridge, 'xgh','xga')
            xh,xa=rates_from_fit(f_xg,fixtures)
            lh=lh**(1-spec.xg_blend)*xh**spec.xg_blend
            la=la**(1-spec.xg_blend)*xa**spec.xg_blend
            xg_used=True
        else:raise ValueError(f'xG coverage {available:.1%} is <80%; cannot backtest xG specification')
    newly=promoted_set(train,at_date)
    for i,r in enumerate(fixtures.itertuples(index=False)):
        # Optional promoted-team adjustment, ONLY if tuned on historical validation.
        if r.home in newly:lh[i]*=math.exp(-spec.promotion_penalty);la[i]*=math.exp(spec.promotion_penalty)
        if r.away in newly:la[i]*=math.exp(-spec.promotion_penalty);lh[i]*=math.exp(spec.promotion_penalty)
        # Difference in available LEAGUE recovery time; not a substitute for UEFA/cup fixtures.
        rh=getattr(r,'rest_home',np.nan);ra=getattr(r,'rest_away',np.nan)
        if pd.notna(rh) and pd.notna(ra):
            rest_delta=(min(float(rh),7)-min(float(ra),7))/7
            lh[i]*=math.exp(spec.rest_coef*rest_delta)
            la[i]*=math.exp(-spec.rest_coef*rest_delta)
    return np.clip(lh,.05,5.5),np.clip(la,.05,5.5),rho,xg_used


def predictions(train, fixtures, spec, mode='model'):
    if mode=='constant':
        h=float(np.mean(train.hg));a=float(np.mean(train.ag))
        lh=np.repeat(h,len(fixtures));la=np.repeat(a,len(fixtures));rho=0;xg=False
    elif mode=='model':
        lh,la,rho,xg=predict_rates(train,fixtures,spec)
    else:raise ValueError('unknown mode')
    records=[]
    for i,r in enumerate(fixtures.itertuples(index=False)):
        pm=score_prob_matrix(lh[i],la[i],spec.family if mode=='model' else 'poisson',
                             rho if mode=='model' else 0,spec.dispersion)
        o=optimal_from_matrix(pm)
        records.append({'date':str(pd.Timestamp(r.date).date()),'home':r.home,'away':r.away,
                        'lambda_home':float(lh[i]),'lambda_away':float(la[i]),
                        'rho':float(rho),'xg_used':bool(xg),
                        **{k:v for k,v in o.items() if k!='alternatives'},
                        'alternatives':o['alternatives'],
                        '_p_matrix':pm})
    return records


def evaluate(preds, actual_df, tag):
    result=[]
    a={(r.date.date(),r.home,r.away):(int(r.hg),int(r.ag)) for r in actual_df.itertuples(index=False)}
    for o in preds:
        key=(pd.Timestamp(o['date']).date(),o['home'],o['away'])
        if key not in a:continue
        x,y=a[key];t=tuple(map(int,o['tip'].split(':')))
        p=o['_p_matrix']; pr=[o['prob_home'],o['prob_draw'],o['prob_away']]
        klass=0 if x>y else (1 if x==y else 2)
        event_prob=max(float(p[x,y]) if x<=MAX_GOALS and y<=MAX_GOALS else 1e-10,1e-10)
        out={k:v for k,v in o.items() if k not in ('_p_matrix','alternatives')}
        out.update({'model':tag,'actual':f'{x}:{y}','points':score(t,(x,y)),
                    'exact':int(t==(x,y)), 'score_log_loss':-math.log(event_prob),
                    'brier_1x2':sum((pr[j]-(j==klass))**2 for j in range(3))})
        result.append(out)
    return result


def rolling_evaluation(all_games, seasons, spec, mode='model', freq='M'):
    test=all_games[all_games.season.isin(seasons)].copy()
    results=[]
    for _,chunk in test.groupby(test.date.dt.to_period(freq),sort=True):
        cutoff=chunk.date.min()
        prior=all_games[(all_games.date<cutoff)&(all_games.date>=cutoff-pd.Timedelta(days=spec.lookback))]
        if len(prior)<120:continue
        if spec.xg_blend and not {'xgh','xga'}.issubset(prior): continue
        # For each month, prediction uses ONLY information known before the first match.
        pred=predictions(prior,chunk,spec,mode)
        results.extend(evaluate(pred,chunk,tag=mode+':'+spec.family))
    return pd.DataFrame(results)


def metric(df):
    return {'n':int(len(df)),'points_per_game':float(df.points.mean()),
            'exact_pct':float(df.exact.mean()*100),
            'score_log_loss':float(df.score_log_loss.mean()),
            'brier_1x2':float(df.brier_1x2.mean()),
            'total_points':int(df.points.sum())}


def bootstrap_difference(a,b,n_reps=2000,seed=42):
    """Block bootstrap by calendar month for model-baseline differences."""
    ab=a[['date','home','away','points']].merge(
        b[['date','home','away','points']],on=['date','home','away'],suffixes=('_m','_b'))
    if len(ab)==0:return None
    ab['block']=pd.to_datetime(ab.date).dt.to_period('M').astype(str)
    monthly=[(q.points_m-q.points_b).to_numpy() for _,q in ab.groupby('block')]
    rng=np.random.default_rng(seed);draws=[]
    for _ in range(n_reps):
        ix=rng.integers(0,len(monthly),size=len(monthly))
        d=np.concatenate([monthly[i] for i in ix]);draws.append(d.mean())
    lo,hi=np.quantile(draws,[.025,.975])
    return {'delta_points_per_game':float((ab.points_m-ab.points_b).mean()),
            'ci95_low':float(lo),'ci95_high':float(hi), 'n':len(ab)}


def make_candidates(include_xg=False):
    variants=[ModelSpec(half_life=h,ridge=r,family='poisson') for h in (180,365,730) for r in (2.0,8.0)]
    variants += [ModelSpec(family='elo',elo_k=20,elo_beta=.35),
                 ModelSpec(family='elo',elo_k=32,elo_beta=.55)]
    variants += [ModelSpec(half_life=365,ridge=2,family='dc'),
                 ModelSpec(half_life=365,ridge=8,family='dc'),
                 ModelSpec(half_life=365,ridge=2,family='nb',dispersion=8),
                 ModelSpec(half_life=365,ridge=8,family='nb',dispersion=5),
                 ModelSpec(half_life=365,ridge=2,rest_coef=.1),
                 ModelSpec(half_life=365,ridge=2,promotion_penalty=.15)]
    if include_xg:
        variants += [ModelSpec(half_life=365,ridge=2,xg_blend=b) for b in (.25,.5,.75)]
    return variants


def validate_select(games, outdir, fast=False):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    # Check potential future holdout pre-match xG availability *without reading result labels*;
    # avoid selecting xG variants that become impossible by late 2025/26.
    covered=games[games.season.between(2020,2025)]
    xg_flag={'xgh','xga'}.issubset(covered) and covered[['xgh','xga']].notna().all(axis=1).mean()>=.90
    candidates=make_candidates(include_xg=xg_flag)
    if fast:candidates=[candidates[0],candidates[2],candidates[8]]
    val_seasons=[2023,2024]; test_seasons=[2025]
    # Prevent misleading success claims when source seasons are incomplete.
    for y in val_seasons+test_seasons:
        n=int((games.season==y).sum())
        if n!=306:raise ValueError(f'Season {y}/{y+1} only {n} matches; require exactly 306 for full-season evaluation')
        check=games[games.season==y]
        club_counts=pd.concat([check.home,check.away]).value_counts()
        if len(club_counts)!=18 or (club_counts!=34).any():
            raise ValueError(f'Season {y}/{y+1}: schedule/club name inconsistency; every club must appear 34 times')
    runs=[]; predictions_by_index={}
    baseline=rolling_evaluation(games,val_seasons,ModelSpec(),mode='constant')
    for i,spec in enumerate(candidates):
        print('Validating',i+1,'/',len(candidates),asdict(spec),flush=True)
        try:
            res=rolling_evaluation(games,val_seasons,spec)
            if len(res)<570:raise ValueError(f'Only {len(res)} matches')
            m=metric(res);runs.append({'index':i,**m,**asdict(spec)})
            predictions_by_index[i]=res
        except Exception as e:print('Candidate rejected:',str(e)[:250],flush=True)
    if not runs:raise RuntimeError('All candidates failed')
    rankings=pd.DataFrame(runs).sort_values(['score_log_loss','brier_1x2'],ascending=[True,True]);rankings.to_csv(outdir/'validation_comparison.csv',index=False)
    best_idx=int(rankings.iloc[0]['index']);best=candidates[best_idx]
    # Freeze configuration here before untouched 2025/26 evaluation.
    model_test=rolling_evaluation(games,test_seasons,best)
    baseline_test=rolling_evaluation(games,test_seasons,ModelSpec(),mode='constant')
    for tag,frame,season_count in [('validation baseline',baseline,612),
                                    ('holdout chosen',model_test,306),('holdout baseline',baseline_test,306)]:
        if len(frame)!=season_count:
            raise RuntimeError(f'{tag}: expected {season_count} historical forecasts, got {len(frame)}')
    model_test.to_csv(outdir/'holdout_predictions_2025_26.csv',index=False)
    baseline_test.to_csv(outdir/'holdout_baseline_2025_26.csv',index=False)
    match_fingerprint=hashlib.sha256(pd.util.hash_pandas_object(
        games[['date','home','away','hg','ag']],index=False).values.tobytes()).hexdigest()
    report={'calculated_at_utc':datetime.now(timezone.utc).isoformat(),
            'dataset_match_fingerprint_sha256':match_fingerprint,
            'dataset_games':len(games),
            'games_by_season':{str(k):int(v) for k,v in games.groupby('season').size().items()},
            'data_source':'Public-domain OpenFootball TXT or user-supplied Bundesliga D1 CSV; optionally match-level xG',
            'validation_seasons':val_seasons,'holdout_season':2025,'chosen_spec':asdict(best),
            'selection_criterion':'validation mean scoreline negative log-likelihood; 1X2 Brier tiebreaker',
            'validation_chosen':metric(predictions_by_index[best_idx]),
            'validation_by_season':{str(y):metric(predictions_by_index[best_idx][pd.to_datetime(predictions_by_index[best_idx].date).map(season_of)==y]) for y in val_seasons},
            'validation_baseline':metric(baseline),
            'holdout_chosen':metric(model_test),'holdout_baseline':metric(baseline_test),
            'validation_delta_ci':bootstrap_difference(predictions_by_index[best_idx],baseline),
            'holdout_delta_ci':bootstrap_difference(model_test,baseline_test),
            'disclaimer':'Confidence intervals are sampling estimates; retrospective performance does not guarantee future rank 1.'}
    (outdir/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (outdir/'chosen_spec.json').write_text(json.dumps(asdict(best),indent=2),encoding='utf-8')
    return report


def load_fixtures(path):
    df=pd.read_csv(path);need={'date','home','away'}
    if not need.issubset(df):raise ValueError('Fixture CSV requires date,home,away')
    df['date']=parse_dates(df.date)
    for k in ('home','away'):df[k]=df[k].map(canonical)
    if df.duplicated(['date','home','away']).any():raise ValueError('Duplicate fixtures')
    return df


def sensitivity(lh,la,spec,rho):
    """Does the optimal tip survive +/-10% in each expected-goals rate? (NOT a CI.)"""
    choices=[]
    for dh in (.9,1.,1.1):
        for da in (.9,1.,1.1):
            try:
                m=score_prob_matrix(lh*dh,la*da,spec.family,rho,spec.dispersion)
                choices.append(optimal_from_matrix(m)['tip'])
            except ValueError: pass
    return {'same_in_9_scenarios':len(set(choices))==1, 'unique_tips':sorted(set(choices))}


def load_scenarios(path, asof_at):
    """Optional NON-VALIDATED scenario only. Never mix into the model's claimed backtest."""
    if not path or not Path(path).exists():return {}
    df=pd.read_csv(path)
    required={'date','home','away','known_at','home_log_delta','away_log_delta','source'}
    if not required.issubset(df):raise ValueError(f'context file missing: {required-set(df)}')
    df['date']=parse_dates(df.date)
    df['known_at']=pd.to_datetime(df.known_at,utc=True)
    at=pd.to_datetime(asof_at,utc=True)
    df=df[df.known_at<=at].copy()
    if df.duplicated(['date','home','away']).any():raise ValueError('Duplicate scenario rows')
    result={}
    for r in df.itertuples(index=False):
        if not str(r.source).strip():raise ValueError('Scenario must cite a source')
        h,a=canonical(r.home),canonical(r.away)
        lh,la=float(r.home_log_delta),float(r.away_log_delta)
        if max(abs(lh),abs(la))>.3:raise ValueError('Max absolute log-delta is 0.30')
        result[(r.date.date(),h,a)]=(lh,la,str(r.source))
    return result


def do_forecast(games, fixture_file, spec_file, outdir, asof, context_file=None,asof_at=None, min_current_games=0):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    specs=ModelSpec(**json.loads(Path(spec_file).read_text(encoding='utf-8')))
    fixtures=load_fixtures(fixture_file)
    limit=pd.Timestamp(asof).normalize()
    fixtures=fixtures[fixtures.date>=limit].copy()
    # Never use unknown future results. Friday results may already be known.
    prior=games[games.date<limit].copy()
    if len(prior)<120:raise ValueError('Insufficient past match data')
    cur_season=season_of(limit)
    count_current=int((prior.season==cur_season).sum())
    if count_current<min_current_games:
        raise ValueError(f'Current season {cur_season}/{cur_season+1}: only {count_current} of '
                         f'{min_current_games} required completed matches in data; refresh data first')
    if len(prior):
        last_day=prior.date.max()
        if (limit-last_day).days>21:
            print(f'WARNING: latest stored result is {last_day.date()}, '
                  f'{(limit-last_day).days} days before forecast. Data may be stale.',flush=True)
    prior,fixtures=add_rest(prior,fixtures)
    scenarios=load_scenarios(context_file,asof_at or asof)
    rows=[]
    for date,chunk in fixtures.groupby('date'):
        if date<limit:continue
        past=prior[prior.date<date].copy()
        if not len(past):continue
        picks=predictions(past,chunk,specs)
        for p in picks:
            p.pop('_p_matrix')
            p['sensitivity_10pct']=sensitivity(p['lambda_home'],p['lambda_away'],specs,p['rho'])
            key=(pd.Timestamp(p['date']).date(),p['home'],p['away'])
            if key in scenarios:
                dh,da,source=scenarios[key]
                pp=score_prob_matrix(p['lambda_home']*math.exp(dh),
                    p['lambda_away']*math.exp(da),specs.family,p['rho'],specs.dispersion)
                alt=optimal_from_matrix(pp)
                p['unvalidated_scenario']={'tip':alt['tip'],'ep':alt['ep'],
                    'home_log_delta':dh,'away_log_delta':da,'source':source}
            rows.append(p)
    pd.DataFrame([{k:v for k,v in row.items() if k!='alternatives'} for row in rows]).to_csv(outdir/'upcoming_predictions.csv',index=False)
    (outdir/'upcoming_predictions_full.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    return rows


def main():
    cli=argparse.ArgumentParser(description='Auditable Bundesliga expected-points engine 4/2/1')
    cli.add_argument('action',choices=['validate','forecast','inspect'])
    cli.add_argument('--data',default='data');cli.add_argument('--output',default='output')
    cli.add_argument('--download',action='store_true',help='Download public-domain OpenFootball Bundesliga TXT for missing historical seasons')
    cli.add_argument('--min-current-season-games',type=int,default=0,help='Safety guard against incomplete recent results (e.g. 72 after 8 completed rounds)')
    cli.add_argument('--fast',action='store_true',help='Only 3 candidates for smoke test; not final calibration')
    cli.add_argument('--fixtures',default='fixtures_st8.csv');cli.add_argument('--spec',default='output/chosen_spec.json')
    cli.add_argument('--asof',default='2026-10-31')
    cli.add_argument('--context',default=None,help='Optional scenario CSV, not validated as a model factor')
    cli.add_argument('--asof-at',default=None,help='ISO timestamp for scenario source publication cutoff')
    args=cli.parse_args()
    games, missing=load_data(args.data,allow_download=args.download)
    games=add_xg_if_available(games,args.data)
    games,_=add_rest(games)
    print('Loaded',len(games),'matches; missing files:',len(missing))
    if args.action=='inspect':
        print(games.groupby('season').size().to_string());return
    if args.action=='validate':
        report=validate_select(games,args.output,fast=args.fast)
        print(json.dumps(report,ensure_ascii=False,indent=2))
    elif args.action=='forecast':
        rows=do_forecast(games,args.fixtures,args.spec,args.output,args.asof,args.context,args.asof_at,args.min_current_season_games)
        for r in rows:
            print(f"{r['date']} {r['home']:12s} - {r['away']:12s} {r['tip']} | EP {r['ep']:.3f} | λ {r['lambda_home']:.2f}–{r['lambda_away']:.2f}")

if __name__=='__main__':main()
