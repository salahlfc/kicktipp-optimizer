"""Private, browser-local non-betting diary. Never creates betting suggestions."""
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import streamlit as st
import streamlit.components.v1 as components

FRONTEND=Path(__file__).resolve().parent/'journal_frontend'
_journal=components.declare_component('local_journal',path=str(FRONTEND))


@st.fragment(run_every=60)
def render(mode='System'):
    st.title('Nicht gewettet.')
    st.caption('Dein 20-€-Papiermodus · kein Geldeinsatz')
    st.write('Markiere die Tage, an denen du sonst gewettet hättest. Pro Tag zählen einmalig 20 € als fiktiv nicht eingesetzter Betrag.')
    _journal(mode=mode,today=datetime.now(ZoneInfo('Europe/Berlin')).date().isoformat(),key='local_savings_diary',default=None)
    with st.expander('Was diese Zahlen bedeuten'):
        st.write('20 € je markiertem Tag sind dein fester Vergleichsbetrag. Das ist keine Bankgutschrift und kein nachgewiesener vermiedener Verlust. Ob ein nicht abgeschlossener Wettschein gewonnen hätte, ist damit nicht bekannt.')
        st.write('Du markierst einen Tag selbst. Bloßes Öffnen der App oder ein Tageswechsel erzeugt keinen Eintrag. Das Datum wird bei geöffneter Seite etwa minütlich aktualisiert. Es gibt keine automatischen Wetttipps, Quoten, Kombis oder Einsatzempfehlungen und keinen täglichen Hintergrundauftrag.')
        st.write('Dein Verlauf bleibt ausschließlich im Speicher dieses Browsers. Er wird nicht an den App-Server geschickt. Auf einem anderen Gerät, nach Löschen der Browserdaten oder im privaten Modus kann er fehlen. Nutze das lokale JSON-Backup zum Übertragen und Sichern.')
    with st.expander('Papierschein aus dem geteilten Chat'):
        st.write('Im Chat vom 12.11.2026 wurde ein bestehender Vergleich mit 10 € fiktivem Einsatz beschrieben; für weitere Tage waren 20 € vorgesehen. Der angegebene Schein, seine Quoten und eine Abrechnung sind hier nicht verifiziert und werden deshalb nicht als Ergebnis oder Ersparnis verbucht.')
        st.caption('Keine Tipps aus diesem Chat werden als neue Empfehlung übernommen. Die dort erwähnten Automationen sind durch diesen Reiter nicht eingerichtet.')
