"""Existing paper-slip tracking with an optional private non-betting diary."""
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import streamlit as st
import streamlit.components.v1 as components

FRONTEND=Path(__file__).resolve().parent/'journal_frontend'
_journal=components.declare_component('local_journal',path=str(FRONTEND))


@st.fragment(run_every=60)
def render(mode='System'):
    from paper_tracker import render as render_tracker
    st.title('Dein Papierschein.')
    st.caption('Vorhandener Schein vom 12.11.2026 · ausschließlich fiktiv')
    render_tracker()
    with st.expander('Optional: privates Nichtwetten-Tagebuch'):
        st.write('Dieser separate Zähler bewertet keine Scheine: Du kannst selbst Nichtwetten-Tage mit je 20 € fiktivem Vergleichsbetrag markieren. Er wird nicht zur Papierbilanz addiert.')
        _journal(mode=mode,today=datetime.now(ZoneInfo('Europe/Berlin')).date().isoformat(),key='local_savings_diary',default=None)
        st.write('Dein Verlauf bleibt ausschließlich im Speicher dieses Browsers. Er wird nicht an den App-Server geschickt. Auf einem anderen Gerät, nach Löschen der Browserdaten oder im privaten Modus kann er fehlen. Nutze das lokale JSON-Backup zum Übertragen und Sichern.')
