"""Berlin Tuesday cycles and honest scoring of forecasts saved before kickoff."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from engine import canonical, score, prediction_matrix
from leanflow import BERLIN, atomic_json


def local_time(value=None):
    t=pd.Timestamp.now(tz=BERLIN) if value is None else pd.Timestamp(value)
    if t.tzinfo is None:raise ValueError('Der Wochenwechsel braucht eine eindeutige Zeitzone.')
    return t.tz_convert(BERLIN)


def tuesday_anchor(value):
    t=local_time(value)
    # Work with local calendar dates, not 24-hour arithmetic over DST boundaries.
    day=t.date()-pd.Timedelta(days=(t.weekday()-1)%7)
    return pd.Timestamp(day).tz_localize(BERLIN)


def weekly_cycle(schedule,now=None):
    now=local_time(now);anchor=tuesday_anchor(now)
    following=pd.Timestamp(anchor.date()+pd.Timedelta(days=7)).tz_localize(BERLIN)
    rounds=[]
    for rnd in sorted({r['round'] for r in schedule}):
        games=[r for r in schedule if r['round']==rnd]
        times=sorted(pd.Timestamp(r['kickoff']).tz_convert(BERLIN) for r in games)
        nominal=times[len(times)//2]  # One postponed game cannot move an entire matchday.
        rounds.append({'round':rnd,'anchor':tuesday_anchor(nominal),'nominal':nominal,
                       'first':times[0],'started':any(t<=now for t in times),
                       'complete':all(r['finished'] for r in games)})
    rounds.sort(key=lambda r:(r['nominal'],r['round']))
    current=[r for r in rounds if r['anchor']==anchor]
    started=[r for r in current if r['started']]
    active=started[-1] if started else None
    future=[r for r in current if not r['started']]
    # English weeks can contain another matchday before the next Tuesday.
    if future and (active is None or active['complete']):
        phase='forecast';target=future[0]['round']
    elif active:
        phase='review';target=active['round']
    else:
        previous=[r for r in rounds if r['nominal']<anchor]
        upcoming=[r for r in rounds if r['anchor']>=anchor and not r['complete']]
        if now.weekday()==0 or not upcoming:
            phase='review';target=previous[-1]['round'] if previous else None
        else:
            phase='forecast';target=upcoming[0]['round']
    preceding=[r for r in rounds if target is None or r['nominal']<next(x['nominal'] for x in rounds if x['round']==target)]
    review_round=target if phase=='review' else (preceding[-1]['round'] if preceding else None)
    return {'phase':phase,'round':target,'review_round':review_round,
            'anchor':anchor.isoformat(),'next_tuesday':following.isoformat()}


def archive_runs(folder,season,round_number,now=None):
    now=local_time(now);runs=[]
    paths=list(Path(folder).glob('lean_20*.json'))
    latest=Path(folder)/'lean_latest.json'
    if latest.exists():paths.append(latest)
    seen=set()
    for path in paths:
        try:
            data=json.loads(path.read_text())
            if data.get('season')!=season or data.get('round')!=round_number:continue
            created=local_time(data['created_at'])
            if created>now or not isinstance(data.get('results'),list):continue
            identity=(data['created_at'],json.dumps(data['results'],sort_keys=True))
            if identity in seen:continue
            seen.add(identity);runs.append((created,data))
        except (OSError,ValueError,KeyError,TypeError):continue
    return sorted(runs,key=lambda r:r[0])


def latest_round(folder,season,round_number,now=None):
    runs=archive_runs(folder,season,round_number,now)
    return runs[-1][1] if runs else None


def assess_round(schedule,folder,season,round_number,now=None,persist=True):
    now=local_time(now)
    games=[r for r in schedule if r['round']==round_number]
    runs=archive_runs(folder,season,round_number,now)
    rows=[]
    for game in sorted(games,key=lambda r:(r['kickoff'],r['home'])):
        official=local_time(game['kickoff']);saved=None
        for created,run in runs:
            for p in run['results']:
                if (canonical(p.get('home')),canonical(p.get('away')))!=(game['home'],game['away']):continue
                try:
                    planned=local_time(p['kickoff'])
                    # Both original and current kickoff must follow forecast creation.
                    if created>=min(official,planned):continue
                    trained=pd.Timestamp(run['training_through']).date()
                    if trained>=min(official,planned).date():continue
                    tip=tuple(map(int,p['tip'].split(':')))
                    if len(tip)!=2 or min(tip)<0 or max(tip)>30:continue
                    ep=float(p['ep'])
                    if not np.isfinite(ep) or not 0<=ep<=4:continue
                except (KeyError,ValueError,TypeError):continue
                saved=(created,run,p,tip)
        finished=bool(game['finished']) and official<=now
        row={'home':game['home'],'away':game['away'],'kickoff':game['kickoff'],
             'finished':finished,'actual':f"{game['hg']}:{game['ag']}" if finished else None,
             'tip':None,'points':None,'ep':None,'saved_at':None,'exact':None,'tendency_correct':None,
             'status':'Kein vorab gespeicherter Tipp' if finished else 'Noch offen'}
        if saved:
            created,run,p,tip=saved
            row.update(tip=p['tip'],ep=float(p['ep']),saved_at=created.isoformat())
            if finished:
                actual=(int(game['hg']),int(game['ag']))
                row.update(points=int(score(tip,actual)),delta_points=float(score(tip,actual)-p['ep']),exact=tip==actual,
                           tendency_correct=bool(np.sign(tip[0]-tip[1])==np.sign(actual[0]-actual[1])),status='Bewertet')
                try:
                    matrix=prediction_matrix(p)
                    h,a=actual
                    probability=float(matrix[h,a]) if h<len(matrix) and a<len(matrix) else 0.
                    row['actual_probability']=probability
                    row['tip_probability']=float(matrix[tip[0],tip[1]]) if max(tip)<len(matrix) else 0.
                    row['actual_rank']=int(1+(matrix>probability).sum())
                    row['score_log_loss']=-float(np.log(max(probability,1e-12)))
                    row['tendency_probability']=float(p.get('prob_tendency',p['prob_home'] if tip[0]>tip[1] else p['prob_draw'] if tip[0]==tip[1] else p['prob_away']))
                    row['lambda_home']=float(p['lambda_home']);row['lambda_away']=float(p['lambda_away'])
                    row['explanation']=(f"Tipp {p['tip']}, Endergebnis {h}:{a}: {row['points']} Punkte statt {p['ep']:.2f} erwarteten Punkten "
                        f"(Abweichung {row['delta_points']:+.2f}). Das Modell gab dem exakten Tipp {row['tip_probability']:.1%} "
                        f"und dem tatsächlichen Ergebnis {probability:.1%} Wahrscheinlichkeit (Rang {row['actual_rank']}). "
                        +("Die Tendenz war richtig, der Spielstand wich ab. " if row['tendency_correct'] and not row['exact'] else "Die Tendenz war falsch. " if not row['tendency_correct'] else "Der Tipp traf exakt. ")
                        +"Das beschreibt die statistische Abweichung. Spielverlauf, Platzverweise oder Verletzungen lassen sich aus Endergebnissen allein nicht als Ursache feststellen.")
                except (ValueError,KeyError,TypeError):pass
        rows.append(row)
    covered=[r for r in rows if r['points'] is not None]
    result={'season':season,'round':round_number,'checked_at':now.isoformat(),'rows':rows,
            'games':len(rows),'finished':sum(r['finished'] for r in rows),'evaluated':len(covered),
            'saved_tips':sum(r['tip'] is not None for r in rows),
            'points':sum(r['points'] for r in covered) if covered else None,
            'expected_points':sum(r['ep'] for r in covered) if covered else None,
            'delta_points':sum(r['points']-r['ep'] for r in covered) if covered else None,
            'exact':sum(r['exact'] for r in covered),'tendency_correct':sum(r['tendency_correct'] for r in covered)}
    if persist:
        path=Path(folder)/f'review_{season}_{round_number:02d}.json'
        atomic_json(path,result)
    return result


def learning_history(folder):
    reviews=[]
    for path in Path(folder).glob('review_20*_*.json'):
        try:
            r=json.loads(path.read_text())
            if r['evaluated']>0:reviews.append(r)
        except (OSError,ValueError,KeyError,TypeError):continue
    return sorted(reviews,key=lambda r:(r['season'],r['round']))


def calibration_summary(reviews):
    rows=[r for review in reviews for r in review['rows'] if r.get('points') is not None and 'tendency_probability' in r]
    buckets=[]
    for label,lo,hi in [('Rot',0.,.45),('Gelb',.45,.60),('Grün',.60,1.00001)]:
        group=[r for r in rows if lo<=r['tendency_probability']<hi]
        if not group:continue
        n=len(group);hits=sum(r['tendency_correct'] for r in group);observed=hits/n
        z=1.96;denom=1+z*z/n
        center=(observed+z*z/(2*n))/denom
        margin=z*((observed*(1-observed)/n+z*z/(4*n*n))**.5)/denom
        buckets.append({'Ampel':label,'Tipps':n,'Ø prognostizierte Tendenzchance':sum(r['tendency_probability'] for r in group)/n,
            'Tatsächlich richtige Tendenz':observed,'95-%-Bereich unten':max(0.,center-margin),'95-%-Bereich oben':min(1.,center+margin)})
    return {'games':len(rows),'buckets':buckets,'enough_for_initial_check':len(rows)>=100}
