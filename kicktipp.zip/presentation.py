"""Transparent explanations and compact summaries of the existing forecast."""
from __future__ import annotations
import html
import io
import ipaddress
import subprocess
from urllib.parse import urlsplit
import numpy as np
from engine import score_prob_matrix, prediction_matrix, SCORE_GRID, TIPS, canonical
from webcore import pretty


def traffic(probability):
    if probability>=.60:return ('green','🟢','Grün','Höhere Tendenzchance')
    if probability>=.45:return ('yellow','🟡','Gelb','Mittlere Tendenzchance')
    return ('red','🔴','Rot','Niedrigere Tendenzchance')


def summarize(pmf):
    p=np.asarray(pmf,dtype=float)
    if not len(p) or not np.isfinite(p).all() or (p<0).any() or not np.isclose(p.sum(),1):
        raise ValueError('Ungültige Punkteverteilung')
    p=p/p.sum();c=np.cumsum(p)
    q=lambda v:int(min(np.searchsorted(c,v),len(p)-1))
    lo,hi=q(.25),q(.75)
    return {'median':q(.5),'mode':int(np.argmax(p)),
            'central_low':lo,'central_high':hi,'central_mass':float(p[lo:hi+1].sum()),
            'at_least_ten':float(p[10:].sum()),'mean':float(np.dot(np.arange(len(p)),p))}


def explain(p):
    matrix=prediction_matrix(p)
    tip=tuple(map(int,p['tip'].split(':')))
    grid=SCORE_GRID[TIPS.index(tip)].astype(int)
    points=np.bincount(grid,weights=matrix.ravel(),minlength=5)
    k=int(np.argmax(matrix));modal=f'{k//matrix.shape[1]}:{k%matrix.shape[1]}'
    alts=sorted((x for x in p.get('alternatives',[]) if x['tip']!=p['tip']),key=lambda x:x['ep'],reverse=True)
    second=alts[0] if alts else None
    margin=max(0.,p['ep']-second['ep']) if second else None
    outcomes=[(p['prob_home'],f"Heimsieg {pretty(p['home'])}"),(p['prob_draw'],'Unentschieden'),
              (p['prob_away'],f"Auswärtssieg {pretty(p['away'])}")]
    favored=max(outcomes,key=lambda v:v[0])
    summary=f"{p['tip']} bringt im Modell {p['ep']:.2f} erwartete Punkte – der höchste Wert unter den geprüften Tipps."
    if modal!=p['tip']:
        summary+=f' Das einzeln wahrscheinlichste Ergebnis ist {modal}; die 4/2/1-Wertung bevorzugt trotzdem diesen Tipp.'
    expected_home=float(np.dot(np.arange(len(matrix)),matrix.sum(axis=1)))
    expected_away=float(np.dot(np.arange(len(matrix)),matrix.sum(axis=0)))
    if abs(expected_home-expected_away)<.3:
        qualitative=f"Ähnliche Torerwartungen ({expected_home:.2f} : {expected_away:.2f}) sprechen im Modell für ein ausgeglichenes Spiel. "
    else:
        stronger=pretty(p['home'] if expected_home>expected_away else p['away'])
        qualitative=f"{stronger} hat im Modell die höhere Torerwartung ({expected_home:.2f} : {expected_away:.2f}). "
    qualitative+=f"{p['tip']} erzielt unter der 4/2/1-Wertung die meisten erwarteten Punkte ({p['ep']:.2f})."
    if tip[0]==tip[1]:
        qualitative+=' Auch andere Remis liefern dabei noch zwei Punkte.'
    if modal!=p['tip']:
        qualitative+=f' Der wahrscheinlichste einzelne Spielstand ist {modal}; unter der Punktewertung bleibt {p["tip"]} die gewählte Empfehlung.'
    if second:
        if margin<1e-9:
            qualitative+=f" Mit {second['tip']} besteht rechnerisch Gleichstand."
        elif margin<.05:
            qualitative+=f" Knappe Wahl: {second['tip']} liegt nur {margin:.3f} EP dahinter."
        else:
            qualitative+=f" Abstand zu {second['tip']}: {margin:.3f} EP."
    return {'points':[float(x) for x in points],'modal_score':modal,'second':second,'margin':margin,
            'qualitative':qualitative,'favored':favored[1],'favored_probability':favored[0],'summary':summary,
            'close':margin is not None and margin<.05}


def explain_round(results,stats):
    """Describe the saved forecasts; does not train or request fresh predictions."""
    if not results:return 'Für diesen Spieltag liegen noch keine Tipps vor.'
    n=len(results)
    strong=sum(p['prob_tendency']>=.60 for p in results)
    uncertain=sum(p['prob_tendency']<.45 for p in results)
    close=sum(explain(p)['close'] for p in results)
    label='Viele erkennbare Favoriten' if strong/n>=.6 else 'Gemischter Spieltag' if strong else 'Offener Spieltag'
    text=f'{label}: {strong} von {n} Tipps haben mindestens 60 % Chance auf die gewählte Tendenz; {uncertain} liegen unter 45 %. '
    text+=f"Jeder Tipp wurde für die höchste erwartete 4/2/1-Punktzahl gewählt; zusammen ergeben sie {stats['expected_points']:.2f} Expected Points. "
    if close:
        text+=f'Bei {close} von {n} Tipps ist die beste Alternative weniger als 0,05 EP entfernt – diese Entscheidungen sind besonders knapp. '
    text+='Die Summe ist ein Erwartungswert, keine zugesicherte Punktzahl.'
    return text


def safe_logo(value):
    if not isinstance(value,str):return ''
    try:url=urlsplit(value)
    except ValueError:return ''
    return value if url.scheme=='https' and url.hostname in {'upload.wikimedia.org','i.imgur.com','assets.dfb.de'} else ''


TEAM_LOGOS = {
    'paderborn':'https://upload.wikimedia.org/wikipedia/commons/6/67/SC_Paderborn_07_Logo_new.svg',
    'union':'https://upload.wikimedia.org/wikipedia/commons/4/44/1._FC_Union_Berlin_Logo.svg',
}


def team_line(name,logo):
    # Correct outdated/raster upstream crests, including already-saved forecasts.
    label=html.escape(pretty(name));url=TEAM_LOGOS.get(canonical(name),safe_logo(logo))
    icon=f'<img src="{html.escape(url,quote=True)}" alt="" loading="lazy" referrerpolicy="no-referrer">' if url else '<span class="crest-fallback">⚽</span>'
    return f'<div class="team-line"><span class="crest">{icon}</span><span>{label}</span></div>'


def phone_url():
    for interface in ('en0','en1'):
        try:
            value=subprocess.check_output(['/usr/sbin/ipconfig','getifaddr',interface],timeout=2,text=True,stderr=subprocess.DEVNULL).strip()
            ip=ipaddress.ip_address(value)
            if ip.is_private and not ip.is_loopback and not ip.is_link_local:
                return f'http://{ip}:8501'
        except (OSError,ValueError,subprocess.SubprocessError):continue
    return None


def qr_png(url):
    import qrcode
    qr=qrcode.QRCode(box_size=7,border=3,error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(url);qr.make(fit=True)
    image=qr.make_image(fill_color='#10241a',back_color='white')
    out=io.BytesIO();image.save(out,format='PNG');return out.getvalue()
