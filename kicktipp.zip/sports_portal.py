"""Monochrome home screen for the existing KickTipp and the slip tracker."""
import streamlit as st


STYLE='''<style>
.portal-hero{padding:34px 0 28px}.portal-hero h1{font-size:clamp(2.8rem,9vw,5rem)!important;line-height:1.02;letter-spacing:-.065em;margin:16px 0}.portal-hero p{color:var(--kt-muted);font-size:1rem;max-width:490px;line-height:1.6}.portal-kicker{font-size:.67rem;letter-spacing:.19em;font-weight:750;color:var(--kt-muted)}
.portal-card{position:relative;overflow:hidden;border:1px solid var(--kt-border);border-radius:22px;background:var(--kt-card);padding:26px;min-height:260px;margin:10px 0 0}.portal-num{font-size:.68rem;letter-spacing:.1em;color:var(--kt-muted)}.portal-card h2{font-size:2.5rem!important;letter-spacing:-.05em;margin:20px 0 8px}.portal-card p{color:var(--kt-muted);font-size:.9rem;line-height:1.5;max-width:350px}.portal-icon{position:absolute;right:22px;top:18px;font-size:3.5rem;opacity:.16}.portal-tags{display:flex;gap:7px;flex-wrap:wrap;margin-top:20px}.portal-tags span{font-size:.66rem;border:1px solid var(--kt-border);padding:6px 9px;border-radius:20px}.portal-note{border-top:1px solid var(--kt-border);padding:18px 0;color:var(--kt-muted);font-size:.75rem;margin-top:28px}
.sb-counts{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0}.sb-counts>div{border:1px solid var(--kt-border);border-radius:12px;padding:12px 9px;background:var(--kt-card)}.sb-counts small{display:block;color:var(--kt-muted);font-size:.65rem;min-height:30px}.sb-counts b{font-size:1.6rem;display:block}.sb-overview{display:grid;grid-template-columns:1fr 1fr 1.5fr;gap:18px;padding:22px;border:1px solid var(--kt-border);border-radius:18px;background:var(--kt-card);margin:20px 0}.sb-overview small{display:block;color:var(--kt-muted);font-size:.7rem;margin-bottom:8px}.sb-overview b{font-size:1.45rem;letter-spacing:-.035em;white-space:nowrap}
.sb-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:18px;padding:20px;margin:14px 0}.sb-meta{display:flex;justify-content:space-between;gap:10px;color:var(--kt-muted);font-size:.68rem;letter-spacing:.045em;margin-bottom:22px}.sb-fixture{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:center}.sb-fixture>b{font-size:1.7rem;white-space:nowrap;letter-spacing:-.04em}.sb-team{display:flex;align-items:center;gap:9px;font-size:.85rem;font-weight:650;min-width:0}.sb-team img{width:36px;height:36px;object-fit:contain;flex-shrink:0}.sb-right{justify-content:flex-end;text-align:right;flex-direction:row-reverse}.sb-pick{display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--kt-border);padding-top:18px;margin-top:22px;gap:14px}.sb-pick small{display:block;color:var(--kt-muted);font-size:.65rem;margin-bottom:5px}.sb-pick strong{font-size:.95rem}.sb-pick>b{font-size:1rem;color:var(--kt-muted)}.sb-status{display:inline-block;border-radius:20px;font-size:.68rem;padding:5px 10px;margin-top:15px;font-weight:700}.sb-status.neutral{background:var(--kt-bg);color:var(--kt-muted);border:1px solid var(--kt-border)}.sb-note{color:var(--kt-muted);font-size:.77rem;line-height:1.5;margin:10px 0 0}.sb-status.green{background:#153d29;color:#a2e8b5}.sb-status.yellow{background:#463b19;color:#ffe49c}.sb-status.red{background:#42272b;color:#ffb7bc}
@media(max-width:540px){.portal-hero{padding:20px 0}.portal-card{padding:22px;min-height:235px}.sb-card{padding:16px}.sb-team{font-size:.75rem;gap:5px}.sb-team img{width:29px;height:29px}.sb-fixture{gap:7px}.sb-fixture>b{font-size:1.4rem}.sb-overview{grid-template-columns:1fr 1fr;gap:16px}.sb-overview>div:last-child{grid-column:1/-1}.sb-overview b{font-size:1.5rem}}
</style>'''


def choose(area):
    st.session_state['portal']=area


def render_home():
    st.markdown('''<div class="portal-hero"><div class="portal-kicker">DEIN SPORT-DASHBOARD</div><h1>Ein Spieltag.<br>Alles im Blick.</h1><p>Deine Tipps. Dein Schein. Spielstände und Einordnung an einem Ort.</p></div>''',unsafe_allow_html=True)
    a,b=st.columns(2,gap='medium')
    with a:
        st.markdown('''<div class="portal-card"><div class="portal-num">01 / BUNDESLIGA</div><div class="portal-icon">⚽</div><h2>KickTipp</h2><p>Ein Knopf für deine Spieltagstipps. Expected Points, Chance-Ampel und der Deep Dive nach Abpfiff.</p><div class="portal-tags"><span>Optimierer</span><span>Live-Spieltag</span><span>Rückblick</span></div></div>''',unsafe_allow_html=True)
        st.button('KickTipp öffnen →',key='open_kicktipp',on_click=choose,args=('KickTipp',),type='primary',width='stretch')
    with b:
        st.markdown('''<div class="portal-card"><div class="portal-num">02 / NFL & FUSSBALL</div><div class="portal-icon">🏈</div><h2>SportBet</h2><p>Deine 13er-Kombi als Live-Tracker. Spielstände, Grenzen und die Partien, die gerade Aufmerksamkeit brauchen.</p><div class="portal-tags"><span>13 Auswahlen</span><span>Teamlogos</span><span>Spielstatistiken</span></div></div>''',unsafe_allow_html=True)
        st.button('SportBet öffnen →',key='open_sportbet',on_click=choose,args=('SportBet',),type='primary',width='stretch')
    st.markdown('<div class="portal-note">Auf deinem iPhone und am Computer · Schwarz oder weiß nach deiner Darstellung · Online ohne laufenden Mac</div>',unsafe_allow_html=True)
