(function(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.JournalCore = api;
})(typeof window === 'undefined' ? {} : window, function() {
  'use strict';
  const AMOUNT_CENTS = 2000;
  const KEY = 'kicktipp.nichtgewettet.v1';
  function validDay(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const dt = new Date(value+'T12:00:00Z');
    return Number.isFinite(dt.getTime()) && dt.toISOString().slice(0,10) === value;
  }
  function validate(value, today) {
    if (!validDay(today)) throw new Error('Das heutige Datum ist nicht verfügbar.');
    if (!value || value.version !== 1 || !Array.isArray(value.days) || value.days.length > 3660)
      throw new Error('Das ist kein gültiges Tagebuch-Backup.');
    if (Object.keys(value).some(k => !['version','days'].includes(k)))
      throw new Error('Das Backup enthält unbekannte Felder.');
    if (value.days.some(day => !validDay(day) || day > today || day < '2020-01-01'))
      throw new Error('Das Backup enthält ungültige oder zukünftige Tage.');
    return {version:1, days:Array.from(new Set(value.days)).sort()};
  }
  function read(storage, today) {
    const raw = storage.getItem(KEY);
    if (raw === null) return {version:1, days:[]};
    if (raw.length > 100000) throw new Error('Der gespeicherte Verlauf ist zu groß.');
    let data;
    try { data = JSON.parse(raw); } catch (_) { throw new Error('Der gespeicherte Verlauf ist beschädigt. Er wurde nicht überschrieben.'); }
    return validate(data, today);
  }
  function commit(storage, value, today) {
    const checked = validate(value, today);
    storage.setItem(KEY, JSON.stringify(checked));
    return checked;
  }
  function mark(storage, today) {
    const value = read(storage, today);
    return commit(storage, {version:1, days:value.days.concat(today)}, today);
  }
  function undo(storage, today) {
    const value = read(storage, today);
    return commit(storage, {version:1, days:value.days.filter(d => d !== today)}, today);
  }
  function merge(storage, incoming, today) {
    const current = read(storage, today), checked = validate(incoming, today);
    return commit(storage, {version:1, days:current.days.concat(checked.days)}, today);
  }
  function stats(value) {
    return {days:value.days.length, amountCents:value.days.length*AMOUNT_CENTS};
  }
  return {KEY, AMOUNT_CENTS, validDay, validate, read, mark, undo, merge, stats};
});
