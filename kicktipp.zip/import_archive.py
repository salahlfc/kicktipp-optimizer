#!/usr/bin/env python3
"""Import OpenFootball/deutschland GitHub ZIP directly, without network or extraction."""
import argparse
from pathlib import Path
from zipfile import ZipFile
from openfootball_import import parse_openfootball

def import_zip(archive,output_dir,first=2015,last=2025):
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    converted=[]
    with ZipFile(archive) as z:
        names=z.namelist()
        for year in range(first,last+1):
            season=f'{year}-{(year+1)%100:02d}'
            suffix=f'/{season}/1-bundesliga.txt'
            found=[name for name in names if name.endswith(suffix)]
            if len(found)!=1:raise ValueError(f'ZIP: exactly one {suffix} expected; found {len(found)}')
            raw=z.read(found[0]).decode('utf-8-sig')
            df=parse_openfootball(raw,year,strict=year<=2025)
            if df.empty: raise ValueError(f'No results for {year}/{year+1}')
            path=dest/f'D1_{year}_{year+1}.csv'
            df.to_csv(path,index=False)
            converted.append((year,len(df),path))
    return converted

def main():
    p=argparse.ArgumentParser(description='Import historical OpenFootball archive ZIP directly')
    p.add_argument('archive');p.add_argument('--data',default='data')
    p.add_argument('--first',type=int,default=2015);p.add_argument('--last',type=int,default=2025)
    a=p.parse_args()
    for year,count,path in import_zip(a.archive,a.data,a.first,a.last):
        print(f'{year}/{year+1}: {count} games -> {path}')
if __name__=='__main__':main()
