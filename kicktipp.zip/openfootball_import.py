#!/usr/bin/env python3
"""Import public-domain OpenFootball Bundesliga TXT archive into engine-compatible CSV.

This downloader uses https://github.com/openfootball/deutschland (public domain).
Results only. Forecasts must never ingest matches after their prediction cutoff.
"""
from __future__ import annotations
import argparse
import re
from datetime import datetime
from pathlib import Path
import pandas as pd

SOURCE='https://raw.githubusercontent.com/openfootball/deutschland/master/{season}/1-bundesliga.txt'
DATE=re.compile(r'^\s*(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+([A-Z][a-z]{2})\s+(\d{1,2})(?:\s+(20\d\d))?\s*$')
TIME=r'(?:\d{1,2}:\d\d\s+)?'
ANNOTATION=re.compile(r'\s+\[awarded\]\s*$', re.IGNORECASE)
# 2015-2021 source layout: team v team 2-1 (1-0)
OLD=re.compile(r'^\s*'+TIME+r'(.+?)\s+v\s+(.+?)\s+(\d+)-(\d+)(?:\s+\(\d+-\d+\))?\s*$')
# 2022+ layout: team 2-1 (1-0) team
NEW=re.compile(r'^\s*'+TIME+r'(.+?)\s{2,}(\d+)-(\d+)(?:\s+\(\d+-\d+\))?\s{2,}(.+?)\s*$')

def parse_openfootball(raw:str, season:int, *, strict=True):
    """Return Date/HomeTeam/AwayTeam/FTHG/FTAG. No pre-match fixtures or score details."""
    games=[];cur_date=None;last_month=None;year=season
    for lineno,line in enumerate(raw.splitlines(),1):
        m=DATE.match(line)
        if m:
            month=datetime.strptime(m.group(1),'%b').month
            day=int(m.group(2))
            year=int(m.group(3)) if m.group(3) else (season if month>=7 else season+1)
            cur_date=pd.Timestamp(year,month,day)
            if season!= (year if month>=7 else year-1):
                raise ValueError(f'Line {lineno}: Date does not belong to {season}/{season+1}: {cur_date}')
            last_month=month
            continue
        if cur_date is None:continue
        # Awarded results are official scores; the marker is not a team name.
        line=ANNOTATION.sub('',line)
        m=OLD.match(line)
        if m:
            home,away,hg,ag=m.groups()
        else:
            # Never reinterpret an unrecognized old-layout fixture as a team.
            if re.search(r'\s+v\s+',line):continue
            m=NEW.match(line)
            if not m:continue
            home,hg,ag,away=m.groups()
        home=home.strip();away=away.strip()
        if not home or not away or home==away: raise ValueError(f'Invalid teams at line {lineno}')
        games.append({'Date':cur_date.date().isoformat(),'HomeTeam':home,'AwayTeam':away,
                      'FTHG':int(hg),'FTAG':int(ag)})
    df=pd.DataFrame(games,columns=['Date','HomeTeam','AwayTeam','FTHG','FTAG'])
    if strict:
        if len(df)!=306:raise ValueError(f'{season}/{season+1}: found {len(df)} finished games, expected 306. Refusing incomplete historical data')
        if df.duplicated(['Date','HomeTeam','AwayTeam']).any():raise ValueError('Duplicate game')
        teams=set(df.HomeTeam)|set(df.AwayTeam)
        if len(teams)!=18:raise ValueError(f'Expected 18 teams, found {len(teams)}: {teams}')
        for t in teams:
            if ((df.HomeTeam==t).sum(),(df.AwayTeam==t).sum())!=(17,17):
                raise ValueError(f'Unbalanced home/away schedule for {t}')
    return df

def convert_one(season,folder,*,download=False,txt_dir=None,strict=True):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    rawfile=(Path(txt_dir) if txt_dir else folder)/f'openfootball_{season}_{season+1}.txt'
    target=folder/f'D1_{season}_{season+1}.csv'
    if not rawfile.exists():
        if not download:raise FileNotFoundError(f'Place TXT at {rawfile} or use --download on internet-connected PC')
        import requests
        url=SOURCE.format(season=f'{season}-{(season+1)%100:02d}')
        response=requests.get(url,timeout=25,headers={'User-Agent':'Bundesliga-private-research/1.0'})
        response.raise_for_status()
        rawfile.parent.mkdir(parents=True,exist_ok=True)
        rawfile.write_bytes(response.content)
    txt=rawfile.read_text(encoding='utf-8-sig')
    df=parse_openfootball(txt,season,strict=strict)
    if len(df)==0:raise ValueError('No completed match results in source')
    df.to_csv(target,index=False)
    return target,len(df)

def main():
    p=argparse.ArgumentParser(description='Public domain OpenFootball Bundesliga TXT importer')
    p.add_argument('--data',default='data');p.add_argument('--first',type=int,default=2015)
    p.add_argument('--last',type=int,default=2025);p.add_argument('--download',action='store_true')
    p.add_argument('--txt-dir',default=None)
    a=p.parse_args()
    for year in range(a.first,a.last+1):
        try:
            path,n=convert_one(year,a.data,download=a.download,txt_dir=a.txt_dir,strict=year<=2025)
            print(f'OK: {year}/{year+1}: {n} matches -> {path}',flush=True)
        except Exception as e:
            print(f'FAILED: {year}/{year+1}: {e}',flush=True)
            raise
if __name__=='__main__':main()
