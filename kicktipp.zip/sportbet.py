"""Read-only tracking of the user's existing slip. No betting actions or forecasts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import urlsplit
import html,json,math,re
import pandas as pd
import requests
import streamlit as st

ROOT=Path(__file__).resolve().parent
BASE='https://site.api.espn.com/apis/site/v2/sports/'
LEAGUES={'football/nfl','soccer/ger.1','soccer/esp.1'}

def load_slip():
    return json.loads((ROOT/'data/sportbet_slip.json').read_text())


def euro(value):
    return f'{value:,.2f}'.replace(',','X').replace('.',',').replace('X','.')+' €'


def safe_logo(value):
    parts=urlsplit(value or '')
    return value if parts.scheme=='https' and parts.hostname=='a.espncdn.com' else ''


def selection(leg):
    if leg['market']=='winner':
        return next(t['name'] for t in (leg['home'],leg['away']) if t['id']==leg['selected_team_id'])+' gewinnt'
    return ('Mehr als ' if leg['market']=='over' else 'Weniger als ')+str(leg['line']).replace('.',',')


def parse_event(event,leg):
    """Pin BOTH participants and event ID; never match by a similar name."""
    if str(event.get('id'))!=leg['event_id']:raise ValueError('Andere Begegnung')
    competitions=event.get('competitions',[])
    if len(competitions)!=1:raise ValueError('Uneindeutige Begegnung')
    comp=competitions[0];sides={c['homeAway']:c for c in comp['competitors']}
    if set(sides)!={'home','away'}:raise ValueError('Unvollständige Paarung')
    if any(str(sides[k]['team']['id'])!=leg[k]['id'] for k in sides):raise ValueError('Andere Teams')
    status=comp.get('status') or event.get('status') or {}
    typ=status.get('type',{});state=typ.get('state','unknown')
    special=any(token in typ.get('name','').upper() for token in ('POSTPON','CANCEL','DELAY','SUSPEND','ABANDON'))
    if special:state='unknown'
    completed=state=='post' and typ.get('completed') is True and not special
    if state=='post' and not completed:state='unknown'
    scores={}
    for side,c in sides.items():
        raw=c.get('score')
        if isinstance(raw,dict):raw=raw.get('value')
        text=str(raw)
        scores[side]=int(text) if re.fullmatch(r'\d{1,3}',text) and int(text)<=200 else None
    if state=='pre':scores={'home':None,'away':None}
    stats={side:{v['name']:str(v.get('displayValue','–')) for v in c.get('statistics',[]) if v.get('name')} for side,c in sides.items()}
    records={side:next((r.get('summary') for r in c.get('records',[]) if r.get('type')=='total'),None) for side,c in sides.items()}
    return {'id':leg['event_id'],'state':state,'completed':completed,'scores':scores,'clock':str(status.get('displayClock','')),
            'period':status.get('period',0),'detail':str(typ.get('shortDetail','')),'kickoff':event.get('date',leg['kickoff']),
            'statistics':stats,'records':records}


@st.cache_data(ttl=60,show_spinner=False)
def fetch_boards():
    slip=load_slip();keys=sorted({(p['league'],p['scoreboard_date']) for p in slip['legs']})
    def fetch(key):
        league,date=key
        try:
            if league not in LEAGUES:raise ValueError('Unbekannte Liga')
            r=requests.get(BASE+league+'/scoreboard',params={'dates':date,'limit':100},timeout=(3,8))
            r.raise_for_status()
            if len(r.content)>3_000_000:raise ValueError('Zu große Antwort')
            events=r.json()['events']
            if not isinstance(events,list):raise ValueError('Unbekanntes Format')
            return league,{'ok':True,'events':events,'checked_at':datetime.now(timezone.utc).isoformat()}
        except (requests.RequestException,ValueError,KeyError,TypeError):
            return league,{'ok':False,'events':[],'checked_at':datetime.now(timezone.utc).isoformat()}
    with ThreadPoolExecutor(max_workers=3) as pool:
        return dict(pool.map(fetch,keys))


@st.cache_data(ttl=120,show_spinner=False)
def fetch_details(league,event_id):
    if league not in LEAGUES or not re.fullmatch(r'\d+',event_id):return None
    try:
        r=requests.get(BASE+league+'/summary',params={'event':event_id},timeout=(3,8));r.raise_for_status()
        if len(r.content)>3_000_000:return None
        data=r.json()
        if str(data.get('header',{}).get('id'))!=event_id:return None
        result={}
        for team in data.get('boxscore',{}).get('teams',[]):
            result[str(team['team']['id'])]={s['name']:str(s.get('displayValue','–')) for s in team.get('statistics',[]) if s.get('name')}
        return result
    except (requests.RequestException,ValueError,KeyError,TypeError):return None


def match_clock(leg,event):
    """Use the reported playing clock, never minutes since scheduled kickoff."""
    clock=str(event.get('clock') or '');period=event.get('period')
    if leg['league'].startswith('soccer/'):
        if period not in (None,0,1,2):return None
        found=re.fullmatch(r"\s*(\d{1,3})\s*['′]?(?:\s*\+\s*(\d{1,2})\s*['′]?)?\s*",clock)
        if not found:return None
        minute=int(found[1])+int(found[2] or 0)
        if not 0<=minute<=120:return None
        return {'elapsed':min(minute,90),'remaining':max(0,90-minute),'duration':90,'text':f"{minute}. Minute · ca. {max(0,90-minute)} reguläre Minuten übrig"}
    if period not in (1,2,3,4):return None
    found=re.fullmatch(r'(\d{1,2}):(\d{2})',clock)
    if not found:return None
    minutes,seconds=map(int,found.groups())
    if minutes>15 or seconds>=60 or (minutes==15 and seconds):return None
    remaining=(4-period)*15+minutes+seconds/60
    return {'elapsed':60-remaining,'remaining':remaining,'duration':60,'text':f"Q{period} · {clock} · {remaining:.1f} Spielminuten übrig"}


def shots_on_target(event):
    values=[event.get('statistics',{}).get(side,{}).get('shotsOnTarget') for side in ('home','away')]
    if any(v is None or not re.fullmatch(r'\d{1,2}',str(v)) for v in values):return None
    total=sum(map(int,values))
    return total if total>=sum(event['scores'].values()) else None


def nfl_pace(leg,event):
    """Quarter checkpoints with a linear target inside each quarter; delta > 0 is favourable."""
    if leg['league']!='football/nfl' or leg['market'] not in ('over','under') or event.get('state')!='in':return None
    clock=match_clock(leg,event)
    if clock is None or any(v is None for v in event['scores'].values()):return None
    target=math.floor(leg['line'])+(1 if leg['market']=='over' else 0)
    actual=sum(event['scores'].values());expected=target*clock['elapsed']/60
    delta=actual-expected if leg['market']=='over' else expected-actual
    color='green' if delta>=-1e-9 else 'yellow' if delta>=-7-1e-9 else 'red'
    # A crossed Under threshold is unfavourable irrespective of pace.
    if leg['market']=='under' and actual>target:color='red'
    quarters=[math.ceil(target*q/4-1e-9) if leg['market']=='over' else math.floor(target*q/4+1e-9) for q in (1,2,3,4)]
    return {'target':target,'actual':actual,'expected':expected,'delta':delta,'color':color,'quarters':quarters,
            'remaining_needed':max(0,target-actual) if leg['market']=='over' else None,
            'buffer':target-actual if leg['market']=='under' else None,'clock':clock}


def delta_sort_key(row):
    # Compare the same metric: NFL total-points pace first, then other live markets.
    if row['status']['code']=='live':
        pace=nfl_pace(row['leg'],row['event'])
        if pace is not None:return (0,pace['delta'],row['leg']['number'])
        return (1,row['status']['priority'],row['leg']['number'])
    return (2 if row['status']['code'] in ('pre','unknown') else 3,row['status']['priority'],row['leg']['number'])


def render_delta_overview(watch):
    parts=[]
    for row in watch:
        leg=row['leg'];pace=nfl_pace(leg,row['event'])
        if pace is None:continue
        title=leg['away']['short']+' – '+leg['home']['short']
        detail=selection(leg)+' · '+pace['clock']['text']
        parts.append('<div class="sb-delta-row"><div><strong>'+html.escape(title)+'</strong><small>'+html.escape(detail)+'</small></div><b>'+str(pace['actual'])+'</b><b>'+f"{pace['expected']:.1f}"+'</b><b class="sb-delta-value '+pace['color']+'">'+f"{pace['delta']:+.1f}"+'</b></div>')
    if parts:st.markdown('<div class="sb-delta-list"><div class="sb-delta-row sb-delta-head"><span>NFL · Zeitplan</span><span>Ist</span><span>Soll</span><span>Δ</span></div>'+''.join(parts)+'</div>',unsafe_allow_html=True)


def render_pace(leg,event):
    pace=nfl_pace(leg,event) if event else None
    if pace is None:return ''
    verb='Mindestens' if leg['market']=='over' else 'Maximal'
    checkpoints=' · '.join(label+' '+str(value) for label,value in zip(('Q1','Halbzeit','Q3','Ende'),pace['quarters']))
    return ('<div class="sb-pace"><div><small>Ist · Gesamtpunkte</small><b>'+str(pace['actual'])+'</b></div>'
            '<div><small>Soll zur Spielzeit</small><b>'+f"{pace['expected']:.1f}"+'</b></div>'
            '<div><small>Δ zum Soll</small><b>'+f"{pace['delta']:+.1f}"+'</b></div></div><p class="sb-note">'+verb+' zum Viertelende: '+checkpoints+'.</p>')


def live_traffic(leg,event,met,total,margin=None):
    clock=match_clock(leg,event);soccer=leg['league'].startswith('soccer/')
    color='yellow';reason='Die Auswahl ist noch offen; es bleibt abzuwarten, wie das Spiel weiterläuft.'
    remaining=clock['remaining'] if clock else None
    elapsed=clock['elapsed'] if clock else None
    pace=nfl_pace(leg,event)
    if pace is not None:
        delta=pace['delta'];color=pace['color']
        direction='vor dem' if delta>=0 else 'hinter dem'
        reason=f"Ist {pace['actual']} · Soll jetzt {pace['expected']:.1f} · Δ {delta:+.1f} Punkte: {abs(delta):.1f} Punkte {direction} Zeitplan. "
        if leg['market']=='over':reason+=f"Zum Endziel fehlen noch {pace['remaining_needed']} Punkte. "
        else:reason+=f"Puffer bis maximal {pace['target']}: {pace['buffer']} Punkte. Bei Under ist ein niedrigeres Ist günstig. "
        reason+='Je Viertel 25 % des Endziels, innerhalb des Viertels zeitanteilig. Gelb bis 7 Punkte hinter dem Soll, darüber Rot. '+pace['clock']['text']+'.'
        return color,reason
    if leg['market']=='over':
        needed=max(0,math.floor(leg['line'])+1-total)
        if met:color='green';reason='Die benötigte Tor-/Punktzahl ist bereits erreicht; die offizielle Bestätigung steht noch aus.'
        elif clock:
            critical=(remaining<=20 and needed>=2) or (remaining<=10 and needed>=1) if soccer else ((remaining<=15 and needed>=14) or (remaining<=5 and needed>7) or (remaining<=2 and needed>0))
            if not soccer and elapsed>=30 and needed>=14:
                critical=critical or needed/max(remaining,.1)>1.8*total/max(elapsed,1)
            if critical:color='red';reason='Für das noch nötige Ergebnis bleibt nur wenig Spielzeit beziehungsweise das bisherige Punktetempo reicht nicht aus.'
            else:reason='Die Grenze ist noch offen. Das nötige Ergebnis ist bei der verbleibenden Spielzeit noch nicht akut im Rückstand.'
    elif leg['market']=='under':
        buffer=math.floor(leg['line'])-total
        if not met:color='red';reason='Die Grenze ist bereits überschritten. Eine normale weitere Tor-/Punktentwicklung kann das nicht zurückdrehen.'
        elif clock:
            projected=total/max(elapsed,1)*clock['duration']
            if soccer:
                if buffer==0 and remaining>=10 and elapsed>=45:color='red';reason='Kein Torpuffer mehr, aber noch Spielzeit: Jedes weitere Tor würde die Grenze überschreiten.'
                elif remaining<=15 and buffer>=1:color='green';reason='Es bleibt wenig reguläre Spielzeit und noch Torpuffer bis zur Grenze.'
                elif elapsed>=45 and buffer>=2 and projected<leg['line']:color='green';reason='Die bisherige Torzahl liegt bei fortgeschrittenem Spiel noch mit Puffer unter der Grenze.'
            else:
                if elapsed>=30 and ((buffer<=7 and remaining>=10) or (buffer<14 and projected>leg['line']+7)):
                    color='red';reason='Wenig Puffer gegenüber der verbleibenden Spielzeit beziehungsweise dem bisherigen Punktetempo.'
                elif (remaining<=15 and buffer>=10) or (elapsed>=30 and buffer>=14 and projected<leg['line']-3):
                    color='green';reason='Das bisherige Punktetempo und der verbleibende Puffer sind aktuell günstig für diese Grenze.'
    else:
        if clock:
            if soccer:
                if (margin<0 and remaining<=15) or (margin<=0 and remaining<=10) or (margin<=-2 and remaining<=30):color='red';reason='Die gewählte Mannschaft braucht spät im Spiel noch den Ausgleich und/oder die Führung.'
                elif margin>=2 or (margin>0 and remaining<=15):color='green';reason='Die gewählte Mannschaft führt mit deutlichem Vorsprung oder bei wenig regulärer Restzeit.'
            else:
                if (margin<=-8 and remaining<=15) or (margin<=0 and remaining<=5):color='red';reason='Die gewählte Mannschaft muss bei wenig verbleibender Spielzeit noch zurückkommen.'
                elif (margin>=14 and elapsed>=15) or (margin>=8 and remaining<=15):color='green';reason='Die gewählte Mannschaft hat aktuell einen deutlichen Vorsprung im Verhältnis zur Spielzeit.'
        if color=='yellow':reason='Knappe Führung, Gleichstand oder noch genügend Zeit für eine Wende: Die Spielrichtung bleibt offen.'
    shots=shots_on_target(event) if soccer else None
    if shots is not None and shots>=8 and leg['market']=='under' and color=='green':
        color='yellow';reason='Trotz Torpuffer gibt es viele Abschlüsse aufs Tor. Die günstige Zeiteinschätzung wird deshalb vorsichtiger bewertet.'
    if shots is not None:reason+=f' Bisher {shots} Schüsse aufs Tor insgesamt.'
    if clock:reason+=' '+clock['text']+'.'
    else:reason+=' Keine verlässliche reguläre Restzeit gemeldet; ohne sie bleibt die Einschätzung vorsichtig.'
    return color,reason


def leg_status(leg,event=None):
    out={'code':'unknown','label':'Daten nicht verfügbar','color':'neutral','note':'Kein verifizierter aktueller Spielstand.','priority':4,'fulfilled':False}
    if event is None:return out
    state=event['state'];scores=event['scores'];finished=event['completed']
    if state=='pre':return dict(out,code='pre',label='Noch offen',note='Wartet auf den Anpfiff.',priority=3)
    if state not in ('in','post') or any(v is None for v in scores.values()):return out
    total=sum(scores.values());soccer=leg['league'].startswith('soccer/')
    if leg['market']=='winner':
        side='home' if leg['home']['id']==leg['selected_team_id'] else 'away'
        other='away' if side=='home' else 'home';margin=scores[side]-scores[other];met=margin>0
        note=f"{leg[side]['short']} liegt {abs(margin)} {'Tore' if soccer else 'Punkte'} {'vorn' if margin>0 else 'zurück'}." if margin else 'Aktuell Gleichstand.'
        label='Führt' if met else 'Gleichstand' if not margin else 'Liegt zurück'

    else:
        line=leg['line'];met=total>line if leg['market']=='over' else total<line
        if leg['market']=='over':
            remaining=max(0,math.floor(line)+1-total)
            note=f"Gesamt {total} · noch {remaining} {'Tore' if soccer else 'Punkte'} bis zur Grenze." if remaining else f'Gesamt {total} · Grenze überschritten.'
            label='Schwelle erreicht' if met else 'Schwelle noch offen'
        else:
            buffer=math.floor(line)-total
            note=f"Gesamt {total} · Puffer {buffer} {'Tore' if soccer else 'Punkte'} bis maximal {math.floor(line)}." if buffer>=0 else f'Gesamt {total} · Grenze bereits überschritten.'
            label='Unter der Grenze' if met else 'Grenze überschritten'
    if finished:
        return dict(out,code='won' if met else 'lost',label='Erfüllt' if met else 'Nicht erfüllt',color='green' if met else 'red',note=note,priority=6 if met else 5,fulfilled=met)
    color,reason=live_traffic(leg,event,met,total,margin if leg['market']=='winner' else None)
    return dict(out,code='live',label=label,color=color,note=note+' '+reason+' Zwischenstand, noch kein Endergebnis.',reason=reason,priority={'red':0,'yellow':1,'green':2}[color])


def traffic_summary(rows):
    counts={color:sum(r['status']['color']==color for r in rows) for color in ('green','yellow','red','neutral')}
    live=[r for r in rows if r['status']['code']=='live']
    lost=sum(r['status']['code']=='lost' for r in rows)
    won=sum(r['status']['code']=='won' for r in rows)
    if lost:color='red';title='Mindestens eine Auswahl ist nicht erfüllt'
    elif any(r['status']['color']=='red' for r in live):color='red';title='Einige laufende Spiele sind kritisch'
    elif any(r['status']['color']=='yellow' for r in live):color='yellow';title='Noch offen · laufende Spiele im Blick behalten'
    elif live:color='green';title='Laufende Spiele aktuell günstig'
    elif won==len(rows) and rows:color='green';title='Alle Auswahlen laut Endstand erfüllt'
    elif won:color='yellow';title='Erste Auswahlen erfüllt · Rest noch offen'
    else:color='neutral';title='Noch keine Live-Einschätzung möglich'
    return {'counts':counts,'color':color,'title':title}


def render_traffic_summary(rows):
    summary=traffic_summary(rows);counts=summary['counts']
    st.markdown('<div class="sb-traffic-summary"><div class="sb-status '+summary['color']+'">'+html.escape(summary['title'])+'</div><div class="sb-traffic-counts">'+''.join('<div><span class="sb-dot '+color+'"></span><b>'+str(counts[color])+'</b><small>'+label+'</small></div>' for color,label in [('green','Grün'),('yellow','Gelb'),('red','Rot')])+'</div><p class="sb-note">'+str(counts['neutral'])+' noch nicht angepfiffen oder ohne verifizierte Daten · Die Gesamtampel richtet sich nach kritischen Auswahlen, nicht nach einem Durchschnitt.</p></div>',unsafe_allow_html=True)
    st.caption('Grün: aktuell günstig oder erfüllt · Gelb: offen / knapp · Rot: zeitlich kritisch oder nicht erfüllt. Zeit-/Spielstandsregeln, keine berechnete Gewinnchance. Fußball ohne vorhersehbare Nachspielzeit; fehlende Uhr und Verlängerung werden vorsichtig behandelt.')


def rows_for(slip,boards):
    rows=[]
    for leg in slip['legs']:
        board=boards.get(leg['league'],{});event=None
        matching=[e for e in board.get('events',[]) if str(e.get('id'))==leg['event_id']] if board.get('ok') else []
        if len(matching)==1:
            try:event=parse_event(matching[0],leg)
            except (ValueError,KeyError,TypeError):pass
        rows.append({'leg':leg,'event':event,'status':leg_status(leg,event),'checked_at':board.get('checked_at')})
    return rows


def team_html(team):
    logo=safe_logo(team.get('logo'))
    return ('<img src="'+html.escape(logo,quote=True)+'" alt="" loading="lazy">' if logo else '')+'<span>'+html.escape(team['short'])+'</span>'


def render_card(row):
    p=row['leg'];e=row['event'];s=row['status'];esc=html.escape
    date=pd.Timestamp((e or {}).get('kickoff',p['kickoff'])).tz_convert('Europe/Berlin').strftime('%d.%m. · %H:%M')
    score=f"{e['scores']['away']} : {e['scores']['home']}" if e and all(v is not None for v in e['scores'].values()) else '– : –'
    clock=(e.get('detail') or e.get('clock') or 'Live') if e and e['state']=='in' else 'Beendet' if e and e['completed'] else date+' Uhr'
    unit='Gesamtpunkte' if p['league']=='football/nfl' else 'Gesamttore'
    market='Sieg' if p['market']=='winner' else unit
    st.markdown(f'''<div class="sb-card"><div class="sb-meta"><span>{'NFL' if p['league']=='football/nfl' else 'BUNDESLIGA' if p['league']=='soccer/ger.1' else 'LA LIGA'} · {esc(clock)}</span><span>#{p['number']:02d}</span></div><div class="sb-fixture"><div class="sb-team">{team_html(p['away'])}</div><b>{score}</b><div class="sb-team sb-right">{team_html(p['home'])}</div></div><div class="sb-pick"><div><small>{market}</small><strong>{esc(selection(p))}</strong></div><b>{p['odds']:.2f}</b></div><div class="sb-status {s['color']}">{esc(({'green':'🟢 Grün · ','yellow':'🟡 Gelb · ','red':'🔴 Rot · '}.get(s['color'],''))+s['label'])}</div><p class="sb-note">{esc(s['note'])}</p>{render_pace(p,e)}</div>''',unsafe_allow_html=True)


@st.fragment(run_every=60)
def render():
    slip=load_slip()
    st.markdown('<div class="eyebrow">SPORTBET / LIVE TRACKER</div>',unsafe_allow_html=True)
    st.title('Dein Schein. Alles im Blick.')
    st.caption('13 Auswahlen · NFL & Fußball · 08. November 2026')
    if st.button('Spielstände aktualisieren',key='refresh_sportbet',width='stretch'):fetch_boards.clear();fetch_details.clear()
    with st.spinner('Spielstände abgleichen …'):boards=fetch_boards()
    rows=rows_for(slip,boards)
    render_traffic_summary(rows)
    won=sum(r['status']['code']=='won' for r in rows);lost=sum(r['status']['code']=='lost' for r in rows)
    live=sum(r['status']['code']=='live' for r in rows);unknown=sum(r['status']['code']=='unknown' for r in rows)
    st.markdown(f'''<div class="sb-overview"><div><small>Einsatz</small><b>{euro(slip['stake'])}</b></div><div><small>Gesamtquote</small><b>{slip['display_odds']:.2f}</b></div><div><small>Mögliche Auszahlung laut Schein</small><b>{euro(slip['possible_payout'])}</b></div></div>''',unsafe_allow_html=True)
    counts=[('Live',live),('Erfüllt',won),('Nicht erfüllt',lost),('Noch offen',sum(r['status']['code']=='pre' for r in rows))]
    st.markdown('<div class="sb-counts">'+''.join(f'<div><small>{label}</small><b>{value}</b></div>' for label,value in counts)+'</div>',unsafe_allow_html=True)
    if lost:st.info('Mindestens eine Auswahl ist laut gemeldetem Endstand nicht erfüllt. Die übrigen Spiele bleiben im Tracker sichtbar.')
    if unknown:st.warning(f'{unknown} Begegnungen gerade ohne verifizierte Daten. Unbekannte Spielstände werden nicht als 0:0 oder erfüllt gewertet.')
    checked=[v['checked_at'] for v in boards.values() if v.get('ok')]
    if checked:st.caption('ESPN · Abgleich '+pd.Timestamp(min(checked)).tz_convert('Europe/Berlin').strftime('%d.%m. %H:%M')+' Uhr · Aktualisierung etwa jede Minute bei geöffneter Seite; Meldungen können verzögert sein.')
    watch=sorted((r for r in rows if r['status']['code']=='live'),key=delta_sort_key)
    if watch:
        st.subheader('Delta-Übersicht · größter Rückstand zuerst')
        render_delta_overview(watch)
        st.caption('NFL-Punktewetten: Grün ab Soll; Gelb bis einschließlich 7 Punkte Rückstand; darüber Rot. Soll = 25 % je Viertel, innerhalb des Viertels zeitanteilig. Δ ist bei Over Ist minus Soll, bei Under Soll minus Ist; negativ bedeutet jeweils ungünstig. Noch nötig bezieht sich auf das Endziel, nicht auf das aktuelle Soll.')
        st.subheader('Alle laufenden Spiele')
        for r in watch:
            p=r['leg'];e=r['event'];color=r['status']['color'];emoji={'red':'🔴','yellow':'🟡','green':'🟢'}[color]
            clock=match_clock(p,e)
            brief=r['status']['note'].split('. ')[0]
            pace=nfl_pace(p,e)
            if pace:brief+=f" · Ist {pace['actual']} / Soll {pace['expected']:.1f} / Δ {pace['delta']:+.1f}"
            if clock:brief+=' · '+clock['text']
            st.markdown(emoji+' **'+p['away']['short']+' – '+p['home']['short']+' · '+str(e['scores']['away'])+':'+str(e['scores']['home'])+'** · '+selection(p)+' · '+brief)
        st.caption('NFL-Punktewetten zuerst nach dem ungünstigsten Delta zum Zeitplan; andere laufende Märkte danach. Für Sieg-Auswahlen wird kein Punkte-Over-Zeitplan erfunden. Das beschreibt den Spielstand, keine Gewinnwahrscheinlichkeit.')
    st.subheader('Deine 13 Auswahlen')
    order=st.radio('Ansicht',['Delta · größter Rückstand zuerst','Reihenfolge des Scheins'],horizontal=True,key='sportbet_order',label_visibility='collapsed')
    for row in sorted(rows,key=delta_sort_key) if order=='Delta · größter Rückstand zuerst' else rows:render_card(row)
    st.subheader('Spielstatistiken')
    i=st.selectbox('Spiel genauer ansehen',range(len(rows)),format_func=lambda i:rows[i]['leg']['away']['short']+' – '+rows[i]['leg']['home']['short'],key='sportbet_detail')
    row=rows[i];leg=row['leg'];event=row['event']
    if event and event['state']=='pre':
        records=event['records'];st.caption('Saisonbilanz laut Datenquelle: '+leg['away']['short']+' '+str(records.get('away') or '–')+' · '+leg['home']['short']+' '+str(records.get('home') or '–')+'. Spielstatistiken erscheinen nach Spielbeginn.')
    elif event and event['state'] in ('in','post'):
        stats=event['statistics'];extra=fetch_details(leg['league'],leg['event_id']) or {}
        stats={side:{**stats.get(side,{}),**extra.get(leg[side]['id'],{})} for side in ('away','home')}
        fields=[('totalYards','Yards gesamt'),('netPassingYards','Pass-Yards'),('rushingYards','Lauf-Yards'),('turnovers','Ballverluste'),('firstDowns','First Downs'),('possessionTime','Ballbesitzzeit')] if leg['league']=='football/nfl' else [('totalShots','Schüsse'),('shotsOnTarget','Schüsse aufs Tor'),('possessionPct','Ballbesitz (%)'),('wonCorners','Ecken'),('foulsCommitted','Fouls')]
        table=[{'Statistik':label,leg['away']['short']:stats['away'].get(key,'–'),leg['home']['short']:stats['home'].get(key,'–')} for key,label in fields if key in stats['away'] or key in stats['home']]
        if table:st.markdown('<div class="data-table">'+pd.DataFrame(table).to_html(index=False,escape=True,border=0)+'</div>',unsafe_allow_html=True)
        else:st.caption('Für diese Partie sind derzeit keine verifizierten Detailstatistiken verfügbar.')
    else:st.caption('Die Detailstatistik wartet auf verifizierte Spieldaten.')
    with st.expander('Schein & Status verstehen'):
        st.write('Bei NFL-Punktewetten folgt die Ampel einem Viertelplan: 25 % des Endziels pro Viertel, innerhalb eines Viertels zeitanteilig. Over ist ab Soll grün, bis 7 Punkte hinter Soll gelb, darüber rot. Under wird umgekehrt gerechnet: Weniger Punkte als das zeitanteilige Maximum sind günstig. Sieg-Wetten folgen weiter Spielrichtung und Restzeit, Fußball seinen Tor- und Zeitregeln. Eine fehlende Spieluhr wird nicht durch die Uhrzeit ersetzt. Sie ist kein kalibriertes Prognosemodell. Eine Gesamtampel wird durch kritische Auswahlen bestimmt, nicht aus den Farben gemittelt. Noch nicht gestartete Spiele bleiben grau. Ohne verlässliche Uhr und in einer Verlängerung bleibt eine offene Auswahl vorsichtig gelb; bereits überschrittene Grenzen werden weiterhin berücksichtigt. Die Auswahlen und Quoten stammen aus deinem Screenshot. Die Zuordnung wurde anhand von Spieltermin und beiden Team-IDs geprüft. Teamreihenfolge: auswärts links, Heimteam rechts. Eine während des Spiels erfüllte Grenze ist noch kein abgerechneter Gewinn. Der Tracker verwendet den gemeldeten Endstand; für Verlängerung, Spielabbruch, Annullierung und Auszahlung gelten die Regeln deines Buchmachers. Es werden keine Wetten abgegeben und keine Cashout-Werte oder Gewinnwahrscheinlichkeiten berechnet.')
        product=math.prod(p['odds'] for p in slip['legs'])
        st.caption(f"13 Einzelquoten ergeben ungerundet {product:.6f}; die Auszahlung wird wie auf dem Screenshot mit {euro(slip['possible_payout'])} angezeigt. Die spätere tatsächliche Abrechnung kann abweichen.")
