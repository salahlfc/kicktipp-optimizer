"""Read-only tracking of the user's existing slip. No betting actions or forecasts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import urlsplit
import html,json,math,re
import pandas as pd
import requests
import streamlit as st

ROOT=Path(__file__).resolve().parent
BASE='https://site.api.espn.com/apis/site/v2/sports/'
LEAGUES={'football/nfl','soccer/ger.1','soccer/esp.1'}

def load_slip():
    return json.loads((ROOT/'data/sportbet_slip.json').read_text())


def euro(value):
    return f'{value:,.2f}'.replace(',','X').replace('.',',').replace('X','.')+' €'


def safe_logo(value):
    parts=urlsplit(value or '')
    return value if parts.scheme=='https' and parts.hostname=='a.espncdn.com' else ''


def selection(leg):
    if leg['market']=='winner':
        return next(t['name'] for t in (leg['home'],leg['away']) if t['id']==leg['selected_team_id'])+' gewinnt'
    return ('Mehr als ' if leg['market']=='over' else 'Weniger als ')+str(leg['line']).replace('.',',')


def parse_event(event,leg):
    """Pin BOTH participants and event ID; never match by a similar name."""
    if str(event.get('id'))!=leg['event_id']:raise ValueError('Andere Begegnung')
    competitions=event.get('competitions',[])
    if len(competitions)!=1:raise ValueError('Uneindeutige Begegnung')
    comp=competitions[0];sides={c['homeAway']:c for c in comp['competitors']}
    if set(sides)!={'home','away'}:raise ValueError('Unvollständige Paarung')
    if any(str(sides[k]['team']['id'])!=leg[k]['id'] for k in sides):raise ValueError('Andere Teams')
    status=comp.get('status') or event.get('status') or {}
    typ=status.get('type',{});state=typ.get('state','unknown')
    special=any(token in typ.get('name','').upper() for token in ('POSTPON','CANCEL','DELAY','SUSPEND','ABANDON'))
    if special:state='unknown'
    completed=state=='post' and typ.get('completed') is True and not special
    if state=='post' and not completed:state='unknown'
    scores={}
    for side,c in sides.items():
        raw=c.get('score')
        if isinstance(raw,dict):raw=raw.get('value')
        text=str(raw)
        scores[side]=int(text) if re.fullmatch(r'\d{1,3}',text) and int(text)<=200 else None
    if state=='pre':scores={'home':None,'away':None}
    stats={side:{v['name']:str(v.get('displayValue','–')) for v in c.get('statistics',[]) if v.get('name')} for side,c in sides.items()}
    records={side:next((r.get('summary') for r in c.get('records',[]) if r.get('type')=='total'),None) for side,c in sides.items()}
    return {'id':leg['event_id'],'state':state,'completed':completed,'scores':scores,'clock':str(status.get('displayClock','')),
            'period':status.get('period',0),'detail':str(typ.get('shortDetail','')),'kickoff':event.get('date',leg['kickoff']),
            'statistics':stats,'records':records}


@st.cache_data(ttl=60,show_spinner=False)
def fetch_boards():
    slip=load_slip();keys=sorted({(p['league'],p['scoreboard_date']) for p in slip['legs']})
    def fetch(key):
        league,date=key
        try:
            if league not in LEAGUES:raise ValueError('Unbekannte Liga')
            r=requests.get(BASE+league+'/scoreboard',params={'dates':date,'limit':100},timeout=(3,8))
            r.raise_for_status()
            if len(r.content)>3_000_000:raise ValueError('Zu große Antwort')
            events=r.json()['events']
            if not isinstance(events,list):raise ValueError('Unbekanntes Format')
            return league,{'ok':True,'events':events,'checked_at':datetime.now(timezone.utc).isoformat()}
        except (requests.RequestException,ValueError,KeyError,TypeError):
            return league,{'ok':False,'events':[],'checked_at':datetime.now(timezone.utc).isoformat()}
    with ThreadPoolExecutor(max_workers=3) as pool:
        return dict(pool.map(fetch,keys))


@st.cache_data(ttl=120,show_spinner=False)
def fetch_details(league,event_id):
    if league not in LEAGUES or not re.fullmatch(r'\d+',event_id):return None
    try:
        r=requests.get(BASE+league+'/summary',params={'event':event_id},timeout=(3,8));r.raise_for_status()
        if len(r.content)>3_000_000:return None
        data=r.json()
        if str(data.get('header',{}).get('id'))!=event_id:return None
        result={}
        for team in data.get('boxscore',{}).get('teams',[]):
            result[str(team['team']['id'])]={s['name']:str(s.get('displayValue','–')) for s in team.get('statistics',[]) if s.get('name')}
        return result
    except (requests.RequestException,ValueError,KeyError,TypeError):return None


def match_clock(leg,event):
    """Use the reported playing clock, never minutes since scheduled kickoff."""
    clock=str(event.get('clock') or '');period=event.get('period')
    if leg['league'].startswith('soccer/'):
        if period not in (None,0,1,2):return None
        found=re.fullmatch(r"\s*(\d{1,3})\s*['′]?(?:\s*\+\s*(\d{1,2})\s*['′]?)?\s*",clock)
        if not found:return None
        minute=int(found[1])+int(found[2] or 0)
        if not 0<=minute<=120:return None
        return {'elapsed':min(minute,90),'remaining':max(0,90-minute),'duration':90,'text':f"{minute}. Minute · ca. {max(0,90-minute)} reguläre Minuten übrig"}
    if period not in (1,2,3,4):return None
    found=re.fullmatch(r'(\d{1,2}):(\d{2})',clock)
    if not found:return None
    minutes,seconds=map(int,found.groups())
    if minutes>15 or seconds>=60 or (minutes==15 and seconds):return None
    remaining=(4-period)*15+minutes+seconds/60
    return {'elapsed':60-remaining,'remaining':remaining,'duration':60,'text':f"Q{period} · {clock} · {remaining:.1f} Spielminuten übrig"}


def shots_on_target(event):
    values=[event.get('statistics',{}).get(side,{}).get('shotsOnTarget') for side in ('home','away')]
    if any(v is None or not re.fullmatch(r'\d{1,2}',str(v)) for v in values):return None
    total=sum(map(int,values))
    return total if total>=sum(event['scores'].values()) else None


def nfl_pace(leg,event):
    """Completed five-minute checkpoints; delta > 0 is favourable."""
    if leg['league']!='football/nfl' or leg['market'] not in ('over','under') or event.get('state')!='in':return None
    clock=match_clock(leg,event)
    if clock is None or any(v is None for v in event['scores'].values()):return None
    target=math.floor(leg['line'])+(1 if leg['market']=='over' else 0)
    checkpoint=min(60,math.floor((clock['elapsed']+1e-9)/5)*5)
    actual=sum(event['scores'].values());expected=target*checkpoint/60
    delta=actual-expected if leg['market']=='over' else expected-actual
    color='green' if delta>=-1e-9 else 'yellow' if delta>=-7-1e-9 else 'red'
    # A crossed Under threshold is unfavourable irrespective of pace.
    if leg['market']=='under' and actual>target:color='red'
    quarters=[math.ceil(target*q/4-1e-9) if leg['market']=='over' else math.floor(target*q/4+1e-9) for q in (1,2,3,4)]
    return {'target':target,'actual':actual,'expected':expected,'delta':delta,'color':color,'quarters':quarters,'checkpoint':checkpoint,'per_step':target/12,
            'remaining_needed':max(0,target-actual) if leg['market']=='over' else None,
            'buffer':target-actual if leg['market']=='under' else None,'clock':clock}


def traffic_sort_key(row):
    # Explicit colour groups; keep the least favourable pace first inside each group.
    return ({"green":0,"yellow":1,"red":2,"neutral":3}[row["status"]["color"]],delta_sort_key(row))


def delta_sort_key(row):
    # Compare the same metric: NFL total-points pace first, then other live markets.
    if row['status']['code']=='live':
        pace=nfl_pace(row['leg'],row['event'])
        if pace is not None:return (0,pace['delta'],row['leg']['number'])
        return (1,row['status']['priority'],row['leg']['number'])
    return (2 if row['status']['code'] in ('pre','unknown') else 3,row['status']['priority'],row['leg']['number'])


def live_traffic(leg,event,met,total,margin=None):
    clock=match_clock(leg,event);soccer=leg['league'].startswith('soccer/')
    color='yellow';reason='Die Auswahl ist noch offen; es bleibt abzuwarten, wie das Spiel weiterläuft.'
    remaining=clock['remaining'] if clock else None
    elapsed=clock['elapsed'] if clock else None
    pace=nfl_pace(leg,event)
    if pace is not None:
        delta=pace['delta'];color=pace['color']
        direction='vor dem' if delta>=0 else 'hinter dem'
        reason=f"Ist {pace['actual']} · Soll jetzt {pace['expected']:.1f} · Δ {delta:+.1f} Punkte: {abs(delta):.1f} Punkte {direction} Zeitplan. "
        if leg['market']=='over':reason+=f"Zum Endziel fehlen noch {pace['remaining_needed']} Punkte. "
        else:reason+=f"Puffer bis maximal {pace['target']}: {pace['buffer']} Punkte. Bei Under ist ein niedrigeres Ist günstig. "
        reason+='Soll am letzten vollständigen 5-Spielminuten-Abschnitt; zwölf Abschnitte pro NFL-Spiel. Gelb bis 7 Punkte hinter dem Soll, darüber Rot. '+pace['clock']['text']+'.'
        return color,reason
    if leg['market']=='over':
        needed=max(0,math.floor(leg['line'])+1-total)
        if met:color='green';reason='Die benötigte Tor-/Punktzahl ist bereits erreicht; die offizielle Bestätigung steht noch aus.'
        elif clock:
            critical=(remaining<=20 and needed>=2) or (remaining<=10 and needed>=1) if soccer else ((remaining<=15 and needed>=14) or (remaining<=5 and needed>7) or (remaining<=2 and needed>0))
            if not soccer and elapsed>=30 and needed>=14:
                critical=critical or needed/max(remaining,.1)>1.8*total/max(elapsed,1)
            if critical:color='red';reason='Für das noch nötige Ergebnis bleibt nur wenig Spielzeit beziehungsweise das bisherige Punktetempo reicht nicht aus.'
            else:reason='Die Grenze ist noch offen. Das nötige Ergebnis ist bei der verbleibenden Spielzeit noch nicht akut im Rückstand.'
    elif leg['market']=='under':
        buffer=math.floor(leg['line'])-total
        if not met:color='red';reason='Die Grenze ist bereits überschritten. Eine normale weitere Tor-/Punktentwicklung kann das nicht zurückdrehen.'
        elif clock:
            projected=total/max(elapsed,1)*clock['duration']
            if soccer:
                if buffer==0 and remaining>=10 and elapsed>=45:color='red';reason='Kein Torpuffer mehr, aber noch Spielzeit: Jedes weitere Tor würde die Grenze überschreiten.'
                elif remaining<=15 and buffer>=1:color='green';reason='Es bleibt wenig reguläre Spielzeit und noch Torpuffer bis zur Grenze.'
                elif elapsed>=45 and buffer>=2 and projected<leg['line']:color='green';reason='Die bisherige Torzahl liegt bei fortgeschrittenem Spiel noch mit Puffer unter der Grenze.'
            else:
                if elapsed>=30 and ((buffer<=7 and remaining>=10) or (buffer<14 and projected>leg['line']+7)):
                    color='red';reason='Wenig Puffer gegenüber der verbleibenden Spielzeit beziehungsweise dem bisherigen Punktetempo.'
                elif (remaining<=15 and buffer>=10) or (elapsed>=30 and buffer>=14 and projected<leg['line']-3):
                    color='green';reason='Das bisherige Punktetempo und der verbleibende Puffer sind aktuell günstig für diese Grenze.'
    else:
        if clock:
            if soccer:
                if (margin<0 and remaining<=15) or (margin<=0 and remaining<=10) or (margin<=-2 and remaining<=30):color='red';reason='Die gewählte Mannschaft braucht spät im Spiel noch den Ausgleich und/oder die Führung.'
                elif margin>=2 or (margin>0 and remaining<=15):color='green';reason='Die gewählte Mannschaft führt mit deutlichem Vorsprung oder bei wenig regulärer Restzeit.'
            else:
                if (margin<=-8 and remaining<=15) or (margin<=0 and remaining<=5):color='red';reason='Die gewählte Mannschaft muss bei wenig verbleibender Spielzeit noch zurückkommen.'
                elif (margin>=14 and elapsed>=15) or (margin>=8 and remaining<=15):color='green';reason='Die gewählte Mannschaft hat aktuell einen deutlichen Vorsprung im Verhältnis zur Spielzeit.'
        if color=='yellow':reason='Knappe Führung, Gleichstand oder noch genügend Zeit für eine Wende: Die Spielrichtung bleibt offen.'
    shots=shots_on_target(event) if soccer else None
    if shots is not None and shots>=8 and leg['market']=='under' and color=='green':
        color='yellow';reason='Trotz Torpuffer gibt es viele Abschlüsse aufs Tor. Die günstige Zeiteinschätzung wird deshalb vorsichtiger bewertet.'
    if shots is not None:reason+=f' Bisher {shots} Schüsse aufs Tor insgesamt.'
    if clock:reason+=' '+clock['text']+'.'
    else:reason+=' Keine verlässliche reguläre Restzeit gemeldet; ohne sie bleibt die Einschätzung vorsichtig.'
    return color,reason


def leg_status(leg,event=None):
    out={'code':'unknown','label':'Daten nicht verfügbar','color':'neutral','note':'Kein verifizierter aktueller Spielstand.','priority':4,'fulfilled':False}
    if event is None:return out
    state=event['state'];scores=event['scores'];finished=event['completed']
    if state=='pre':return dict(out,code='pre',label='Noch offen',note='Wartet auf den Anpfiff.',priority=3)
    if state not in ('in','post') or any(v is None for v in scores.values()):return out
    total=sum(scores.values());soccer=leg['league'].startswith('soccer/')
    if leg['market']=='winner':
        side='home' if leg['home']['id']==leg['selected_team_id'] else 'away'
        other='away' if side=='home' else 'home';margin=scores[side]-scores[other];met=margin>0
        note=f"{leg[side]['short']} liegt {abs(margin)} {'Tore' if soccer else 'Punkte'} {'vorn' if margin>0 else 'zurück'}." if margin else 'Aktuell Gleichstand.'
        label='Führt' if met else 'Gleichstand' if not margin else 'Liegt zurück'

    else:
        line=leg['line'];met=total>line if leg['market']=='over' else total<line
        if leg['market']=='over':
            remaining=max(0,math.floor(line)+1-total)
            note=f"Gesamt {total} · noch {remaining} {'Tore' if soccer else 'Punkte'} bis zur Grenze." if remaining else f'Gesamt {total} · Grenze überschritten.'
            label='Schwelle erreicht' if met else 'Schwelle noch offen'
        else:
            buffer=math.floor(line)-total
            note=f"Gesamt {total} · Puffer {buffer} {'Tore' if soccer else 'Punkte'} bis maximal {math.floor(line)}." if buffer>=0 else f'Gesamt {total} · Grenze bereits überschritten.'
            label='Unter der Grenze' if met else 'Grenze überschritten'
    if finished:
        return dict(out,code='won' if met else 'lost',label='Erfüllt' if met else 'Nicht erfüllt',color='green' if met else 'red',note=note,priority=6 if met else 5,fulfilled=met)
    color,reason=live_traffic(leg,event,met,total,margin if leg['market']=='winner' else None)
    return dict(out,code='live',label=label,color=color,note=note+' '+reason+' Zwischenstand, noch kein Endergebnis.',reason=reason,priority={'red':0,'yellow':1,'green':2}[color])


def traffic_summary(rows):
    counts={color:sum(r['status']['color']==color for r in rows) for color in ('green','yellow','red','neutral')}
    live=[r for r in rows if r['status']['code']=='live']
    lost=sum(r['status']['code']=='lost' for r in rows)
    won=sum(r['status']['code']=='won' for r in rows)
    if lost:color='red';title='Mindestens eine Auswahl ist nicht erfüllt'
    elif any(r['status']['color']=='red' for r in live):color='red';title='Einige laufende Spiele sind kritisch'
    elif any(r['status']['color']=='yellow' for r in live):color='yellow';title='Noch offen · laufende Spiele im Blick behalten'
    elif live:color='green';title='Laufende Spiele aktuell günstig'
    elif won==len(rows) and rows:color='green';title='Alle Auswahlen laut Endstand erfüllt'
    elif won:color='yellow';title='Erste Auswahlen erfüllt · Rest noch offen'
    else:color='neutral';title='Noch keine Live-Einschätzung möglich'
    return {'counts':counts,'color':color,'title':title}


def render_traffic_summary(rows):
    summary=traffic_summary(rows);counts=summary['counts']
    assessed=sum(counts[c] for c in ('green','yellow','red'))
    label={'green':'Aktuell günstig','yellow':'Noch offen','red':'Kritisch','neutral':'Wartet auf Spiele'}[summary['color']]
    if any(r['status']['code']=='lost' for r in rows):label='Mindestens eine Auswahl nicht erfüllt'
    if assessed:label+=f" · {counts['green']}/{assessed} aktuell grün"
    st.caption(label)
    st.markdown('<div class="sb-traffic-summary"><div class="sb-mini-summary">'+''.join('<span><i class="sb-dot '+color+'"></i><b>'+str(counts[color])+'</b> '+label+'</span>' for color,label in [('green','Grün'),('yellow','Gelb'),('red','Rot')])+'<span class="sb-muted">'+str(counts['neutral'])+' offen</span></div></div>',unsafe_allow_html=True)


def rows_for(slip,boards):
    rows=[]
    for leg in slip['legs']:
        board=boards.get(leg['league'],{});event=None
        matching=[e for e in board.get('events',[]) if str(e.get('id'))==leg['event_id']] if board.get('ok') else []
        if len(matching)==1:
            try:event=parse_event(matching[0],leg)
            except (ValueError,KeyError,TypeError):pass
        rows.append({'leg':leg,'event':event,'status':leg_status(leg,event),'checked_at':board.get('checked_at')})
    return rows


def team_html(team):
    logo=safe_logo(team.get('logo'))
    return ('<img src="'+html.escape(logo,quote=True)+'" alt="" loading="lazy">' if logo else '')+'<span>'+html.escape(team['short'])+'</span>'


def compact_metrics(leg,event):
    unknown=[('Ist','–'),('Soll','–'),('Δ','–'),('Fehlt','–')]
    if event is None or event['state'] not in ('in','post') or any(v is None for v in event['scores'].values()):return unknown,None
    total=sum(event['scores'].values());finished=event['completed']
    if leg['market']=='winner':
        side='home' if leg['selected_team_id']==leg['home']['id'] else 'away'
        margin=event['scores'][side]-event['scores']['away' if side=='home' else 'home']
        return [('Führung',f'{margin:+d}'),('Soll','+1'),('Δ',f'{margin-1:+d}'),('Fehlt',str(max(0,1-margin)))],None
    target=math.floor(leg['line'])+(1 if leg['market']=='over' else 0)
    pace=nfl_pace(leg,event)
    checkpoint=None
    if pace:
        expected=pace['expected'];delta=pace['delta'];checkpoint=pace['checkpoint']
    elif finished:
        expected=target;delta=total-target if leg['market']=='over' else target-total
    else:
        clock=match_clock(leg,event)
        if clock:
            checkpoint=min(clock['duration'],math.floor((clock['elapsed']+1e-9)/5)*5)
            expected=target*checkpoint/clock['duration'];delta=total-expected if leg['market']=='over' else expected-total
        else:expected=delta=None
    end=max(0,target-total) if leg['market']=='over' else target-total
    return [('Ist',str(total)),('Soll',f'{expected:.1f}' if expected is not None else '–'),('Δ',f'{delta:+.1f}' if delta is not None else '–'),('Fehlt' if leg['market']=='over' else 'Puffer',str(end))],checkpoint


def render_card(row):
    leg=row['leg'];event=row['event'];status=row['status'];esc=html.escape
    kickoff=pd.Timestamp((event or {}).get('kickoff',leg['kickoff'])).tz_convert('Europe/Berlin').strftime('%H:%M')
    known=event is not None and all(v is not None for v in event['scores'].values())
    score=f"{event['scores']['away']} : {event['scores']['home']}" if known else '– : –'
    clock=(event.get('detail') or event.get('clock') or 'Live') if event and event['state']=='in' else 'Ende' if event and event['completed'] else kickoff+' Uhr' if event and event['state']=='pre' else 'Keine Daten'
    if event and event['state']=='in' and leg['league']=='football/nfl' and event.get('period'):
        clock='Q'+str(event['period'])+' '+event.get('clock','')
    metrics,checkpoint=compact_metrics(leg,event)
    plan=' · Plan '+str(checkpoint)+'′' if checkpoint is not None else ''
    target_note=''
    if leg['market'] in ('over','under'):
        target=math.floor(leg['line'])+(1 if leg['market']=='over' else 0)
        target_note=' · '+('Ziel ' if leg['market']=='over' else 'Max. ')+str(target)
    state_label={'won':'Erfüllt','lost':'Nicht erfüllt','pre':'Offen','unknown':'Keine Daten'}.get(status['code'],'Live')
    numeric=''.join('<div><small>'+label+'</small><b'+(' class="sb-metric-'+status['color']+'"' if label=='Δ' else '')+'>'+value+'</b></div>' for label,value in metrics)
    st.markdown('<div class="sb-card"><div class="sb-compact-top"><span>'+esc(clock+plan)+'</span><span><i class="sb-dot '+status['color']+'"></i> '+state_label+'</span></div><div class="sb-compact-game"><div class="sb-compact-team">'+team_html(leg['away'])+'</div><strong>'+score+'</strong><div class="sb-compact-team sb-right">'+team_html(leg['home'])+'</div></div><div class="sb-compact-pick">'+esc(selection(leg)+target_note)+'</div><div class="sb-four-stats">'+numeric+'</div></div>',unsafe_allow_html=True)


@st.fragment(run_every=60)
def render():
    slip=load_slip()
    st.title('SportBet')
    boards=fetch_boards();rows=rows_for(slip,boards)
    render_traffic_summary(rows)
    checked=[v['checked_at'] for v in boards.values() if v.get('ok')]
    stamp=pd.Timestamp(min(checked)).tz_convert('Europe/Berlin').strftime('%H:%M') if checked else '–'
    st.caption('5-Spielminuten-Soll · Daten '+stamp+' Uhr')
    if st.button('↻ Aktualisieren',key='refresh_sportbet'):fetch_boards.clear();fetch_details.clear();st.rerun()
    order=st.radio('Sortierung',['Ampel','Delta','Schein'],horizontal=True,key='sportbet_order_v2',label_visibility='collapsed')
    ordered=sorted(rows,key=traffic_sort_key) if order=='Ampel' else sorted(rows,key=delta_sort_key) if order=='Delta' else rows
    for row in ordered:render_card(row)
    with st.expander('Spielstatistiken'):
        i=st.selectbox('Spiel',range(len(rows)),format_func=lambda i:rows[i]['leg']['away']['short']+' – '+rows[i]['leg']['home']['short'],key='sportbet_detail')
        if st.toggle('Detaildaten laden',key='sportbet_load_details'):
            row=rows[i];leg=row['leg'];event=row['event']
            extra=fetch_details(leg['league'],leg['event_id']) if event and event['state'] in ('in','post') else None
            stats={side:{**((event or {}).get('statistics',{}) if event and event['state'] in ('in','post') else {}).get(side,{}),**(extra or {}).get(leg[side]['id'],{})} for side in ('away','home')}
            fields=[('totalYards','Yards'),('netPassingYards','Pass-Yards'),('rushingYards','Lauf-Yards'),('turnovers','Ballverluste'),('firstDowns','First Downs')] if leg['league']=='football/nfl' else [('totalShots','Schüsse'),('shotsOnTarget','Aufs Tor'),('possessionPct','Ballbesitz (%)'),('wonCorners','Ecken')]
            table=[{'Statistik':label,leg['away']['short']:stats['away'].get(key,'–'),leg['home']['short']:stats['home'].get(key,'–')} for key,label in fields if key in stats['away'] or key in stats['home']]
            if table:st.markdown('<div class="data-table">'+pd.DataFrame(table).to_html(index=False,escape=True,border=0)+'</div>',unsafe_allow_html=True)
            else:st.caption('Keine Detaildaten verfügbar.')
    with st.expander('Schein'):
        st.write(f"{len(rows)} Auswahlen · Einsatz {euro(slip['stake'])} · Quote {slip['display_odds']:.2f} · Mögliche Auszahlung {euro(slip['possible_payout'])}")
    with st.expander('Info'):
        st.write('Ampel-Reihenfolge: Grün, Gelb, Rot, dann offene Spiele ohne Bewertung. Innerhalb einer Farbe stehen größere Rückstände zuerst. Die Gesamtbewertung und der Grün-Anteil beschreiben den aktuellen Stand; sie sind keine Gewinnwahrscheinlichkeit des Kombischeins. NFL: zwölf Abschnitte à fünf Spielminuten. Soll = Endziel × zuletzt vollständige Spielminuten / 60. Bei 40 Punkten: 3,33 je Abschnitt; nach 5 Minuten 3,33, nach 10 Minuten 6,67. Over: Δ = Ist − Soll; Under: Δ = Soll − Ist. Grün ab null, Gelb bis einschließlich −7, darunter Rot. Fehlt zeigt die restlichen Punkte bis zum Endziel, Puffer das noch erlaubte Ergebnis bei Under. Der Plan ist eine Regel, keine Gewinnwahrscheinlichkeit. Spielstände aktualisieren etwa minütlich; die Quelle kann verzögert melden. Ohne Uhr keine geschätzte Spielzeit. Für Fußball gelten 90 reguläre Minuten und die bisherigen Tor-/Zeitregeln; für Sieg-Auswahlen zählt die Führung. Die Buchmacherabrechnung bleibt maßgeblich.')
