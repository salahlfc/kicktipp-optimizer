"""Read-only betting research. No executable tip or stake without validated inputs."""
from pathlib import Path
import hashlib
import json
import math
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from scipy.stats import binom
import streamlit as st
from market_model import club

ROOT=Path(__file__).resolve().parent
BERLIN=ZoneInfo('Europe/Berlin')
RULE_EV=.05  # Fixed research rule, never selected using this test season.


def decimal_value(probability,odds,stake=10.,payout_factor=1.):
    values=[probability,odds,stake,payout_factor]
    if not all(math.isfinite(float(v)) for v in values):raise ValueError('Nicht endliche Eingabe')
    if not 0<=probability<=1 or odds<=1 or stake<0 or not 0<payout_factor<=1:raise ValueError('Ungültige Eingabe')
    gross_odds=odds*payout_factor
    return {'break_even':1/gross_odds,'expected_payout':stake*probability*gross_odds,
            'expected_profit':stake*(probability*gross_odds-1),'profit_if_won':stake*(gross_odds-1),
            'roi':probability*gross_odds-1}


def series_risk(probability,odds,stake=10.,tickets=10):
    decimal_value(probability,odds,stake)
    if isinstance(tickets,bool) or not isinstance(tickets,int) or not 1<=tickets<=1000:raise ValueError('Ungültige Anzahl')
    # Identical hypothetical prices, independent tickets. Never a fitted win probability.
    wins_to_profit=math.floor(tickets/odds)+1
    return {'cost':tickets*stake,'expected_profit':tickets*stake*(probability*odds-1),
            'no_win_probability':float(binom.pmf(0,tickets,probability)),
            'profit_probability':float(binom.sf(wins_to_profit-1,tickets,probability)),
            'wins_to_profit':wins_to_profit,'loss_if_no_win':tickets*stake}


def bankroll_path(returns):
    cumulative=np.r_[0.,np.cumsum(np.asarray(returns,dtype=float))]
    return cumulative,float(np.max(np.maximum.accumulate(cumulative)-cumulative))


def historical_audit(folder=ROOT/'output'):
    """Exploratory older baseline + historical Bwin prices with UNKNOWN quote times.

    Scores must agree across both sources. No closing prices, no retrospective
    strategy tuning, no claim of executable or independently validated ROI.
    """
    folder=Path(folder);predfile=folder/'holdout_predictions_2025_26.csv';oddsfile=folder/'market_data/2025.csv'
    p=pd.read_csv(predfile);q=pd.read_csv(oddsfile,encoding='utf-8-sig')
    required={'Date','HomeTeam','AwayTeam','FTHG','FTAG','BWH','BWD','BWA'}
    if not required.issubset(q):raise ValueError('Historische Bwin-Quoten fehlen')
    q['date']=pd.to_datetime(q.Date,dayfirst=True,format='mixed',errors='coerce').dt.strftime('%Y-%m-%d')
    q['home']=q.HomeTeam.map(club);q['away']=q.AwayTeam.map(club)
    keys=['date','home','away']
    if p.duplicated(keys).any() or q.duplicated(keys).any():raise ValueError('Mehrdeutige historische Begegnungen')
    joined=p.merge(q[keys+['FTHG','FTAG','BWH','BWD','BWA']],on=keys,how='inner',validate='one_to_one')
    records=[];invalid=0
    for r in joined.to_dict('records'):
        probs=np.asarray([r['prob_home'],r['prob_draw'],r['prob_away']],dtype=float)
        prices=np.asarray([r['BWH'],r['BWD'],r['BWA']],dtype=float)
        if not np.isfinite(probs).all() or (probs<0).any() or (probs>1).any() or not np.isclose(probs.sum(),1,atol=1e-6):raise ValueError('Ungültige Modellwahrscheinlichkeiten')
        if not np.isfinite(prices).all() or (prices<=1).any():invalid+=1;continue
        hg,ag=map(int,str(r['actual']).split(':'))
        if pd.Timestamp(r['date']).date()>=datetime.now(BERLIN).date():raise ValueError('Zukünftiges historisches Endergebnis')
        if (hg,ag)!=(r['FTHG'],r['FTAG']):raise ValueError('Widersprüchliche historische Endergebnisse')
        realized=0 if hg>ag else 1 if hg==ag else 2
        ev=probs*prices-1;choice=int(np.argmax(ev))
        if ev[choice]<RULE_EV:continue
        won=choice==realized;net=10*(prices[choice]*int(won)-1)
        records.append({'date':r['date'],'home':r['home'],'away':r['away'],'selection':['1','X','2'][choice],
                        'odds':float(prices[choice]),'probability':float(probs[choice]),'model_ev':float(ev[choice]),
                        'won':won,'net':float(net)})
    d=pd.DataFrame(records)
    result={'matched':len(joined),'predictions':len(p),'invalid_odds':invalid,'tickets':len(d),
            'rule_ev':RULE_EV,'stake':10,'tradable_validation':False,'quote_times_known':False,
            'fingerprint':hashlib.sha256(predfile.read_bytes()+oddsfile.read_bytes()).hexdigest(),
            'model':'Archiviertes früheres Einzelmodell; kein neu optimierter Betting-Algorithmus',
            'records':records}
    if d.empty:return dict(result,net=0.,roi=None,win_rate=None,max_drawdown=0.,roi_interval=None)
    d=d.sort_values(['date','home','away']);curve,drawdown=bankroll_path(d.net)
    # Resample calendar-week clusters, not individual bets which may be dependent.
    week=pd.to_datetime(d.date).dt.to_period('W').astype(str)
    grouped=d.assign(week=week).groupby('week').agg(net=('net','sum'),n=('net','size'))
    interval=None
    if len(grouped)>=10:
        rng=np.random.default_rng(7619);idx=rng.integers(0,len(grouped),size=(2000,len(grouped)))
        roi=grouped.net.to_numpy()[idx].sum(axis=1)/(10*grouped.n.to_numpy()[idx].sum(axis=1))
        interval=np.quantile(roi,[.025,.975]).tolist()
    return dict(result,net=float(d.net.sum()),roi=float(d.net.sum()/(10*len(d))),win_rate=float(d.won.mean()),
                max_drawdown=drawdown,roi_interval=interval,curve=curve.tolist())


@st.cache_data(show_spinner=False)
def daily_audit(day):
    # Deliberately no live-odds calls, training, purchases or background scheduler.
    return historical_audit()


def research_reports():
    reports=[]
    for name in ('initial','extended'):
        data=json.loads((ROOT/'data'/f'betting_study_{name}.json').read_text())
        if data['business_case_supported'] is not False or data['candidate_count']!=216:
            raise ValueError('Unerwarteter Forschungsbericht')
        reports.append(data)
    return reports


def new_research_reports():
    reports=[]
    for name in ('new_markets','price_comparison'):
        data=json.loads((ROOT/'data'/f'betting_study_{name}.json').read_text())
        if data['business_case_supported'] is not False:raise ValueError('Ungeprüfte Freigabe')
        reports.append(data)
    return reports


def render_new_research():
    try:study,prices=new_research_reports()
    except (ValueError,KeyError,OSError):
        st.info('Neue Testberichte derzeit nicht verfügbar. Keine Einsatzfreigabe.');return
    count=sum(v['candidate_count'] for v in study['markets'].values())+sum(v['candidate_count'] for v in prices['markets'].values())
    st.markdown('**Neue Prüfung: weiterhin kein belegter Business Case**')
    st.caption(f'{count} zusätzliche feste Konfigurationen · insgesamt {216+count} · Form-/Schussdaten und weitere Wettmärkte')
    for key,title in [('1x2','1X2 · Bwin · zusätzliche Form-/Schussdaten'),('ou25','Über/Unter 2,5 · Bet365-Vergleich')]:
        item=study['markets'][key];raw=item['diagnostic_forced']['1'];stress=item['diagnostic_forced']['0.9025']
        st.markdown('<div class="tip-card"><strong>'+title+'</strong><div class="tip-stats"><div><span>Virtuelle Test-Tipps</span><b>'+str(raw['n'])+'</b></div><div><span>Vor Kosten</span><b>'+f"{raw['net']:+.2f} €"+'</b></div><div><span>Schlechtere Quoten + Abzug</span><b>'+f"{stress['net']:+.2f} €"+'</b></div><div><span>Freigabe-Regel</span><b>Keine Wetten</b></div></div></div>',unsafe_allow_html=True)
    st.caption('Diagnostischer Rückblick bei 10 € je Tipp, falls die jährlich gewählte Regel trotz schwacher Vorprüfung angewendet würde. Die vorab festgelegte Freigabe hätte in beiden Märkten keine Wetten zugelassen. 5 % schlechtere Quoten plus 5 % Auszahlungsabzug sind ein Rechenszenario.')
    st.markdown('**Preisvergleich mit separatem Referenzanbieter**')
    st.write('Keine ausreichend belegte Auswahl: Nach dem angenommenen Abzug gab es zu wenige passende frühere Fälle für die festgelegte Mindestzahl von 30. Das ist fehlende Evidenz, kein Gewinnnachweis.')
    st.caption('Über/Unter verwendet Bet365-Preise, keine behaupteten Bwin-Quoten. Ergebnisse beider Märkte nicht addieren: Es können dieselben Spiele betroffen sein.')
    with st.expander('Neue Daten & Testablauf'):
        st.write('Letzte sechs beendete Ligaspiele je Team: Tore, Gegentore, Schüsse und Schüsse aufs Tor, jeweils für und gegen das Team. Alle Formmerkmale verwenden ausschließlich frühere Spieltage, nie das vorherzusagende Spiel. Fehlende Werte werden nicht als null erfunden. Keine Behauptung zu Aufstellungen, Verletzungen oder Europapokalbelastung.')
        st.write('Drei unterschiedlich stark regularisierte Wahrscheinlichkeitsmodelle ergänzen die Marktschätzung um diese Merkmale. Gewichte werden wöchentlich ausschließlich aus früheren Ergebnissen geschätzt; Standardisierung ebenfalls nur auf Trainingsdaten. Über/Unter nutzt zusätzlich die drei bisherigen Torverteilungen. Strategieauswahl jeweils auf früheren Saisons, Auswertung danach. Alle neuen Regeln wurden vor dieser Auswertung festgelegt; das bleibt rückblickende Forschung mit bereits betrachteten historischen Daten.')
        st.write('Der Preisvergleich nutzt Pinnacle-Vorabquoten als separate Referenz und entfernt die Marge proportional oder mit der Power-Methode. Es werden keine Schlussquoten als Vorabinformation verwendet. Die Veröffentlichungszeitpunkte und gleichzeitige Verfügbarkeit beider Anbieterpreise sind trotzdem nicht bewiesen.')
        for key,label in [('1x2','1X2'),('ou25','Über/Unter')]:
            item=study['markets'][key];raw=item['diagnostic_forced']['1']
            st.write(f"{label}: {item['eligible_games']} geeignete historische Datensätze; {item['excluded_games']} wegen fehlender Preise, Merkmale oder anfänglicher Trainingshistorie ausgeschlossen. 95-%-ROI-Intervall vor Kosten: "+' bis '.join(f'{v:.1%}' for v in raw['roi_ci']))
        st.caption('Die Märkte und Modellversuche sind keine unabhängigen Experimente. Weitere Suchen auf denselben Ergebnissen ersetzen keine neue, unberührte Vorabprüfung.')
        st.markdown('[Verfahren zur Margenbereinigung – Originalarbeit](https://sciencepublishinggroup.com/article/10.11648/10026106)')
    with st.expander('Wahrscheinlichkeiten im Vergleich'):
        for key,label in [('1x2','1X2'),('ou25','Über/Unter')]:
            quality=study['markets'][key]['probability_quality']
            table=[{'Modell':name,'Log Loss':round(v['log_loss'],5),'Brier':round(v['brier'],5),'Spiele':v['n']} for name,v in quality.items()]
            st.write(label);st.dataframe(pd.DataFrame(table),hide_index=True,width='stretch')
        st.caption('Kleinere Werte sind besser. Ein kleiner Vorteil in der Wahrscheinlichkeitsschätzung bedeutet noch keinen Gewinn nach Buchmachermarge und Kosten.')
    with st.expander('Berichte herunterladen'):
        st.download_button('Form- und Tore-Test',json.dumps(study,ensure_ascii=False,indent=2),file_name='betting_form_tore_test.json',mime='application/json',key='betting_form_download')
        st.download_button('Preisvergleich',json.dumps(prices,ensure_ascii=False,indent=2),file_name='betting_preisvergleich.json',mime='application/json',key='betting_prices_download')


def render_research():
    round_choice=st.radio('Forschungsrunde',['Neue Prüfungen','Bisherige Prüfungen'],horizontal=True,key='betting_research_round')
    if round_choice=='Neue Prüfungen':
        render_new_research();return
    try:initial,study=research_reports()
    except (ValueError,KeyError,OSError):
        st.info('Modelltest-Bericht nicht verfügbar. Keine Freigabe.')
        return
    raw=study['combined_test']['reported_odds'];stress=study['combined_test']['odds_minus5pct_and_cost5pct']
    st.markdown('**Business Case: bisher nicht belegt**')
    st.caption('216 feste Konfigurationen · 8 Prognose-Saisons · 6 spätere Test-Saisons. Jede Auswahl nutzt ausschließlich frühere Saisons.')
    st.markdown('<div class="tip-card"><div class="tip-stats"><div><span>Virtuelle Test-Tipps</span><b>'+str(raw['n'])+'</b></div><div><span>Virtueller Einsatz</span><b>'+f"{raw['n']*10:,.0f} €"+'</b></div></div></div>',unsafe_allow_html=True)
    for key,label in [('reported_odds','Originalquoten · vor Kosten'),('payout_cost_5pct','5 % angenommener Auszahlungsabzug'),('odds_minus5pct_and_cost5pct','5 % schlechtere Quoten + 5 % Abzug')]:
        m=study['combined_test'][key]
        st.markdown('<div class="tip-card"><small>'+label+'</small><div class="tip-stats"><div><span>Virtueller Saldo</span><b>'+f"{m['net']:+.2f} €"+'</b></div><div><span>Rendite auf Einsatz</span><b>'+f"{m['roi']:+.1%}"+'</b></div></div></div>',unsafe_allow_html=True)
    st.caption('Die Abzüge sind Rechenszenarien, keine Aussage zur konkreten Bwin-Abrechnung. Alle Werte sind historische Simulationen mit 10 € je Tipp.')
    with st.expander('Testjahre & Risiko'):
        rows=[]
        for item in study['walk_forward']:
            m=item['test']['reported_odds'];year=item['season']
            rows.append({'Saison':f'{year}/{str(year+1)[2:]}','Tipps':m['n'],'Netto vor Kosten (€)':round(m['net'],2)})
        st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
        st.write(f"Größter Rückgang vor Kosten: {raw['max_drawdown']:.2f} € · Längste Verlustserie: {raw['max_loss_streak']} Tipps.")
        st.write('95-%-Intervall des ROI (Wochen-Bootstrap, vor Kosten): '+' bis '.join(f'{v:.1%}' for v in raw['roi_ci']))
        st.caption('Das Intervall belegt keinen positiven Vorteil und erfasst keine unbekannten Quotenzeitpunkte oder künftigen Marktänderungen.')
    with st.expander('Was wurde geprüft?'):
        st.write('Drei Tor-Modelle (Dixon-Coles mit 365/730 Tagen Halbwertszeit, Poisson mit 180 Tagen), vier Marktgewichte, zwei Kalibrierungs-Temperaturen, drei Mindest-Erwartungswerte und drei Quotenobergrenzen. Wöchentliche Prognosen nutzen nur davor beendete Spiele; die jährliche Strategieauswahl sieht keine späteren Testergebnisse. Höchstens ein Tipp pro Begegnung, keine künstlichen 30er-Kombis.')
        st.write(f"{study['coverage']['predictions']} Modellprognosen; {study['matches']} mit verwendbaren Quoten. {study['coverage']['missing_or_invalid_quotes']} wegen fehlender/ungültiger Quoten ausgeschlossen; keine stillen Ersatzpreise. Für 2018/19 stammen die Marktdurchschnitte aus BetBrain, danach aus AvgH/D/A. Bwin-Auszahlungsquoten bleiben BWH/BWD/BWA.")
        st.write('Die historischen Quotenzeitpunkte sind nicht exakt bekannt. 2025/26 wurde schon in früheren Analysen betrachtet. Diese Prüfung ist deshalb retrospektive Forschung, kein unberührter Vorab-Test und keine Freigabe für Echtgeld.')
        st.download_button('Testbericht herunterladen',json.dumps(study,ensure_ascii=False,indent=2),file_name='betting_modelltest.json',mime='application/json',key='betting_report_download')
        st.write('Die Auswahlregel wird auch dann ausgewertet, wenn ihr bester Kandidat schon in den Auswahldaten schwach ist. Das macht ihre Schwächen sichtbar und ist keine Aufforderung, jedes Jahr zu wetten.')
    with st.expander('Erste Prüfung & rückblickend schönste Variante'):
        first=initial['combined_test']['reported_odds'];first_stress=initial['combined_test']['odds_minus5pct_and_cost5pct']
        st.write(f"Erste Prüfung mit fünf Saisons: {first['n']} spätere Test-Tipps, {first['net']:+.2f} € vor Kosten; im Stressszenario {first_stress['net']:+.2f} €.")
        best=study['hindsight_best']['metrics']
        st.write(f"Die nach Betrachtung aller Ergebnisse schönste Variante zeigt {best['net']:+.2f} € bei {best['n']} Tipps. Diese nachträgliche Auswahl ist ausdrücklich kein Nachweis eines zukünftigen Vorteils. Ihr Unsicherheitsintervall enthält ebenfalls Verluste.")
        st.caption('Ein positives Ergebnis nach vielen Versuchen reicht nicht. Die Auswahl muss auch bei späteren, zuvor unbekannten Ergebnissen und schlechteren Preisen bestehen.')


def render():
    st.title('Betting Optimizer')
    st.caption('Analyse & Test · Echtgeld-Empfehlungen noch nicht freigegeben')
    today=datetime.now(BERLIN).date().isoformat()
    if st.button('Daten prüfen',type='primary',key='betting_check',width='stretch'):
        daily_audit.clear()
    try:report=daily_audit(today)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        st.info('Historischer Datencheck nicht verfügbar. Keine Einsatzempfehlung.')
        report=None
    st.markdown('<div class="tip-card"><strong>Heute keine freigegebenen Wetten</strong><div class="tip-stats"><div><span>Empfohlener Einsatz</span><b>0 €</b></div><div><span>Bwin-Livequoten</span><b>Nicht angebunden</b></div></div></div>',unsafe_allow_html=True)
    st.caption('Tagesprüfung '+datetime.now(BERLIN).strftime('%d.%m.%Y')+' · Kein automatischer täglicher Hintergrundlauf eingerichtet.')
    page=st.radio('Analyse',['Modelltests','Datencheck','Rechner','Info'],horizontal=True,key='betting_page',label_visibility='collapsed')
    if page=='Modelltests':
        render_research()
    elif page=='Datencheck':
        st.markdown('**Historischer Rückblick · Bundesliga 2025/26**')
        st.caption('Testregel: pro Spiel höchstens ein 1X2-Tipp mit mindestens 5 % Modell-Erwartungswert; je 10 € virtueller Einsatz. Vor Kosten.')
        if report:
            st.markdown('<div class="tip-card"><div class="tip-stats"><div><span>Abgeglichene Spiele</span><b>'+str(report['matched'])+'</b></div><div><span>Virtuelle Tipps</span><b>'+str(report['tickets'])+'</b></div><div><span>Rechnerischer Rückblick</span><b>'+f"{report['net']:+.2f} €"+'</b></div><div><span>Größter Rückgang</span><b>'+f"{report['max_drawdown']:.2f} €"+'</b></div></div></div>',unsafe_allow_html=True)
            st.caption('Archiviertes früheres Einzelmodell, kein neu optimierter Wettalgorithmus. Exploratives Szenario: Zeitpunkt der historischen Quoten unbekannt. Kein Nachweis, dass diese Preise bei Tippabgabe erhältlich gewesen wären; keine nachgewiesene profitable Strategie.')
            with st.expander('Auswertung'):
                if report['roi'] is not None:
                    st.write(f"ROI: {report['roi']:.1%} · Treffer: {report['win_rate']:.1%}")
                    if report['roi_interval']:st.write('95-%-Intervall des historischen ROI (Wochen-Bootstrap): '+ ' bis '.join(f'{v:.1%}' for v in report['roi_interval']))
                    st.caption('Das Intervall erfasst keine unbekannten Quotenzeitpunkte, Modellwechsel oder zukünftigen Marktänderungen.')
                    st.line_chart(pd.DataFrame({'Virtueller Saldo (€)':report['curve']}))
                    rows=pd.DataFrame(report['records']).rename(columns={'date':'Datum','home':'Heim','away':'Gast','selection':'Tipp','odds':'Quote','net':'Virtuelles Netto'})
                    st.dataframe(rows[['Datum','Heim','Gast','Tipp','Quote','Virtuelles Netto']],hide_index=True,width='stretch')
                st.write(f"Fehlende/ungültige Quoten: {report['invalid_odds']}; nicht zugeordnete Prognosen: {report['predictions']-report['matched']}.")
        with st.expander('Was für echte Empfehlungen fehlt'):
            st.write('Aktuelle, zeitgestempelte und eindeutig zum deutschen Bwin-Angebot passende Quoten; eigenes festes Budget; ein für Wetten geprüftes Modell; unabhängige zeitliche Tests nach Kosten und dauerhafte Speicherung aller Vorabprognosen. NFL und andere Ligen benötigen eigene Modelle und Tests. Verletzungen, Aufstellung und Belastung zählen erst mit verifizierter Datenquelle und messbarem Nutzen.')
    elif page=='Rechner':
        st.caption('Nur ein Rechenszenario. Die Trefferchance unten ist deine Annahme, keine Modellprognose.')
        odds=st.number_input('Gesamtquote',min_value=1.01,max_value=1000.,value=30.,step=1.,key='betting_calc_odds')
        stake=st.number_input('Virtueller Einsatz je Schein (€)',min_value=0.,max_value=10.,value=10.,step=1.,key='betting_calc_stake')
        n=st.number_input('Anzahl Scheine',min_value=1,max_value=1000,value=10,step=1,key='betting_calc_count')
        p=st.number_input('Angenommene Trefferchance pro Schein (%)',min_value=0.,max_value=100.,value=100/30,step=.1,key='betting_calc_probability')/100
        value=decimal_value(p,odds,stake);risk=series_risk(p,odds,stake,int(n))
        st.write(f"Gewinnschwelle: {value['break_even']:.2%} · Erwartetes Netto: {value['expected_profit']:+.2f} € je Schein")
        st.write(f"{int(n)} Scheine kosten {risk['cost']:.2f} €. Ein Treffer zahlt {stake*odds:.2f} € aus; der Gesamtsaldo wäre {stake*odds-risk['cost']:+.2f} €.")
        st.write(f"Kein einziger Treffer: {risk['no_win_probability']:.1%} · Chance auf positiven Gesamtsaldo: {risk['profit_probability']:.1%}")
        st.caption('Unter der Annahme unabhängiger Scheine, gleicher Quote und konstanter echter Trefferchance. Überlappende Tipps sind abhängig. Vor Gebühren, Abzügen und Steuern. Hohe Quote bedeutet keine hohe Gewinnchance; auch positiver Erwartungswert garantiert kein Plus.')
    else:
        st.write('Ziel ist ein überprüfbarer Preisvorteil, keine feste Wunschquote. Erwartetes Netto = Einsatz × (Trefferchance × tatsächlich ausbezahlte Quote − 1). Eine Quote von 30 ist kein Grund, ungeeignete Tipps zu ergänzen.')
        st.write('Für einen späteren Echtbetrieb: getrennte Modelle pro Sport und Markt; aktuelle Form zeitlich abwerten; verifizierte Ausfälle, Aufstellungen und Belastung als messbare Merkmale testen; vollständige Quotenmärkte um Marge bereinigen. Modellwahl auf älteren Daten, danach Kalibrierung und unangetasteter zeitlicher Test. Vergleich mit Markt und einfacher Baseline, Bootstrap nach Spieltag/Woche, Drawdown und Verlustserien prüfen. Gute KickTipp-Punkte allein reichen nicht.')
        st.write('Kombis: mehrere Tipps desselben Spiels nicht als unabhängig behandeln. Gemeinsame Teams und überlappende Scheine begrenzen. Eine gemeinsame Trefferchance benötigt ein geprüftes Abhängigkeitsmodell; Einzelchancen werden nicht ungeprüft multipliziert. Erst nach erfolgreichem Vorab-Test wäre eine begrenzte Einsatzregel möglich, gedeckelt durch verfügbares Budget, Tageslimit und maximal 10 € pro Schein. Keine Erhöhung zum Aufholen von Verlusten.')
        st.write('Tagesbetrieb ist noch nicht eingerichtet. Dafür braucht es einen Cloud-Zeitplan und dauerhaften Speicher: Quoten und Modellstand vor Anpfiff einfrieren, nach Ende korrekt abrechnen, Fehler prüfen und erst nach erneuter unabhängiger Validierung Modelländerungen übernehmen. Aktuell erfolgt nur der lokale historische Tagescheck beim Öffnen dieser Kategorie. Keine Wettabgabe und keine Bwin-Anmeldung durch die App.')
        st.write('Kostenlose Quelle geprüft: Football-Data stellt historische Ergebnisse und Quoten sowie eine aktuelle Fixture-Datei bereit. Die kommenden Quoten werden laut Anbieter typischerweise freitags und dienstags gesammelt. Das ersetzt keinen minutengenauen deutschen Bwin-Quotenfeed. Ein kostenpflichtiges Angebot wurde nicht gebucht. Ein fester Budgetrahmen ist noch nicht konfiguriert.')
        st.markdown('[Kostenlose Quoten: Aktualisierungsrhythmus](https://www.football-data.co.uk/matches.php) · [Historische Fußball- und Quotendaten](https://www.football-data.co.uk/data.php) · [Dokumentation zeitgestempelter Quoten](https://the-odds-api.com/liveapi/guides/v4/)')
