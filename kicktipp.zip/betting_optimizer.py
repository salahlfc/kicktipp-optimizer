"""Read-only betting research. No executable tip or stake without validated inputs."""
from pathlib import Path
import hashlib
import math
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from scipy.stats import binom
import streamlit as st
from market_model import club

ROOT=Path(__file__).resolve().parent
BERLIN=ZoneInfo('Europe/Berlin')
RULE_EV=.05  # Fixed research rule, never selected using this test season.


def decimal_value(probability,odds,stake=10.,payout_factor=1.):
    values=[probability,odds,stake,payout_factor]
    if not all(math.isfinite(float(v)) for v in values):raise ValueError('Nicht endliche Eingabe')
    if not 0<=probability<=1 or odds<=1 or stake<0 or not 0<payout_factor<=1:raise ValueError('Ungültige Eingabe')
    gross_odds=odds*payout_factor
    return {'break_even':1/gross_odds,'expected_payout':stake*probability*gross_odds,
            'expected_profit':stake*(probability*gross_odds-1),'profit_if_won':stake*(gross_odds-1),
            'roi':probability*gross_odds-1}


def series_risk(probability,odds,stake=10.,tickets=10):
    decimal_value(probability,odds,stake)
    if isinstance(tickets,bool) or not isinstance(tickets,int) or not 1<=tickets<=1000:raise ValueError('Ungültige Anzahl')
    # Identical hypothetical prices, independent tickets. Never a fitted win probability.
    wins_to_profit=math.floor(tickets/odds)+1
    return {'cost':tickets*stake,'expected_profit':tickets*stake*(probability*odds-1),
            'no_win_probability':float(binom.pmf(0,tickets,probability)),
            'profit_probability':float(binom.sf(wins_to_profit-1,tickets,probability)),
            'wins_to_profit':wins_to_profit,'loss_if_no_win':tickets*stake}


def bankroll_path(returns):
    cumulative=np.r_[0.,np.cumsum(np.asarray(returns,dtype=float))]
    return cumulative,float(np.max(np.maximum.accumulate(cumulative)-cumulative))


def historical_audit(folder=ROOT/'output'):
    """Exploratory older baseline + historical Bwin prices with UNKNOWN quote times.

    Scores must agree across both sources. No closing prices, no retrospective
    strategy tuning, no claim of executable or independently validated ROI.
    """
    folder=Path(folder);predfile=folder/'holdout_predictions_2025_26.csv';oddsfile=folder/'market_data/2025.csv'
    p=pd.read_csv(predfile);q=pd.read_csv(oddsfile,encoding='utf-8-sig')
    required={'Date','HomeTeam','AwayTeam','FTHG','FTAG','BWH','BWD','BWA'}
    if not required.issubset(q):raise ValueError('Historische Bwin-Quoten fehlen')
    q['date']=pd.to_datetime(q.Date,dayfirst=True,format='mixed',errors='coerce').dt.strftime('%Y-%m-%d')
    q['home']=q.HomeTeam.map(club);q['away']=q.AwayTeam.map(club)
    keys=['date','home','away']
    if p.duplicated(keys).any() or q.duplicated(keys).any():raise ValueError('Mehrdeutige historische Begegnungen')
    joined=p.merge(q[keys+['FTHG','FTAG','BWH','BWD','BWA']],on=keys,how='inner',validate='one_to_one')
    records=[];invalid=0
    for r in joined.to_dict('records'):
        probs=np.asarray([r['prob_home'],r['prob_draw'],r['prob_away']],dtype=float)
        prices=np.asarray([r['BWH'],r['BWD'],r['BWA']],dtype=float)
        if not np.isfinite(probs).all() or (probs<0).any() or (probs>1).any() or not np.isclose(probs.sum(),1,atol=1e-6):raise ValueError('Ungültige Modellwahrscheinlichkeiten')
        if not np.isfinite(prices).all() or (prices<=1).any():invalid+=1;continue
        hg,ag=map(int,str(r['actual']).split(':'))
        if pd.Timestamp(r['date']).date()>=datetime.now(BERLIN).date():raise ValueError('Zukünftiges historisches Endergebnis')
        if (hg,ag)!=(r['FTHG'],r['FTAG']):raise ValueError('Widersprüchliche historische Endergebnisse')
        realized=0 if hg>ag else 1 if hg==ag else 2
        ev=probs*prices-1;choice=int(np.argmax(ev))
        if ev[choice]<RULE_EV:continue
        won=choice==realized;net=10*(prices[choice]*int(won)-1)
        records.append({'date':r['date'],'home':r['home'],'away':r['away'],'selection':['1','X','2'][choice],
                        'odds':float(prices[choice]),'probability':float(probs[choice]),'model_ev':float(ev[choice]),
                        'won':won,'net':float(net)})
    d=pd.DataFrame(records)
    result={'matched':len(joined),'predictions':len(p),'invalid_odds':invalid,'tickets':len(d),
            'rule_ev':RULE_EV,'stake':10,'tradable_validation':False,'quote_times_known':False,
            'fingerprint':hashlib.sha256(predfile.read_bytes()+oddsfile.read_bytes()).hexdigest(),
            'model':'Archiviertes früheres Einzelmodell; kein neu optimierter Betting-Algorithmus',
            'records':records}
    if d.empty:return dict(result,net=0.,roi=None,win_rate=None,max_drawdown=0.,roi_interval=None)
    d=d.sort_values(['date','home','away']);curve,drawdown=bankroll_path(d.net)
    # Resample calendar-week clusters, not individual bets which may be dependent.
    week=pd.to_datetime(d.date).dt.to_period('W').astype(str)
    grouped=d.assign(week=week).groupby('week').agg(net=('net','sum'),n=('net','size'))
    interval=None
    if len(grouped)>=10:
        rng=np.random.default_rng(7619);idx=rng.integers(0,len(grouped),size=(2000,len(grouped)))
        roi=grouped.net.to_numpy()[idx].sum(axis=1)/(10*grouped.n.to_numpy()[idx].sum(axis=1))
        interval=np.quantile(roi,[.025,.975]).tolist()
    return dict(result,net=float(d.net.sum()),roi=float(d.net.sum()/(10*len(d))),win_rate=float(d.won.mean()),
                max_drawdown=drawdown,roi_interval=interval,curve=curve.tolist())


@st.cache_data(show_spinner=False)
def daily_audit(day):
    # Deliberately no live-odds calls, training, purchases or background scheduler.
    return historical_audit()


def render():
    st.title('Betting Optimizer')
    st.caption('Analyse & Test · Echtgeld-Empfehlungen noch nicht freigegeben')
    today=datetime.now(BERLIN).date().isoformat()
    if st.button('Daten prüfen',type='primary',key='betting_check',width='stretch'):
        daily_audit.clear()
    try:report=daily_audit(today)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        st.info('Historischer Datencheck nicht verfügbar. Keine Einsatzempfehlung.')
        report=None
    st.markdown('<div class="tip-card"><strong>Heute keine freigegebenen Wetten</strong><div class="tip-stats"><div><span>Empfohlener Einsatz</span><b>0 €</b></div><div><span>Bwin-Livequoten</span><b>Nicht angebunden</b></div></div></div>',unsafe_allow_html=True)
    st.caption('Tagesprüfung '+datetime.now(BERLIN).strftime('%d.%m.%Y')+' · Kein automatischer täglicher Hintergrundlauf eingerichtet.')
    page=st.radio('Analyse',['Datencheck','Rechner','Info'],horizontal=True,key='betting_page',label_visibility='collapsed')
    if page=='Datencheck':
        st.markdown('**Historischer Rückblick · Bundesliga 2025/26**')
        st.caption('Testregel: pro Spiel höchstens ein 1X2-Tipp mit mindestens 5 % Modell-Erwartungswert; je 10 € virtueller Einsatz. Vor Kosten.')
        if report:
            st.markdown('<div class="tip-card"><div class="tip-stats"><div><span>Abgeglichene Spiele</span><b>'+str(report['matched'])+'</b></div><div><span>Virtuelle Tipps</span><b>'+str(report['tickets'])+'</b></div><div><span>Rechnerischer Rückblick</span><b>'+f"{report['net']:+.2f} €"+'</b></div><div><span>Größter Rückgang</span><b>'+f"{report['max_drawdown']:.2f} €"+'</b></div></div></div>',unsafe_allow_html=True)
            st.caption('Archiviertes früheres Einzelmodell, kein neu optimierter Wettalgorithmus. Exploratives Szenario: Zeitpunkt der historischen Quoten unbekannt. Kein Nachweis, dass diese Preise bei Tippabgabe erhältlich gewesen wären; keine nachgewiesene profitable Strategie.')
            with st.expander('Auswertung'):
                if report['roi'] is not None:
                    st.write(f"ROI: {report['roi']:.1%} · Treffer: {report['win_rate']:.1%}")
                    if report['roi_interval']:st.write('95-%-Intervall des historischen ROI (Wochen-Bootstrap): '+ ' bis '.join(f'{v:.1%}' for v in report['roi_interval']))
                    st.caption('Das Intervall erfasst keine unbekannten Quotenzeitpunkte, Modellwechsel oder zukünftigen Marktänderungen.')
                    st.line_chart(pd.DataFrame({'Virtueller Saldo (€)':report['curve']}))
                    rows=pd.DataFrame(report['records']).rename(columns={'date':'Datum','home':'Heim','away':'Gast','selection':'Tipp','odds':'Quote','net':'Virtuelles Netto'})
                    st.dataframe(rows[['Datum','Heim','Gast','Tipp','Quote','Virtuelles Netto']],hide_index=True,width='stretch')
                st.write(f"Fehlende/ungültige Quoten: {report['invalid_odds']}; nicht zugeordnete Prognosen: {report['predictions']-report['matched']}.")
        with st.expander('Was für echte Empfehlungen fehlt'):
            st.write('Aktuelle, zeitgestempelte und eindeutig zum deutschen Bwin-Angebot passende Quoten; eigenes festes Budget; ein für Wetten geprüftes Modell; unabhängige zeitliche Tests nach Kosten und dauerhafte Speicherung aller Vorabprognosen. NFL und andere Ligen benötigen eigene Modelle und Tests. Verletzungen, Aufstellung und Belastung zählen erst mit verifizierter Datenquelle und messbarem Nutzen.')
    elif page=='Rechner':
        st.caption('Nur ein Rechenszenario. Die Trefferchance unten ist deine Annahme, keine Modellprognose.')
        odds=st.number_input('Gesamtquote',min_value=1.01,max_value=1000.,value=30.,step=1.,key='betting_calc_odds')
        stake=st.number_input('Virtueller Einsatz je Schein (€)',min_value=0.,max_value=10.,value=10.,step=1.,key='betting_calc_stake')
        n=st.number_input('Anzahl Scheine',min_value=1,max_value=1000,value=10,step=1,key='betting_calc_count')
        p=st.number_input('Angenommene Trefferchance pro Schein (%)',min_value=0.,max_value=100.,value=100/30,step=.1,key='betting_calc_probability')/100
        value=decimal_value(p,odds,stake);risk=series_risk(p,odds,stake,int(n))
        st.write(f"Gewinnschwelle: {value['break_even']:.2%} · Erwartetes Netto: {value['expected_profit']:+.2f} € je Schein")
        st.write(f"{int(n)} Scheine kosten {risk['cost']:.2f} €. Ein Treffer zahlt {stake*odds:.2f} € aus; der Gesamtsaldo wäre {stake*odds-risk['cost']:+.2f} €.")
        st.write(f"Kein einziger Treffer: {risk['no_win_probability']:.1%} · Chance auf positiven Gesamtsaldo: {risk['profit_probability']:.1%}")
        st.caption('Unter der Annahme unabhängiger Scheine, gleicher Quote und konstanter echter Trefferchance. Überlappende Tipps sind abhängig. Vor Gebühren, Abzügen und Steuern. Hohe Quote bedeutet keine hohe Gewinnchance; auch positiver Erwartungswert garantiert kein Plus.')
    else:
        st.write('Ziel ist ein überprüfbarer Preisvorteil, keine feste Wunschquote. Erwartetes Netto = Einsatz × (Trefferchance × tatsächlich ausbezahlte Quote − 1). Eine Quote von 30 ist kein Grund, ungeeignete Tipps zu ergänzen.')
        st.write('Für einen späteren Echtbetrieb: getrennte Modelle pro Sport und Markt; aktuelle Form zeitlich abwerten; verifizierte Ausfälle, Aufstellungen und Belastung als messbare Merkmale testen; vollständige Quotenmärkte um Marge bereinigen. Modellwahl auf älteren Daten, danach Kalibrierung und unangetasteter zeitlicher Test. Vergleich mit Markt und einfacher Baseline, Bootstrap nach Spieltag/Woche, Drawdown und Verlustserien prüfen. Gute KickTipp-Punkte allein reichen nicht.')
        st.write('Kombis: mehrere Tipps desselben Spiels nicht als unabhängig behandeln. Gemeinsame Teams und überlappende Scheine begrenzen. Eine gemeinsame Trefferchance benötigt ein geprüftes Abhängigkeitsmodell; Einzelchancen werden nicht ungeprüft multipliziert. Erst nach erfolgreichem Vorab-Test wäre eine begrenzte Einsatzregel möglich, gedeckelt durch verfügbares Budget, Tageslimit und maximal 10 € pro Schein. Keine Erhöhung zum Aufholen von Verlusten.')
        st.write('Tagesbetrieb ist noch nicht eingerichtet. Dafür braucht es einen Cloud-Zeitplan und dauerhaften Speicher: Quoten und Modellstand vor Anpfiff einfrieren, nach Ende korrekt abrechnen, Fehler prüfen und erst nach erneuter unabhängiger Validierung Modelländerungen übernehmen. Aktuell erfolgt nur der lokale historische Tagescheck beim Öffnen dieser Kategorie. Keine Wettabgabe und keine Bwin-Anmeldung durch die App.')
        st.write('Kostenlose Quelle geprüft: Football-Data stellt historische Ergebnisse und Quoten sowie eine aktuelle Fixture-Datei bereit. Die kommenden Quoten werden laut Anbieter typischerweise freitags und dienstags gesammelt. Das ersetzt keinen minutengenauen deutschen Bwin-Quotenfeed. Ein kostenpflichtiges Angebot wurde nicht gebucht. Ein fester Budgetrahmen ist noch nicht konfiguriert.')
        st.markdown('[Kostenlose Quoten: Aktualisierungsrhythmus](https://www.football-data.co.uk/matches.php) · [Historische Fußball- und Quotendaten](https://www.football-data.co.uk/data.php) · [Dokumentation zeitgestempelter Quoten](https://the-odds-api.com/liveapi/guides/v4/)')
