"""Local screenshot recognition and fail-closed, one-button forecasting.

Screenshots identify fixtures, never supply unverified training labels or dates.
Only finished public results before the common forecast cutoff enter training.
"""
from __future__ import annotations
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import unicodedata
import fcntl
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import requests
from PIL import Image, UnidentifiedImageError

from engine import (ALIASES, ModelSpec, canonical, load_data, normalize, predictions,
                    validate_select, score_prob_matrix, prediction_matrix, SCORE_GRID, TIPS)
from webcore import pretty

ROOT = Path(__file__).resolve().parent
DATA = ROOT/'data'
OUTPUT = ROOT/'output'
BERLIN = ZoneInfo('Europe/Berlin')
API = 'https://api.openligadb.de/getmatchdata/bl1/{season}'
VERSION = 2


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.'+path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def season_now(now=None):
    now = now or datetime.now(BERLIN)
    return now.year if now.month >= 7 else now.year-1


def validate_feed(payload, season, now=None):
    now = now or datetime.now(BERLIN)
    cutoff = pd.Timestamp(now).tz_convert('UTC')
    if not isinstance(payload, list) or not payload:
        raise ValueError('Der öffentliche Spielplan ist leer. Bitte später erneut optimieren.')
    rows=[]
    for m in payload:
        if int(m['leagueSeason']) != season or m['leagueShortcut'] != 'bl1':
            raise ValueError('Die Datenquelle liefert eine andere Liga oder Saison.')
        dt=pd.Timestamp(m['matchDateTimeUTC'])
        if dt.tzinfo is None:
            raise ValueError('Ein Spieltermin hat keine eindeutige Zeitzone.')
        dt=dt.tz_convert('UTC')
        h=canonical(m['team1']['teamName']); a=canonical(m['team2']['teamName'])
        finished=m['matchIsFinished']
        if not isinstance(finished,bool):raise ValueError('Unklarer Spielstatus in der Datenquelle.')
        hg=ag=None
        if finished:
            finals=[r for r in m['matchResults'] if r.get('resultTypeID')==2]
            if len(finals)!=1:raise ValueError('Ein abgeschlossenes Spiel hat kein eindeutiges Endergebnis.')
            hg=finals[0]['pointsTeam1'];ag=finals[0]['pointsTeam2']
            if any(isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=30 for v in (hg,ag)):
                raise ValueError('Ungültiges Endergebnis in der Datenquelle.')
            if dt>=cutoff:raise ValueError('Die Datenquelle enthält ein zukünftiges Endergebnis.')
        rnd=int(m['group']['groupOrderID'])
        if not 1<=rnd<=34 or h==a or not h or not a:
            raise ValueError('Ungültige Begegnung im öffentlichen Spielplan.')
        local=dt.tz_convert(BERLIN)
        if (local.year if local.month>=7 else local.year-1)!=season:
            raise ValueError('Ein Termin gehört nicht zur aktuellen Saison.')
        rows.append({'id':int(m['matchID']),'round':rnd,'kickoff':dt.isoformat(),
                     'date':local.date().isoformat(),'home':h,'away':a,
                     'home_name':m['team1']['teamName'],'away_name':m['team2']['teamName'],
                     'home_logo':m['team1'].get('teamIconUrl') or '',
                     'away_logo':m['team2'].get('teamIconUrl') or '',
                     'home_short':m['team1'].get('shortName') or h,
                     'away_short':m['team2'].get('shortName') or a,
                     'finished':finished,'hg':hg,'ag':ag})
    frame=pd.DataFrame(rows)
    clubs=set(frame.home)|set(frame.away)
    if len(frame)!=306 or len(clubs)!=18 or frame.id.duplicated().any() or frame.duplicated(['home','away']).any():
        raise ValueError('Der Spielplan ist unvollständig oder widersprüchlich (18 Teams / 306 Spiele erforderlich).')
    if not frame.groupby('round').size().eq(9).all() or frame['round'].nunique()!=34:
        raise ValueError('Der Spielplan enthält unvollständige Spieltage.')
    for t in clubs:
        if (int((frame.home==t).sum()),int((frame.away==t).sum()))!=(17,17):
            raise ValueError('Der öffentliche Spielplan ist nicht ausgeglichen.')
    return rows


def fetch_schedule(season, now=None):
    # No silent stale-cache fallback: every click needs a fresh schedule.
    try:
        res=requests.get(API.format(season=season),timeout=(5,25),
                         headers={'User-Agent':'Kicktipp-Optimizer-local/2.0'})
        res.raise_for_status()
        if len(res.content)>5_000_000:raise ValueError('Die Antwort der Datenquelle ist zu groß.')
        payload=res.json()
    except (requests.RequestException,ValueError) as exc:
        raise ValueError('Aktuelle Ergebnisse sind gerade nicht erreichbar. Deine letzten Tipps bleiben gespeichert; bitte erneut versuchen.') from exc
    try:
        return validate_feed(payload,season,now)
    except (KeyError,TypeError,OverflowError) as exc:
        raise ValueError('Die Datenquelle hat ein unbekanntes Format. Keine neuen Tipps berechnet.') from exc


def read_screenshot(content):
    if len(content)>15_000_000:raise ValueError('Bitte einen Screenshot unter 15 MB verwenden.')
    try:
        with Image.open(io.BytesIO(content)) as image:
            if image.format not in ('PNG','JPEG','WEBP') or image.width*image.height>24_000_000:
                raise ValueError('Bitte einen PNG-, JPG- oder WebP-Screenshot bis 24 Megapixel verwenden.')
            image.load()
            cleaned=image.convert('RGB')
    except (UnidentifiedImageError,OSError,Image.DecompressionBombError) as exc:
        raise ValueError('Das Bild ist nicht lesbar. Bitte einen normalen Screenshot hochladen.') from exc
    source=ROOT/'local_ocr.swift'
    helper=OUTPUT/'.local_ocr'
    if not helper.exists() or helper.stat().st_mtime<source.stat().st_mtime:
        OUTPUT.mkdir(parents=True,exist_ok=True)
        try:
            subprocess.run(['/usr/bin/xcrun','swiftc',str(source),'-o',str(helper),
                            '-module-cache-path',str(OUTPUT/'.swift-cache')],
                           check=True,capture_output=True,timeout=120)
        except (OSError,subprocess.SubprocessError) as exc:
            raise ValueError('Die lokale Bilderkennung ist noch nicht startbereit. Du kannst ohne Screenshot automatisch den nächsten Spieltag optimieren.') from exc
    with tempfile.TemporaryDirectory(prefix='kicktipp-image-') as d:
        path=Path(d)/'screenshot.png';cleaned.save(path)
        try:
            run=subprocess.run([str(helper),str(path)],check=True,capture_output=True,text=True,timeout=40)
            lines=json.loads(run.stdout)
        except (OSError,subprocess.SubprocessError,ValueError) as exc:
            raise ValueError('Der Screenshot konnte nicht gelesen werden. Bitte die Ergebnisliste größer und scharf aufnehmen.') from exc
    if not lines:raise ValueError('Kein Text erkannt. Bitte einen scharfen Screenshot der Ergebnisliste verwenden.')
    return lines


def screenshot_round(lines, schedule, season):
    """Read fixture rows from OCR geometry; match exact aliases, never fuzzy guesses."""
    text='\n'.join(x['text'] for x in lines)
    years=re.findall(r'\b(20\d{2})\s*[/–-]\s*(20\d{2}|\d{2})\b',text)
    if years and any(int(y)!=season or int(end)%100!=(season+1)%100 for y,end in years):
        raise ValueError('Der Screenshot zeigt eine andere Saison. Bitte die aktuelle Ergebnisliste verwenden.')
    def clean_text(value):
        value=unicodedata.normalize('NFKD',str(value)).encode('ascii','ignore').decode().lower()
        return ' '.join(re.sub(r'[^a-z0-9 ]',' ',value).split())
    aliases={}
    clubs={r[k] for r in schedule for k in ('home','away')}
    for alias,club in ALIASES.items():
        if club in clubs:aliases[clean_text(alias)]=club
    for r in schedule:
        for side in ('home','away'):
            club=r[side]
            for alias in (club,r[side+'_name'],r[side+'_short']):aliases[clean_text(alias)]=club
    for alias,club in {'bvb':'dortmund','bmg':'gladbach','fcb':'bayern','s04':'schalke','koeln':'koln'}.items():
        if club in clubs:aliases[alias]=club
    def teams(text):
        clean=clean_text(text)
        found=[]
        for alias,club in aliases.items():
            for m in re.finditer(r'(?<!\w)'+re.escape(alias)+r'(?!\w)',clean):
                found.append((m.start(),-len(alias),club))
        ordered=[]
        for _,_,club in sorted(found):
            if club not in ordered:ordered.append(club)
        return ordered
    # Join independently recognized columns on the same visual row.
    rows=[]
    for line in sorted(lines,key=lambda x:(x['y'],x['x'])):
        if line.get('confidence',0)<.45:continue
        if rows and abs(rows[-1]['y']-line['y'])<=max(.004,min(rows[-1]['height'],line['height'])*.65):
            rows[-1]['parts'].append(line)
        else:rows.append({'y':line['y'],'height':line['height'],'parts':[line]})
    for row in rows:
        row['text']=' '.join(x['text'] for x in sorted(row['parts'],key=lambda x:x['x']))
        row['teams']=teams(row['text'])
    pairs=[]
    i=0
    while i<len(rows):
        row=rows[i];t=row['teams'];rowtext=row['text']
        if len(t)==1 and i+1<len(rows):
            j=i+1
            # A centered score can sit between vertically stacked home/away names.
            if not rows[j]['teams'] and j+1<len(rows):j+=1
            nxt=rows[j]
            combined=' '.join(r['text'] for r in rows[i:j+1])
            if len(nxt['teams'])==1 and nxt['y']-row['y']<2.3*max(row['height'],nxt['height']) and re.search(r'\d\s*[:–-]\s*\d',combined):
                t=t+nxt['teams'];rowtext=combined;i=j
        if len(t)==2 and t[0]!=t[1]:pairs.append((t[0],t[1],rowtext))
        i+=1
    matched=[]
    lookup={(r['home'],r['away']):r for r in schedule}
    for h,a,rowtext in pairs:
        r=lookup.get((h,a))
        if r is None:continue
        scores=[(int(x),int(y)) for x,y in re.findall(r'(?<!\d)(\d{1,2})\s*[:–-]\s*(\d{1,2})(?!\d)',rowtext)
                if int(x)<=15 and int(y)<=15]
        # A result screenshot may include tip and score columns. The official score must be among them.
        if scores and r['finished'] and (r['hg'],r['ag']) not in scores:
            raise ValueError(f'Screenshot und Endergebnis passen bei {pretty(h)} – {pretty(a)} nicht zusammen. Bitte die Ergebnisansicht statt eigener Tipps oder Zwischenstände aufnehmen.')
        matched.append(r)
    unique={r['id']:r for r in matched}
    rounds={r['round'] for r in unique.values()}
    if len(unique)<2:
        raise ValueError('Mindestens zwei klare Bundesliga-Paarungen werden benötigt. Bitte die Ergebnisliste mit beiden Teamnamen aufnehmen; eine Tabelle oder Rangliste reicht nicht.')
    if len(rounds)!=1:
        raise ValueError('Der Screenshot enthält mehrere Spieltage. Bitte nur einen Spieltag aufnehmen.')
    rnd=next(iter(rounds))
    heading=re.findall(r'\b(\d{1,2})\s*\.\s*Spieltag\b',text,re.I)
    if heading and any(int(x)!=rnd for x in heading):
        raise ValueError('Spieltag-Überschrift und erkannte Paarungen widersprechen sich. Bitte einen vollständigen Screenshot verwenden.')
    return {'round':rnd,'matched':len(unique),'finished':sum(r['finished'] for r in unique.values())}


def choose_fixtures(schedule, progress=None, now=None):
    now=now or datetime.now(BERLIN)
    cutoff=pd.Timestamp(now).tz_convert('UTC')+pd.Timedelta(minutes=15)
    available=[r for r in schedule if not r['finished'] and pd.Timestamp(r['kickoff'])>cutoff]
    if progress:
        # A completed screenshot marks progress; open screenshot fixtures target their own round.
        available=[r for r in available if r['round']>=progress['round']]
    if not progress:
        from weekly_review import weekly_cycle
        cycle=weekly_cycle(schedule,now)
        available=[r for r in available if r['round']==cycle['round']]
        if not available and cycle['phase']=='review':
            raise ValueError('Dieser Spieltag wird bis Dienstag rückwirkend bewertet. Es werden keine Tipps nach Anpfiff erfunden.')
    if not available:
        raise ValueError('Für diese Saison sind keine offenen, noch nicht gestarteten Spiele verfügbar.')
    rnd=min(r['round'] for r in available)
    selected=sorted([r for r in available if r['round']==rnd],key=lambda r:(r['kickoff'],r['id']))
    return rnd,selected


def historical_model(progress=lambda s:None):
    games,missing=load_data(DATA,first=2015,last=2025,allow_download=False)
    games=games[games.season.between(2015,2025)].reset_index(drop=True)
    if missing or any(int((games.season==y).sum())!=306 for y in range(2015,2026)):
        raise ValueError('Die historischen Trainingsdaten sind unvollständig. Bitte die lokale Installation prüfen lassen.')
    from advanced_model import choose_model
    bundle,report=choose_model(games,OUTPUT,progress)
    return games,bundle,report


def point_statistics(results):
    distribution=np.array([1.])
    for p in results:
        matrix=prediction_matrix(p)
        index=TIPS.index(tuple(map(int,p['tip'].split(':'))))
        points=SCORE_GRID[index].astype(int)
        pmf=np.bincount(points,weights=matrix.ravel(),minlength=5)
        distribution=np.convolve(distribution,pmf)
    cumulative=np.cumsum(distribution)
    quantile=lambda q:int(min(np.searchsorted(cumulative,q),len(distribution)-1))
    return {'expected_points':sum(p['ep'] for p in results),
            'expected_exact':sum(p['prob_exact'] for p in results),
            'points_low':quantile(.1),'points_high':quantile(.9),
            'pmf':[float(x) for x in distribution]}


def _optimize(content=None, progress=lambda s:None, now=None):
    now=now or datetime.now(BERLIN)
    season=season_now(now)
    progress('Aktuelle Ergebnisse und Spieltermine prüfen …')
    schedule=fetch_schedule(season,now)
    screenshot=None
    if content:
        progress('Screenshot lokal lesen und mit dem Spielplan abgleichen …')
        screenshot=screenshot_round(read_screenshot(content),schedule,season)
    rnd,selected=choose_fixtures(schedule,screenshot,now)
    progress('Historisch gewähltes Modell laden …')
    history,bundle,report=historical_model(progress)
    if season<=2025:raise ValueError('Für diesen Stichtag ist das Modell nicht unabhängig historisch getestet.')
    # A date-only engine must never consume today's results, even for later fixtures today.
    day=pd.Timestamp(now.astimezone(BERLIN).date())
    first_date=pd.Timestamp(min(r['date'] for r in selected))
    training_cutoff=min(day,first_date)
    finished=[r for r in schedule if r['finished'] and pd.Timestamp(r['date'])<training_cutoff]
    if len(finished)<9:
        raise ValueError('Noch zu wenige verifizierte Ergebnisse der aktuellen Saison. Bitte nach dem ersten vollständigen Spieltag erneut versuchen.')
    current=normalize(pd.DataFrame(finished)[['date','home','away','hg','ag']],source='OpenLigaDB')
    history=history[history.date<training_cutoff]
    games=pd.concat([history,current],ignore_index=True).sort_values(['date','home','away']).reset_index(drop=True)
    if games.duplicated(['date','home','away']).any():raise ValueError('Doppelte Trainingsspiele erkannt.')
    from market_model import choose_market, live_quotes, apply_market
    quotes,market_status=live_quotes(selected,now,OUTPUT)
    try:
        market_report=choose_market(history,bundle,OUTPUT,progress)
    except (ValueError,RuntimeError,requests.RequestException,OSError) as exc:
        market_report={'weight':0.,'maximum_weight':.3,'error':'Historischer Quotenvergleich nicht verfügbar; Marktgewicht 0 %.','detail':str(exc)}
    progress(f'{rnd}. Spieltag berechnen und Tipps auf 4/2/1-Punkte optimieren …')
    results=[]
    # Fit once per match date. The same frozen knowledge cutoff applies to every fixture.
    frame=pd.DataFrame(selected)
    for _,group in frame.groupby('date',sort=True):
        from advanced_model import ensemble_predictions
        pred=ensemble_predictions(games,group[['date','home','away']].assign(date=lambda d:pd.to_datetime(d.date)),bundle)
        for p,r in zip(pred,group.to_dict('records')):
            p=apply_market(p,quotes.get((r['home'],r['away'])),market_report['weight'],market_status)
            p.pop('_p_matrix',None)
            p.update({'kickoff':r['kickoff'],
                      'home_logo':r.get('home_logo',''),'away_logo':r.get('away_logo','')})
            h,a=map(int,p['tip'].split(':'))
            p['prob_tendency']=p['prob_home'] if h>a else p['prob_draw'] if h==a else p['prob_away']
            results.append(p)
    result={'version':VERSION,'season':season,'round':rnd,'created_at':now.isoformat(),
            'source':'OpenLigaDB','current_results':len(current),'history_results':len(history),
            'training_through':str(games.date.max().date()),'screenshot':screenshot,
            'input_hash':hashlib.sha256(content).hexdigest() if content else None,
            'results':results,'stats':point_statistics(results),
            'model_audit':report,'market_audit':market_report,'market_status':market_status,
            'historical':{'model':report['holdout_chosen'],'baseline':report['holdout_baseline'],
                          'interval':report['holdout_delta_ci']}}
    OUTPUT.mkdir(parents=True,exist_ok=True)
    atomic_json(OUTPUT/'lean_latest.json',result)
    # Preserve dated provenance for future comparison without storing the uploaded image.
    atomic_json(OUTPUT/f'lean_{now.strftime("%Y%m%d_%H%M%S_%f")}.json',result)
    return result


def optimize(content=None, progress=lambda s:None, now=None):
    OUTPUT.mkdir(parents=True,exist_ok=True)
    with (OUTPUT/'.optimize.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as exc:raise ValueError('Eine Optimierung läuft bereits. Bitte kurz warten.') from exc
        try:return _optimize(content,progress,now)
        finally:fcntl.flock(lock,fcntl.LOCK_UN)


def saved_result():
    try:
        r=json.loads((OUTPUT/'lean_latest.json').read_text())
        return r if r.get('version')==VERSION else None
    except (OSError,ValueError):return None
