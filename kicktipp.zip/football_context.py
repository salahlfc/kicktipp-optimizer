"""Sourced football review, separate from the numerical forecasting model.

No LLM, training, paid API or background worker. Reviewed assertions expire;
form is derived from verified results and headlines come from a public RSS feed.
"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from email.utils import parsedate_to_datetime
import html,json,re
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit
import pandas as pd
import requests
from webcore import pretty

ROOT=Path(__file__).resolve().parent
RSS_URL='https://www.sportschau.de/fussball/bundesliga/index~rss2.xml'
ALIASES={'hsv':['hsv','hamburger sv'],'gladbach':['gladbach','mönchengladbach'],'dortmund':['dortmund','bvb'],'elversberg':['elversberg'],'leipzig':['leipzig'],'augsburg':['augsburg'],'mainz':['mainz'],'bayern':['bayern'],'paderborn':['paderborn'],'frankfurt':['eintracht frankfurt','frankfurt'],'stuttgart':['stuttgart','vfb'],'bremen':['werder','bremen'],'koln':['köln','koeln'],'leverkusen':['leverkusen'],'freiburg':['freiburg'],'union':['union berlin'],'hoffenheim':['hoffenheim','tsg'],'schalke':['schalke','s04']}


def load_review():
    try:return json.loads((ROOT/'data/football_review.json').read_text())
    except (OSError,ValueError):return {'sources':{},'matches':[]}


def match_review(prediction,season,rnd,now,review=None):
    review=load_review() if review is None else review
    now=pd.Timestamp(now)
    for item in review.get('matches',[]):
        if (item['season'],item['round'],item['date'],item['home'],item['away'])!=(season,rnd,prediction['date'],prediction['home'],prediction['away']):continue
        checked=pd.Timestamp(review['checked_at']);kickoff=pd.Timestamp(prediction['kickoff'])
        valid=checked<=now and checked<kickoff and now<min(checked+pd.Timedelta(hours=24),kickoff)
        return {**item,'checked_at':checked.isoformat(),'fresh':bool(valid),'tip_matches':item['assessed_tip']==prediction['tip'],'sources':review['sources']}
    return None


def recent_form(schedule,club,cutoff):
    cutoff=pd.Timestamp(cutoff)
    games=sorted((r for r in (schedule or []) if r.get('finished') and club in (r['home'],r['away']) and pd.Timestamp(r['kickoff'])<cutoff),key=lambda r:r['kickoff'])[-5:]
    points=gf=ga=0;sequence=[]
    for r in games:
        a,b=(r['hg'],r['ag']) if r['home']==club else (r['ag'],r['hg'])
        gf+=a;ga+=b;points+=3 if a>b else 1 if a==b else 0
        sequence.append('S' if a>b else 'U' if a==b else 'N')
    return {'games':len(games),'points':points,'goals_for':gf,'goals_against':ga,'sequence':sequence}


def parse_news(content,now):
    if len(content)>1_000_000 or b'<!DOCTYPE' in content.upper() or b'<!ENTITY' in content.upper():raise ValueError('Ungültiger Nachrichtenfeed')
    now=pd.Timestamp(now);result=[];seen=set()
    for item in ET.fromstring(content).findall('./channel/item')[:100]:
        title=html.unescape(' '.join(item.findtext('title','').split()))
        link=item.findtext('link','').strip();parts=urlsplit(link)
        if not title or parts.scheme!='https' or parts.hostname not in ('www.sportschau.de','sportschau.de'):continue
        try:date=pd.Timestamp(parsedate_to_datetime(item.findtext('pubDate','')))
        except (ValueError,TypeError,OverflowError):continue
        if date.tzinfo is None or not now-pd.Timedelta(days=7)<=date<=now or link in seen:continue
        description=html.unescape(re.sub('<[^>]+>',' ',item.findtext('description','')))
        def mentioned(text):
            return [club for club,aliases in ALIASES.items() if any(re.search(r'(?<!\w)'+re.escape(a)+r'(?!\w)',text.casefold()) for a in aliases)]
        # A passing reference to the last opponent must not attach a headline to that club.
        clubs=mentioned(title) or mentioned(description)
        if not clubs:continue
        seen.add(link);result.append({'title':title[:240],'url':link,'published_at':date.isoformat(),'clubs':clubs})
    return sorted(result,key=lambda r:r['published_at'],reverse=True)


def fetch_news(now):
    checked=pd.Timestamp(now).isoformat()
    try:
        r=requests.get(RSS_URL,timeout=(2,4),headers={'User-Agent':'Kicktipp-local-context/1.0'});r.raise_for_status()
        return {'checked_at':checked,'items':parse_news(r.content,now),'ok':True}
    except (requests.RequestException,ValueError,ET.ParseError):
        return {'checked_at':checked,'items':[],'ok':False}


def news_for_match(news,prediction,now):
    cutoff=min(pd.Timestamp(now),pd.Timestamp(prediction['kickoff']))
    return [n for n in news.get('items',[]) if pd.Timestamp(n['published_at'])<cutoff and any(c in n['clubs'] for c in (prediction['home'],prediction['away']))][:3]


def source_links(st,record,ids):
    links=[]
    for key in dict.fromkeys(ids):
        source=record['sources'].get(key)
        if source:links.append('['+source['title']+']('+source['url']+')')
    if links:st.caption('Quellen: '+' · '.join(links))


def render_match(st,prediction,season,rnd,schedule,now,news):
    review=match_review(prediction,season,rnd,now)
    st.subheader('Fußballerische Einordnung')
    if review and review['fresh']:
        st.caption('Geprüft am '+pd.Timestamp(review['checked_at']).tz_convert('Europe/Berlin').strftime('%d.%m.%Y · %H:%M')+' · Einordnung des gespeicherten Tipps, kein zusätzlicher Modellfaktor')
        if review['tip_matches']:
            st.markdown('**Dafür spricht:** '+review['supports'])
            st.markdown('**Dagegen spricht:** '+review['risks'])
            source_links(st,review,review['analysis_sources'])
        else:st.info('Die Fakten wurden für einen anderen Tipp geprüft. Für den aktuellen Tipp liegt noch kein neuer Pro-/Contra-Check vor.')
        for label,key in (('Ausfälle & Fragezeichen','personnel'),('Aufstellung','lineup'),('Belastung & Rotation','workload')):
            text=review[key]
            st.markdown('**'+label+':** '+text['text'])
            source_links(st,review,text['sources'])
        st.caption('Startelf: hier nur eine Vorschau, keine bestätigte Aufstellung. Ein kurzer Spielabstand zeigt ein Belastungsrisiko; eine tatsächliche Rotation ist damit nicht bewiesen.')
    else:
        if review:st.warning('Der Fußballcheck ist älter als 24 Stunden oder das Spiel hat begonnen. Ausfälle und Aufstellung werden deshalb nicht als aktuelle Fakten angezeigt.')
        else:st.info('Für diese Partie liegt noch kein geprüfter Ausfall-, Startelf- und Belastungscheck vor. Fehlende Meldungen bedeuten nicht, dass alle Spieler fit sind.')
    st.markdown('**Form / Momentum – letzte fünf Ligaspiele:**')
    cutoff=min(pd.Timestamp(now),pd.Timestamp(prediction['kickoff']))
    for club in (prediction['home'],prediction['away']):
        f=recent_form(schedule,club,cutoff)
        if f['games']:st.write(f"{pretty(club)}: {' · '.join(f['sequence'])} · {f['points']} Punkte aus {f['games']} Spielen · Tore {f['goals_for']}:{f['goals_against']}")
        else:st.write(pretty(club)+': verifizierte Formdaten aktuell nicht verfügbar.')
    st.caption('S = Sieg · U = Remis · N = Niederlage; ältestes Spiel links. Quelle: OpenLigaDB. Die Form beschreibt Ergebnisse, keine gemessene mentale Verfassung.')
    st.markdown('**Aktuelle Nachrichten:**')
    items=news_for_match(news,prediction,now)
    for n in items:
        title=n['title'].replace('[','\\[').replace(']','\\]')
        st.markdown('['+title+']('+n['url']+')')
        st.caption('Sportschau · '+pd.Timestamp(n['published_at']).tz_convert('Europe/Berlin').strftime('%d.%m.%Y · %H:%M'))
    if not items:st.caption('Keine zuordenbare aktuelle Meldung im Feed.' if news.get('ok') else 'Nachrichtenfeed gerade nicht erreichbar.')
    st.caption('Nachrichten werden beim Öffnen des Deep Dive höchstens alle 15 Minuten geladen. Eine neue Schlagzeile aktualisiert nicht automatisch den oben datierten Personalcheck.')


def render_round(st,result,now):
    data=load_review();records=[match_review(p,result['season'],result['round'],now,data) for p in result['results']]
    valid=[r for r in records if r and r['fresh'] and r['tip_matches']]
    if valid and len(valid)==len(result['results']):
        st.markdown('**Fußballcheck für den Spieltag:** '+data['round_summary'])
        source_links(st,valid[0],data['round_sources'])
        st.caption('Recherche vom '+pd.Timestamp(data['checked_at']).tz_convert('Europe/Berlin').strftime('%d.%m.%Y · %H:%M')+' · Diese Prüfung kann einem Modelltipp widersprechen. Spieler- und Belastungseffekte sind noch nicht als eigene Modellgewichte trainiert.')
    else:st.caption(f'{len(valid)}/{len(records)} Partien mit aktuellem, zum Tipp passendem Fußballcheck. Details und verfügbare Formdaten stehen beim Einzelspiel.')
