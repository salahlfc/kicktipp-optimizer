"""KickTipp: focused predictions, matchday review and model information."""
import html
import re
import pandas as pd
import streamlit as st
from leanflow import BERLIN, OUTPUT, optimize, saved_result, point_statistics, fetch_schedule, season_now
from weekly_review import weekly_cycle, latest_round, assess_round, learning_history, calibration_summary
from presentation import traffic, summarize, explain, explain_round, team_line
from webcore import pretty
from engine import prediction_matrix
from matchday_live import matchday_result, match_state, render_match_assessment, render_round_assessment
from appearance import theme_css
from model_info import info_sections
from kickbase_projection import add_kickbase_estimates
from football_context import render_match as render_football_match, render_round as render_football_round, fetch_news
from team_context_api import refresh_projected_lineup, add_official_player_portraits

st.set_page_config(page_title='KickTipp · Häuser Buli Cup',page_icon='⚽',layout='centered',initial_sidebar_state='collapsed')
st.markdown('''<style>
.block-container{max-width:980px;padding-top:1rem;padding-bottom:3rem}
header[data-testid="stHeader"]{background:transparent}
h1{font-size:2.1rem!important;letter-spacing:-.045em}.eyebrow{color:var(--kt-muted);font-size:.7rem;letter-spacing:.16em;font-weight:750}
.stButton>button[kind="primary"]{min-height:3.3rem;border-radius:13px;font-weight:750}
.tip-card{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:16px;padding:16px;margin:12px 0}
.tip-top{color:var(--kt-muted);font-size:.74rem;margin-bottom:10px}.tip-main{display:flex;align-items:center;justify-content:space-between;gap:12px}
.team-line{display:flex;align-items:center;gap:9px;min-height:36px;font-weight:650}.crest{display:flex;align-items:center;justify-content:center;width:28px;height:29px}.crest img{width:27px;height:27px;object-fit:contain}
.tip-score{font-size:2.3rem;font-weight:800;color:var(--kt-fg);white-space:nowrap}.badge{border-radius:22px;padding:5px 9px;font-size:.72rem;font-weight:750;display:inline-block;margin-bottom:12px}
.green{background:#153d29;color:#a2e8b5}.yellow{background:#463b19;color:#ffe49c}.red{background:#42272b;color:#ffb7bc}
.tip-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;border-top:1px solid var(--kt-border);margin-top:14px;padding-top:12px}.tip-stats b{font-size:1.13rem;display:block}.tip-stats span{font-size:.7rem;color:var(--kt-muted)}
.total{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:15px;padding:16px;margin:14px 0}.total b{font-size:1.9rem;color:var(--kt-fg)}.total small{display:block;color:var(--kt-muted)}
.lineups-grid,.availability-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:10px 0}.lineup-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:14px;padding:12px;min-width:0}.lineup-heading{display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:9px}.lineup-heading img{width:25px;height:25px;object-fit:contain}.lineup-pitch{border:1px solid var(--kt-border);border-radius:10px;padding:9px 4px;background:linear-gradient(90deg,transparent 49.8%,var(--kt-border) 50%,transparent 50.2%)}.lineup-row{display:flex;justify-content:center;align-items:flex-start;gap:3px;margin:8px 0}.lineup-player{width:20%;max-width:76px;min-width:0;text-align:center;font-size:.61rem;line-height:1.12;overflow-wrap:anywhere}.player-face{position:relative;display:block;width:35px;height:35px;border-radius:50%;overflow:hidden;border:1px solid var(--kt-border);margin:0 auto 4px;background:var(--kt-bg)}.player-face img,.player-face .lineup-avatar{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:50%;object-fit:cover;margin:0}.player-face .lineup-avatar{display:grid;place-items:center;background:var(--kt-bg);font-size:.7rem;font-weight:750}.kb-points{display:block;color:var(--kt-muted);font-size:.58rem;font-weight:700;line-height:1.2;margin-top:3px}.lineup-total{margin-left:auto;color:var(--kt-fg);font-size:.76rem;font-weight:800;white-space:nowrap}.lineup-role{font-size:.57rem;color:var(--kt-muted);text-align:center;letter-spacing:.1em;text-transform:uppercase}.lineup-empty{border:1px dashed var(--kt-border);border-radius:12px;padding:12px;color:var(--kt-muted);font-size:.86rem}.lineup-state{display:flex;align-items:center;gap:10px;border:1px solid var(--kt-border);border-radius:12px;background:var(--kt-bg);padding:12px;margin:8px 0}.lineup-state img{width:38px;height:38px;object-fit:contain}.lineup-state b{display:block}.lineup-state small{color:var(--kt-muted)}.empty-pitch{height:74px;border:1px solid var(--kt-border);border-radius:9px;margin-top:9px;position:relative;background:linear-gradient(90deg,transparent 49.6%,var(--kt-border) 50%,transparent 50.4%),linear-gradient(0deg,transparent 49.4%,var(--kt-border) 50%,transparent 50.6%)}.empty-pitch:before{content:'';position:absolute;inset:6px auto 6px 50%;width:24px;border:1px solid var(--kt-border);border-radius:50%;transform:translateX(-50%)}.availability-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:14px;padding:12px;min-width:0}.availability-title{display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:9px}.availability-title img{width:24px;height:24px;object-fit:contain}.absence-item{display:flex;align-items:center;gap:9px;padding:8px 0;border-top:1px solid var(--kt-border)}.absence-item img,.absence-avatar{width:34px;height:34px;border-radius:50%;object-fit:cover;flex:none;border:1px solid var(--kt-border)}.absence-avatar{display:grid;place-items:center;background:var(--kt-bg);font-size:.72rem;font-weight:750}.absence-copy{min-width:0}.absence-copy b{display:block;font-size:.85rem}.absence-copy small{display:block;color:var(--kt-muted);font-size:.72rem}.availability-empty{font-size:.82rem;color:var(--kt-muted);padding:7px 0}.team-update{border:1px solid var(--kt-border);border-radius:14px;background:var(--kt-card);padding:12px 14px;margin:10px 0;color:var(--kt-muted);font-size:.82rem}.team-status{display:flex;align-items:center;gap:12px;border:1px solid var(--kt-border);border-radius:15px;background:var(--kt-card);padding:12px 14px;margin:12px 0;box-shadow:var(--kt-shadow)}.team-status-icon{display:grid;place-items:center;width:31px;height:31px;flex:none;border:1px solid var(--kt-border);border-radius:11px;background:var(--kt-soft);font-weight:800}.team-status-copy{min-width:0}.team-status-copy b{display:block;font-size:.8rem}.team-status-copy small{display:block;color:var(--kt-muted);font-size:.73rem;line-height:1.4;margin-top:2px}.team-status.partial .team-status-icon{border-style:dashed}
.lineup-list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.lineup-list .lineup-player{width:auto;max-width:none;border:1px solid var(--kt-border);border-radius:9px;background:var(--kt-bg);padding:7px 3px;font-size:.67rem}
.kpi{color:var(--kt-muted);font-size:.85rem}.chart{display:flex;align-items:end;gap:4px;height:140px;margin:10px 0 24px}.bar{flex:1;min-width:0;text-align:center;color:var(--kt-muted);font-size:.65rem}.bar i{display:block;background:var(--kt-fg);border-radius:4px 4px 0 0;margin-bottom:5px}
@media(max-width:640px){.block-container{padding-left:1rem;padding-right:1rem}.team-line{font-size:.91rem}.tip-score{font-size:2rem}.lineups-grid,.availability-grid{grid-template-columns:1fr}.lineup-player{width:19%;font-size:.58rem}.lineup-player img,.lineup-avatar{width:32px;height:32px}}
</style>''',unsafe_allow_html=True)
# Remove obsolete page state when an already-open session receives this update.
for obsolete in list(st.session_state):
    if obsolete=='portal' or obsolete.startswith(('watch_','sportbet_','betting_','open_watch','open_sportbet','open_betting','paper_','local_savings_')):
        del st.session_state[obsolete]
st.markdown('<div class="app-brand"><div class="app-brand-mark">⚽</div><div><b>KICKTIPP</b><small>Häuser Buli Cup · 4 / 2 / 1</small></div></div>',unsafe_allow_html=True)
pages=['Hauptseite','Expected S11','Deep Dive','Info']
if st.session_state.get('kicktipp_page') not in [None,*pages]:
    st.session_state['kicktipp_page']='Hauptseite'
page=st.radio('Seite',pages,horizontal=True,label_visibility='collapsed',key='kicktipp_page')
if page=='Info':
    modes=['System','Dunkel','Hell']
    st.session_state['design']=st.selectbox('Darstellung',modes,index=modes.index(st.session_state.get('design','System')),key='appearance_choice')
st.markdown(theme_css(st.session_state.get('design','System')),unsafe_allow_html=True)

def show_table(data,**kwargs):
    st.markdown('<div class="data-table">'+data.to_html(index=False,escape=True,border=0)+'</div>',unsafe_allow_html=True)


def lineup_markup(team,formation,logo,players):
    logo=str(logo or '')
    logo=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    groups={'Angriff':[],'Mittelfeld':[],'Abwehr':[],'Tor':[],'Spieler':[]}
    for player in players:
        pos=str(player.get('position','')).casefold()
        role='Tor' if 'goalkeeper' in pos or 'keeper' in pos or 'torwart' in pos else 'Abwehr' if 'defend' in pos or 'verteidig' in pos else 'Mittelfeld' if 'midfield' in pos or 'mittelfeld' in pos else 'Angriff' if 'forward' in pos or 'attacker' in pos or 'stürm' in pos else 'Spieler'
        groups[role].append(player)
    digits=[int(n) for n in re.findall(r'\d+',str(formation or ''))]
    valid_formation=digits if len(digits) in (3,4) and sum(digits)==10 else []
    if not valid_formation:
        outfield=[len(groups['Abwehr']),len(groups['Mittelfeld']),len(groups['Angriff'])]
        if outfield[0]>=3 and outfield[1]>=2 and outfield[2]>=1 and sum(outfield)==10:
            valid_formation=outfield
            formation='-'.join(map(str,outfield))
    rows=[]
    if valid_formation and len(groups['Tor'])==1 and len(groups['Abwehr'])==valid_formation[0] and len(groups['Angriff'])==valid_formation[-1] and len(groups['Mittelfeld'])==sum(valid_formation[1:-1]):
        rows.append(('Angriff',groups['Angriff']))
        midfield=groups['Mittelfeld'];line_numbers=list(range(1,len(valid_formation)-1))
        tagged=all(int(p.get('line_group',-1)) in line_numbers for p in midfield)
        cursor=0
        for line_index,count in reversed(list(zip(line_numbers,valid_formation[1:-1]))):
            line=[p for p in midfield if int(p.get('line_group',-1))==line_index] if tagged else midfield[cursor:cursor+count]
            if not tagged:cursor+=count
            rows.append(('Mittelfeld',line))
        rows.extend([('Abwehr',groups['Abwehr']),('Tor',groups['Tor'])])
    else:
        rows=[(k,v) for k,v in groups.items() if v and k!='Spieler']
        if groups['Spieler']:
            rows.append(('Startelf',groups['Spieler']))
        if len(rows)==1 and rows[0][0]=='Startelf':
            formation=''
    parts=[]
    for role,items in rows:
        cards=[]
        for player in items:
            name=str(player.get('name','Spieler'))[:80]
            image=str(player.get('image',''))
            initials=html.escape(''.join(w[:1] for w in name.split()[:2]).upper())
            if image.startswith('https://') and len(image)<500:
                avatar=f'<span class="player-face"><img loading="lazy" src="{html.escape(image,quote=True)}" alt="" onerror="this.onerror=null;this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'"><span class="lineup-avatar" style="display:none">{initials}</span></span>'
            else:
                avatar=f'<span class="player-face"><span class="lineup-avatar">{initials}</span></span>'
            point_tag=''
            if player.get('kb_expected_points') is not None:
                point_tag=f'<small class="kb-points">{int(player["kb_expected_points"])} P</small>'
            cards.append(f'<div class="lineup-player">{avatar}{html.escape(name)}{point_tag}</div>')
        parts.append('<div class="lineup-role">'+html.escape(role)+' '+str(len(items))+'</div><div class="lineup-row">'+''.join(cards)+'</div>')
    total=sum(float(x.get('kb_expected_points',0) or 0) for x in players if isinstance(x,dict))
    total_tag=f'<small class="lineup-total">{total:.0f} P</small>' if any(x.get('kb_expected_points') is not None for x in players if isinstance(x,dict)) else ''
    formation_tag=f'<small style="margin-left:8px;color:var(--kt-muted);white-space:nowrap">{html.escape(str(formation or ""))}</small>' if formation else ''
    return f'<div class="lineup-card"><div class="lineup-heading">{logo}<span>{html.escape(pretty(team))}</span>{total_tag}{formation_tag}</div><div class="lineup-pitch">'+''.join(parts)+'</div></div>'


def lineup_pending_markup(team,logo):
    logo=str(logo or '')
    crest=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    return f'<div class="lineup-card"><div class="lineup-state">{crest}<div><b>{html.escape(pretty(team))}</b><small>Voraussichtliche Aufstellung</small></div></div><div class="empty-pitch" aria-hidden="true"></div><small style="display:block;color:var(--kt-muted);margin-top:8px">Noch nicht von der Datenquelle veröffentlicht.</small></div>'


def absence_markup(team,logo,players,check_complete):
    logo=str(logo or '')
    crest=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    items=[]
    for player in players:
        name=str(player.get('name','Spieler'))[:80]
        image=str(player.get('image',''))
        if image.startswith('https://live-football-api.com/people/'):
            avatar=f'<img src="{html.escape(image,quote=True)}" alt="">'
        else:
            initials=html.escape(''.join(w[:1] for w in name.split()[:2]).upper())
            avatar=f'<span class="absence-avatar">{initials}</span>'
        details=' · '.join(x for x in (str(player.get('position','')).strip(),str(player.get('status','')).strip()) if x)
        items.append(f'<div class="absence-item">{avatar}<div class="absence-copy"><b>{html.escape(name)}</b><small>{html.escape(details or "Ausfallmeldung")}</small></div></div>')
    if not items:
        message='Keine bestätigten Ausfälle gemeldet.' if check_complete else 'In diesem Lauf nicht verlässlich geprüft.'
        items=[f'<div class="availability-empty">{message}</div>']
    return f'<div class="availability-card"><div class="availability-title">{crest}<span>{html.escape(pretty(team))}</span></div>'+''.join(items)+'</div>'


def render_team_context(st,p,created,now,compact=False):
    context=p.get('team_context') or {};lineup_data=context.get('lineups') or {}
    home_data=lineup_data.get('home') or {};away_data=lineup_data.get('away') or {}
    home_line=home_data.get('starting',[]);away_line=away_data.get('starting',[])
    logos=context.get('team_logos') or {}
    if not compact:
        checked_raw=context.get('injuries_checked_at') or context.get('checked_at')
        checked_label='–'
        if checked_raw:
            checked=pd.Timestamp(checked_raw)
            if checked.tzinfo is None:checked=checked.tz_localize('UTC')
            checked=checked.tz_convert(BERLIN)
            checked_label=checked.strftime('%d.%m. · %H:%M')
        st.caption(f"Stand {created.strftime('%d.%m. %H:%M')} · Teamnews {checked_label}")
    if lineup_data.get('is_projected'):
        st.caption('EXPECTED S11' if compact else 'VORAUSSICHTLICH')
    elif len(home_line)>=11 and len(away_line)>=11:
        st.caption('BESTÄTIGT')
    elif home_line or away_line:
        st.caption('TEILWEISE')
    else:
        st.caption('S11 noch nicht verfügbar')
    cards=lineup_markup(p['home'],home_data.get('formation'),logos.get('home') or p.get('home_logo'),home_line) if home_line else lineup_pending_markup(p['home'],logos.get('home') or p.get('home_logo'))
    cards+=lineup_markup(p['away'],away_data.get('formation'),logos.get('away') or p.get('away_logo'),away_line) if away_line else lineup_pending_markup(p['away'],logos.get('away') or p.get('away_logo'))
    st.markdown('<div class="lineups-grid">'+cards+'</div>',unsafe_allow_html=True)
    source_url=context.get('source_url') or lineup_data.get('source_url')
    if context.get('source')=='Bundesliga.com' and source_url and source_url.startswith('https://www.bundesliga.com/'):
        st.markdown(f'[Bundesliga ↗]({source_url})')
    absences=context.get('absences_by_team') or {};complete=bool(context.get('injury_check_complete'))
    home_out=absences.get('home') or [];away_out=absences.get('away') or []
    absence_cards=absence_markup(p['home'],logos.get('home') or p.get('home_logo'),home_out,complete)
    absence_cards+=absence_markup(p['away'],logos.get('away') or p.get('away_logo'),away_out,complete)
    st.markdown('<div class="availability-grid">'+absence_cards+'</div>',unsafe_allow_html=True)
    if not compact:
        st.caption('Vorberichte sind voraussichtlich und ändern die Tippchance nicht.')

@st.cache_data(ttl=900,show_spinner=False)
def current_football_news():
    return fetch_news(pd.Timestamp.now(tz=BERLIN))

@st.cache_data(ttl=60,show_spinner=False)
def current_schedule(season):
    return fetch_schedule(season)


def review_view(review,compact=False,notes=True):
    if not review:return
    st.subheader(f"Rückblick · Spieltag {review['round']}")
    if review['evaluated']:
        a,b,c=st.columns(3)
        a.metric('Erzielte Modellpunkte',review['points'])
        b.metric('Expected Points',f"{review['expected_points']:.2f}")
        c.metric('Abweichung zu EP',f"{review['delta_points']:+.2f}")
        if notes:st.caption(f"{review['evaluated']} vorab gespeicherte Tipps bewertet · {review['finished']}/{review['games']} Endergebnisse bekannt. Expected Points beziehen sich auf dieselben bewerteten Spiele.")
    else:
        if notes:st.info(f"{review['finished']}/{review['games']} Spiele beendet. Es gibt noch keine auswertbaren, vor Anpfiff gespeicherten Tipps für diesen Spieltag.")
        else:st.info(f"{review['finished']}/{review['games']} beendet · 0 vorab gespeicherte Tipps")
    if compact:
        rows=[{'Spiel':pretty(r['home'])+' – '+pretty(r['away']),'Tipp':r['tip'] or '–','Ergebnis':r['actual'] or '–',
               'Punkte':str(r['points']) if r['points'] is not None else '–','EP':f"{r['ep']:.2f}" if r['ep'] is not None else '–',
               'Δ':f"{r['delta_points']:+.2f}" if r.get('delta_points') is not None else '–'} for r in review['rows']]
        show_table(pd.DataFrame(rows))
    else:
        rows=[{'Partie':f"{pretty(r['home'])} – {pretty(r['away'])}",'Tipp':r['tip'] or '–','Ergebnis':r['actual'] or '–',
               'Punkte':str(r['points']) if r['points'] is not None else '–',
               'Expected Points':f"{r['ep']:.2f}" if r['ep'] is not None else '–',
               'Abweichung':f"{r['delta_points']:+.2f}" if r.get('delta_points') is not None else '–','Stand':r['status']} for r in review['rows']]
        show_table(pd.DataFrame(rows),hide_index=True,width='stretch')
    if notes:st.caption('Bewertet werden gespeicherte Modelltipps, nicht automatisch deine tatsächlich bei Kicktipp abgegebenen Tipps. Bei mehreren Läufen gilt pro Spiel der letzte gültige Tipp vor Anpfiff.')


@st.fragment(run_every=60)
def render_site(page):
    now=pd.Timestamp.now(tz=BERLIN)
    result=st.session_state.get('v3_result') or saved_result()
    schedule=None;cycle=None;review=None;current_review=None
    try:
        schedule=current_schedule(season_now(now))
        cycle=weekly_cycle(schedule,now)
        if cycle['review_round'] is not None:
            review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now) if cycle['round'] is not None else None
        if cycle['round'] is not None:
            current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    except Exception as exc:
        st.warning(f'Spieltag konnte gerade nicht aktualisiert werden: {exc}')

    if page=='Info':
        st.title('Info')
        for section in info_sections(result):
            with st.expander(section['title']):st.write(section['body'])
        if result:
            stats=point_statistics(result['results'])
            a,b,c=st.columns(3)
            a.metric('Expected Points',f"{stats['expected_points']:.2f}")
            b.metric('Tore / Teamspiel',f"{sum(p['lambda_home']+p['lambda_away'] for p in result['results'])/max(1,2*len(result['results'])):.2f}")
            c.metric('Spiele',len(result['results']))
            audit=result.get('model_audit',{});market=result.get('market_audit',{})
            if audit:
                with st.expander('Modellprüfung'):
                    st.write(f"Test: {audit['holdout_chosen']['points_per_game']:.3f} Punkte/Spiel · Vergleich {audit['holdout_baseline']['points_per_game']:.3f}.")
                    ci=audit['holdout_delta_ci'];st.write(f"95-%-Intervall: {ci['ci95_low']:+.3f} bis {ci['ci95_high']:+.3f} Punkte/Spiel.")
                    show_table(pd.DataFrame(audit['candidates'])[['family','half_life','ridge','points_per_game','score_log_loss','brier_1x2']])
            if market.get('trials'):
                with st.expander('Quotenvergleich'):
                    show_table(pd.DataFrame(market['trials']))
                    st.write(f"{market['validation_games']} Validierungsspiele · {market['test_games']} Testspiele.")
        calibration=calibration_summary(learning_history(OUTPUT))
        with st.expander('Wahrscheinlichkeiten im Rückblick'):
            if calibration['games']:show_table(pd.DataFrame(calibration['buckets']))
            else:st.caption('Noch keine abgeschlossenen Tipps auswertbar.')
        return

    reviewing=cycle is not None and cycle['phase']=='review'
    if page=='Deep Dive':
        st.title('Deep Dive')
        deep_dive_mode=st.radio('Spieltag',['Nächster Spieltag','Letzter Spieltag'],horizontal=True,
                                label_visibility='collapsed',key='deep_dive_matchday')
        if deep_dive_mode=='Letzter Spieltag':
            if review:review_view(review,compact=True,notes=False)
            else:st.caption('Noch kein bewerteter Spieltag.')
            return

    if page=='Hauptseite':
        st.title('Hauptseite')
        button_label='Ergebnisse aktualisieren' if reviewing else 'Tipps optimieren'
        clicked=st.button(button_label,type='primary',width='stretch')
        has_open=schedule is not None and cycle is not None and any(r['round']==cycle['round'] and not r['finished'] and pd.Timestamp(r['kickoff'])>now+pd.Timedelta(minutes=15) for r in schedule)
        needs_cycle_forecast=cycle and not reviewing and (result is None or pd.Timestamp(result['created_at'])<pd.Timestamp(cycle['anchor']))
        auto_key=(season_now(now),cycle['anchor'],cycle['round']) if cycle else None
        retry=st.session_state.get('weekly_auto_attempt')
        auto=needs_cycle_forecast and (not retry or retry[0]!=auto_key or (now-pd.Timestamp(retry[1])).total_seconds()>300)
        if clicked or auto:
            st.session_state.pop('v3_error',None)
            if auto:st.session_state['weekly_auto_attempt']=(auto_key,now.isoformat())
            try:
                if reviewing and not has_open:
                    current_schedule.clear();schedule=current_schedule(season_now(now))
                    review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
                    st.success('Spieltag aktualisiert.')
                else:
                    with st.status('Tipps werden optimiert …',expanded=False) as state:
                        result=optimize(now=now.to_pydatetime())
                        st.session_state['v3_result']=result
                        current_schedule.clear()
                        state.update(label='Fertig',state='complete',expanded=False)
            except Exception as exc:
                st.session_state['v3_error']=str(exc);st.error(str(exc))
        if reviewing:review_view(review,compact=True,notes=False)
        if review and not reviewing:
            with st.expander(f"Letzter Spieltag · {review['round']}"):
                review_view(review,compact=True,notes=False)

    if schedule is not None and cycle and cycle['round'] is not None:
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now)
        current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    if not result:
        if page in ('Expected S11','Deep Dive'):st.caption('Noch keine Prognose für den nächsten Spieltag.')
        return
    created=pd.Timestamp(result['created_at']).tz_convert(BERLIN)
    games=result['results']
    review_rows={(r['home'],r['away']):r for r in (current_review or {}).get('rows',[])}
    stats=point_statistics(games)

    if page=='Hauptseite':
        summary=summarize(stats['pmf'])
        a,b,c=st.columns(3)
        a.metric('Expected Points',f"{stats['expected_points']:.2f}")
        b.metric('Median',summary['median'])
        c.metric('Punkte ≥ 10',f"{summary['at_least_ten']:.0%}")
        st.caption(f"Spieltag {result['round']} · {len(games)} Spiele · {created.strftime('%d.%m. %H:%M')}")
        for p in games:
            state=match_state(p,schedule,now);row=review_rows.get((p['home'],p['away']))
            dt=pd.Timestamp(p['kickoff']).tz_convert(BERLIN)
            score=html.escape(state['label']+' · '+state['score'])
            teams=team_line(p['home'],p.get('home_logo',''))+team_line(p['away'],p.get('away_logo',''))
            color,emoji,label,_=traffic(p['prob_tendency'])
            points=f" · {row['points']} pt" if row and row.get('points') is not None else ''
            st.markdown(f'''<div class="tip-card"><div class="tip-top">{dt.strftime('%d.%m. · %H:%M')} · {score}{points}</div>
<div class="tip-main"><div>{teams}</div><div class="tip-score">{p['tip']}</div></div>
<div class="badge {color}">{emoji} {label} · {p['prob_tendency']:.0%}</div>
<div class="tip-stats"><div><b>{p['ep']:.2f}</b><span>Expected Points</span></div><div><b>{p['prob_exact']:.0%}</b><span>Exakt</span></div></div></div>''',unsafe_allow_html=True)
        return

    if page=='Expected S11':
        st.title(f"Expected S11 · Spieltag {result['round']}")
        st.caption('Kickbase-Punkte pro Spieler')
        for p in games:
            refresh_projected_lineup(p,result.get('season'),result['round'])
            add_kickbase_estimates(p)
        add_official_player_portraits(games)
        for p in games:
            lineups=(p.get('team_context') or {}).get('lineups') or {}
            home_n=len((lineups.get('home') or {}).get('starting',[]));away_n=len((lineups.get('away') or {}).get('starting',[]))
            marker='✓' if home_n>=11 and away_n>=11 and not lineups.get('is_projected') else f'{home_n}/{away_n}'
            with st.expander(f"{pretty(p['home'])} – {pretty(p['away'])} · {marker}"):
                render_team_context(st,p,created,now,compact=True)
        return

    st.title(f"Spieltag {result['round']}")
    summary=summarize(stats['pmf'])
    a,b,c=st.columns(3)
    a.metric('Expected Points',f"{stats['expected_points']:.2f}")
    b.metric('Median',summary['median'])
    c.metric('Punkte ≥ 10',f"{summary['at_least_ten']:.0%}")
    selected=st.selectbox('Spiel',range(len(games)),format_func=lambda i:pretty(games[i]['home'])+' – '+pretty(games[i]['away']),label_visibility='collapsed')
    p=games[selected];matrix=prediction_matrix(p)
    state=match_state(p,schedule,now);row=review_rows.get((p['home'],p['away']))
    st.caption(f"{p['tip']} · {state['label']} {state['score']}"+(f" · {row['points']} Punkte" if row and row.get('points') is not None else ''))
    a,b=st.columns(2)
    a.metric('Expected Points',f"{p['ep']:.2f}")
    b.metric('Exakt',f"{p['prob_exact']:.0%}")
    a,b=st.columns(2)
    a.metric('Tendenz',f"{p['prob_tendency']:.0%}")
    b.metric('1 / X / 2',f"{p['prob_home']:.0%} / {p['prob_draw']:.0%} / {p['prob_away']:.0%}")
    with st.expander('Expected S11 & Ausfälle'):
        render_team_context(st,p,created,now,compact=True)
    scores=sorted(((float(matrix[h,a]),f'{h}:{a}') for h in range(len(matrix)) for a in range(len(matrix))),reverse=True)[:5]
    show_table(pd.DataFrame([{'Ergebnis':t,'Chance':f'{v:.1%}'} for v,t in scores]))
    point_probs=explain(p)['points']
    show_table(pd.DataFrame([{'Punkte':k,'Chance':f"{point_probs[k]:.1%}"} for k in (4,2,1,0)]))
render_site(page)
