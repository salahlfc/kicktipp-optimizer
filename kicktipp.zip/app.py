"""Two-screen local optimizer: focused action and separate model investigation."""
import html
import pandas as pd
import streamlit as st
from leanflow import BERLIN, OUTPUT, optimize, saved_result, point_statistics, fetch_schedule, season_now
from weekly_review import weekly_cycle, latest_round, assess_round, learning_history, calibration_summary
from presentation import traffic, summarize, explain, explain_round, team_line
from webcore import pretty
from engine import prediction_matrix
from matchday_live import matchday_result, match_state, render_match_assessment, render_round_assessment
from appearance import theme_css
from model_info import info_sections
from football_context import render_match as render_football_match, render_round as render_football_round, fetch_news

st.set_page_config(page_title='Matchday · KickTipp & SportBet',page_icon='⚽',layout='centered',initial_sidebar_state='collapsed')
st.markdown('''<style>
.block-container{max-width:920px;padding-top:1.3rem;padding-bottom:2rem}
header[data-testid="stHeader"]{background:transparent}
h1{font-size:2.1rem!important;letter-spacing:-.045em}.eyebrow{color:var(--kt-muted);font-size:.7rem;letter-spacing:.16em;font-weight:750}
.stButton>button[kind="primary"]{min-height:3.3rem;border-radius:13px;font-weight:750}
.tip-card{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:16px;padding:16px;margin:12px 0}
.tip-top{color:var(--kt-muted);font-size:.74rem;margin-bottom:10px}.tip-main{display:flex;align-items:center;justify-content:space-between;gap:12px}
.team-line{display:flex;align-items:center;gap:9px;min-height:36px;font-weight:650}.crest{display:flex;align-items:center;justify-content:center;width:28px;height:29px}.crest img{width:27px;height:27px;object-fit:contain}
.tip-score{font-size:2.3rem;font-weight:800;color:var(--kt-fg);white-space:nowrap}.badge{border-radius:22px;padding:5px 9px;font-size:.72rem;font-weight:750;display:inline-block;margin-bottom:12px}
.green{background:#153d29;color:#a2e8b5}.yellow{background:#463b19;color:#ffe49c}.red{background:#42272b;color:#ffb7bc}
.tip-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;border-top:1px solid var(--kt-border);margin-top:14px;padding-top:12px}.tip-stats b{font-size:1.13rem;display:block}.tip-stats span{font-size:.7rem;color:var(--kt-muted)}
.total{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:15px;padding:16px;margin:14px 0}.total b{font-size:1.9rem;color:var(--kt-fg)}.total small{display:block;color:var(--kt-muted)}
.kpi{color:var(--kt-muted);font-size:.85rem}.chart{display:flex;align-items:end;gap:4px;height:140px;margin:10px 0 24px}.bar{flex:1;min-width:0;text-align:center;color:var(--kt-muted);font-size:.65rem}.bar i{display:block;background:var(--kt-fg);border-radius:4px 4px 0 0;margin-bottom:5px}
@media(max-width:540px){.block-container{padding-left:1rem;padding-right:1rem}.team-line{font-size:.91rem}.tip-score{font-size:2rem}}
</style>''',unsafe_allow_html=True)
from sports_portal import STYLE, render_home
from sportbet import render as render_sportbet
from betting_optimizer import render as render_betting
st.markdown(STYLE,unsafe_allow_html=True)
portal=st.radio('Bereich',['Start','KickTipp','SportBet','Betting Optimizer'],horizontal=True,key='portal',label_visibility='collapsed')
if portal!='KickTipp':
    modes=['System','Dunkel','Hell']
    with st.popover('Darstellung'):
        mode=st.selectbox('Darstellung',modes,index=modes.index(st.session_state.get('design','System')),key='appearance_choice')
        st.session_state['design']=mode
    st.markdown(theme_css(st.session_state.get('design','System')),unsafe_allow_html=True)
    if portal=='Start':render_home()
    elif portal=='SportBet':render_sportbet()
    else:render_betting()
    st.stop()
st.markdown('<div class="eyebrow">HÄUSER BULI CUP · 4 / 2 / 1</div>',unsafe_allow_html=True)
page=st.radio('Seite',['Hauptseite','Deep Dive','Info'],horizontal=True,label_visibility='collapsed',key='kicktipp_page')
if page=='Info':
    modes=['System','Dunkel','Hell']
    st.session_state['design']=st.selectbox('Darstellung',modes,index=modes.index(st.session_state.get('design','System')),key='appearance_choice')
st.markdown(theme_css(st.session_state.get('design','System')),unsafe_allow_html=True)

def show_table(data,**kwargs):
    st.markdown('<div class="data-table">'+data.to_html(index=False,escape=True,border=0)+'</div>',unsafe_allow_html=True)

@st.cache_data(ttl=900,show_spinner=False)
def current_football_news():
    return fetch_news(pd.Timestamp.now(tz=BERLIN))

@st.cache_data(ttl=60,show_spinner=False)
def current_schedule(season):
    return fetch_schedule(season)


def review_view(review,compact=False,notes=True):
    if not review:return
    st.subheader(f"Rückblick · Spieltag {review['round']}")
    if review['evaluated']:
        a,b,c=st.columns(3)
        a.metric('Erzielte Modellpunkte',review['points'])
        b.metric('Expected Points',f"{review['expected_points']:.2f}")
        c.metric('Abweichung zu EP',f"{review['delta_points']:+.2f}")
        if notes:st.caption(f"{review['evaluated']} vorab gespeicherte Tipps bewertet · {review['finished']}/{review['games']} Endergebnisse bekannt. Expected Points beziehen sich auf dieselben bewerteten Spiele.")
    else:
        if notes:st.info(f"{review['finished']}/{review['games']} Spiele beendet. Es gibt noch keine auswertbaren, vor Anpfiff gespeicherten Tipps für diesen Spieltag.")
        else:st.info(f"{review['finished']}/{review['games']} beendet · 0 vorab gespeicherte Tipps")
    if not compact:
        rows=[{'Partie':f"{pretty(r['home'])} – {pretty(r['away'])}",'Tipp':r['tip'] or '–','Ergebnis':r['actual'] or '–',
               'Punkte':str(r['points']) if r['points'] is not None else '–',
               'Expected Points':f"{r['ep']:.2f}" if r['ep'] is not None else '–',
               'Abweichung':f"{r['delta_points']:+.2f}" if r.get('delta_points') is not None else '–','Stand':r['status']} for r in review['rows']]
        show_table(pd.DataFrame(rows),hide_index=True,width='stretch')
    if notes:st.caption('Bewertet werden gespeicherte Modelltipps, nicht automatisch deine tatsächlich bei Kicktipp abgegebenen Tipps. Bei mehreren Läufen gilt pro Spiel der letzte gültige Tipp vor Anpfiff.')


@st.fragment(run_every=60)
def render_site(page):
    now=pd.Timestamp.now(tz=BERLIN)
    result=st.session_state.get('v3_result') or saved_result()
    schedule=None;cycle=None;review=None;current_review=None
    try:
        schedule=current_schedule(season_now(now))
        cycle=weekly_cycle(schedule,now)
        if cycle['review_round'] is not None:
            review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now) if cycle['round'] is not None else None
        if cycle['round'] is not None:
            current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    except Exception as exc:
        st.warning(f'Wochenstatus und Ergebnisse konnten gerade nicht online geprüft werden: {exc}')

    if page=='Info':
        st.title('Info')
        for section in info_sections(result):
            with st.expander(section['title']):st.write(section['body'])
        if result:
            audit=result.get('model_audit',{})
            market=result.get('market_audit',{})
            st.subheader('Gewichte dieses Laufs')
            rows=[{'Spiel':pretty(p['home'])+' – '+pretty(p['away']),'Ergebnismodell':f"{1-p.get('market',{}).get('weight',0):.0%}",'Wettmarkt':f"{p.get('market',{}).get('weight',0):.0%}"} for p in result['results']]
            show_table(pd.DataFrame(rows))
            components=result['results'][0].get('components',[]) if result['results'] else []
            if components:show_table(pd.DataFrame([{'Modell':c['spec']['family'],'Anteil im Ergebnismodell':f"{c['weight']:.0%}",'Halbwertszeit (Tage)':c['spec']['half_life'],'Rückblick (Tage)':c['spec']['lookback'],'Ruhezeit-Koeffizient':c['spec']['rest_coef']} for c in components]))
            if market.get('trials'):
                with st.expander('Historischer Quotenvergleich'):
                    show_table(pd.DataFrame(market['trials']))
                    st.write(f"{market['validation_games']} passende Validierungsspiele · {market['test_games']} separate Testspiele. Test: {market['test_market']['points_per_game']:.3f} Punkte/Spiel mit Quoten gegenüber {market['test_model']['points_per_game']:.3f} ohne Quoten. Historisches Verfügbarkeitsszenario; keine verifizierten Dienstagsquoten.")
            if audit:
                with st.expander('Modellprüfung und Grenzen'):
                    st.write(f"Test: {audit['holdout_chosen']['points_per_game']:.3f} Punkte/Spiel · Vergleichsmethode {audit['holdout_baseline']['points_per_game']:.3f}.")
                    ci=audit['holdout_delta_ci'];st.write(f"95-%-Intervall des Punktvorteils: {ci['ci95_low']:+.3f} bis {ci['ci95_high']:+.3f}. Ein Intervall über null allein wäre noch keine Zukunftsgarantie.")
                    show_table(pd.DataFrame(audit['candidates'])[['family','half_life','ridge','points_per_game','score_log_loss','brier_1x2']])
            st.subheader('Warum diese Tipps?')
            for p in result['results']:
                with st.expander(pretty(p['home'])+' – '+pretty(p['away'])+' · '+p['tip']):
                    st.write(explain(p)['summary'])
                    m=p.get('market',{});st.write(f"Ergebnismodell {1-m.get('weight',0):.0%} · Wettmarkt {m.get('weight',0):.0%}. Gewählt wird der höchste erwartete Punktewert, kein sicherer Endstand.")
        if review:
            st.subheader('Einordnung der Abweichungen')
            for r in review['rows']:
                if r.get('explanation'):
                    with st.expander(pretty(r['home'])+' – '+pretty(r['away'])):st.write(r['explanation'])
        calibration=calibration_summary(learning_history(OUTPUT))
        st.subheader('Laufende Wahrscheinlichkeitsprüfung')
        if calibration['games']:
            show_table(pd.DataFrame(calibration['buckets']))
        else:st.caption('Noch keine vorab gespeicherten Tipps mit späteren Endergebnissen auswertbar. Die Wahrscheinlichkeitseinschätzungen werden über viele Spiele geprüft.')
        st.markdown('[Quoten-Dokumentation](https://www.football-data.co.uk/notes.txt) · [Zeitpunkt der Quotenveröffentlichung](https://www.football-data.co.uk/matches.php) · [OpenLigaDB](https://www.openligadb.de/)')
        return

    reviewing=cycle is not None and cycle['phase']=='review'
    if page=='Hauptseite':
        st.title('Dein Spieltag im Blick.' if reviewing else 'Dein nächster Spieltag.')
        if cycle:
            if reviewing:
                switch=pd.Timestamp(cycle['next_tuesday']).strftime('%d.%m. · %H:%M')
                st.info(f"Rückblick · Spieltag {cycle['round']} · Wechsel {switch} Uhr")
            else:
                st.caption(f"Planung · Spieltag {cycle['round']}")
        has_open=schedule is not None and cycle is not None and any(r['round']==cycle['round'] and not r['finished'] and pd.Timestamp(r['kickoff'])>now+pd.Timedelta(minutes=15) for r in schedule)
        label='Spieltag bewerten & aktualisieren' if reviewing and not has_open else 'Tipps erstellen & optimieren →'
        clicked=st.button(label,type='primary',width='stretch')
        needs_cycle_forecast=cycle and not reviewing and (result is None or pd.Timestamp(result['created_at'])<pd.Timestamp(cycle['anchor']))
        auto_key=(season_now(now),cycle['anchor'],cycle['round']) if cycle else None
        retry=st.session_state.get('weekly_auto_attempt')
        auto=needs_cycle_forecast and (not retry or retry[0]!=auto_key or (now-pd.Timestamp(retry[1])).total_seconds()>300)
        if clicked or auto:
            st.session_state.pop('v3_error',None)
            if auto:st.session_state['weekly_auto_attempt']=(auto_key,now.isoformat())
            try:
                if reviewing and not has_open:
                    current_schedule.clear()
                    schedule=current_schedule(season_now(now))
                    review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
                    st.success('Gespeicherte Tipps mit den aktuellen Endergebnissen abgeglichen.')
                else:
                    with st.status('Neuer Dienstagszyklus: Tipps werden berechnet …' if auto and not clicked else 'Optimierung läuft …',expanded=True) as state:
                        message=st.empty()
                        result=optimize(progress=message.write,now=now.to_pydatetime())
                        st.session_state['v3_result']=result
                        current_schedule.clear()
                        state.update(label='Tipps optimiert · neue Ergebnisse im Training berücksichtigt',state='complete',expanded=False)
            except Exception as exc:
                st.session_state['v3_error']=str(exc)
                st.error(str(exc))
        if reviewing:
            review_view(review,notes=False)
        elif review:
            with st.expander(f"Letzter Spieltag · Rückblick {review['round']}"):
                review_view(review,compact=False,notes=False)
    else:
        st.title('Deep Dive')
        if reviewing:review_view(review,notes=False)
        elif review:
            with st.expander(f"Letzter Spieltag · Rückblick {review['round']}"):
                review_view(review,notes=False)
        history=learning_history(OUTPUT)
        if history:
            with st.expander('Bewertete Spieltage'):
                show_table(pd.DataFrame([{'Saison':r['season'],'Spieltag':r['round'],'Tipps':r['evaluated'],'Punkte':r['points'],'Expected Points':round(r['expected_points'],2),'Abweichung':round(r['points']-r['expected_points'],2)} for r in history]))
    # Rebuild the display after every run: later partial runs must not hide earlier tips.
    if schedule is not None and cycle and cycle['round'] is not None:
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now)
        current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    if page=='Deep Dive':
        render_round_assessment(st,current_review if reviewing else review)
        reviewed_round=current_review if reviewing else review
        if reviewed_round:
            for row in reviewed_round['rows']:
                if row.get('points') is not None:
                    game=next((g for g in schedule if (g['home'],g['away'])==(row['home'],row['away'])),None)
                    with st.expander(pretty(row['home'])+' – '+pretty(row['away'])+' · '+row['actual']):
                        render_match_assessment(st,row,game)
    if not result:
        if page=='Deep Dive':st.info('Für diesen Spieltag liegt noch kein Prognoselauf vor. Neue Tipps werden im Planungsmodus erstellt; ein Rückblick erzeugt keine Tipps im Nachhinein.')
        return
    created=pd.Timestamp(result['created_at']).tz_convert(BERLIN)
    open_predictions=result['results']
    review_rows={(r['home'],r['away']):r for r in (current_review or {}).get('rows',[])}
    if not reviewing and ((now-created).total_seconds()>3600 or st.session_state.get('v3_error')):
        st.warning('Gespeicherter Stand: Auf der Hauptseite erneut optimieren, um Ergebnisse und Termine zu aktualisieren.')
    if not open_predictions:
        return
    stats=point_statistics(open_predictions)
    summary=summarize(stats['pmf'])
    if page=='Hauptseite':
        st.caption(f"Spieltag {result['round']} · {len(open_predictions)} Spiele · Stand {created.strftime('%d.%m. %H:%M')}")
        st.markdown(f'<div class="total"><small>Expected Points gesamt</small><b>{stats["expected_points"]:.2f}</b></div>',unsafe_allow_html=True)
        checked=next((r.get('feed_checked_at') for r in (schedule or []) if r.get('feed_checked_at')),None)
        if checked:st.caption('Spielstände: OpenLigaDB · abgerufen '+pd.Timestamp(checked).tz_convert(BERLIN).strftime('%d.%m. %H:%M')+' Uhr · Aktualisierung etwa jede Minute bei geöffneter Seite; Meldungen können verzögert sein.')
        for p in open_predictions:
            state=match_state(p,schedule,now)
            row=review_rows.get((p['home'],p['away']))
            points=f" · {row['points']} Punkte" if row and row.get('points') is not None else ''
            scoreline=html.escape(state['label']+' · '+state['score']+points)
            color,emoji,label,_=traffic(p['prob_tendency'])
            dt=pd.Timestamp(p['kickoff']).tz_convert(BERLIN)
            teams=team_line(p['home'],p.get('home_logo',''))+team_line(p['away'],p.get('away_logo',''))
            st.markdown(f'''<div class="tip-card"><div class="tip-top">{dt.strftime('%d.%m. · %H:%M')} Uhr</div>
    <div class="kpi">{scoreline}</div>
    <div class="badge {color}">{emoji} {label} · {p['prob_tendency']:.0%} Tendenzchance</div>
    <div class="tip-main"><div>{teams}</div><div class="tip-score"><small style="display:block;font-size:.7rem;font-weight:500">Tipp</small>{p['tip']}</div></div>
    <div class="tip-stats"><div><b>{p['ep']:.2f}</b><span>Expected Points</span></div><div><b>{p['prob_exact']:.1%}</b><span>Modellwahrscheinlichkeit · exakt</span></div></div></div>''',unsafe_allow_html=True)
    else:
        st.subheader('Gesamter Spieltag')
        render_football_round(st,result,now)
        with st.expander('Statistische Einordnung'):
            st.write(explain_round(open_predictions,stats))
        a,b,c=st.columns(3)
        a.metric('Expected Points',f"{stats['expected_points']:.2f}")
        b.metric('Median Punkte',summary['median'])
        c.metric('Chance ≥ 10 Punkte',f"{summary['at_least_ten']:.1%}")
        show_table(pd.DataFrame([{'Bereich':'Zentral','Punkte von':summary['central_low'],'Punkte bis':summary['central_high'],'Modellwahrscheinlichkeit':f"{summary['central_mass']:.1%}"},{'Bereich':'Zentral 80 %','Punkte von':stats['points_low'],'Punkte bis':stats['points_high'],'Modellwahrscheinlichkeit':'≥ 80 %'}]))
        pmf=stats['pmf'];maximum=max(pmf)
        bars=''.join(f'<div class="bar" title="{i} Punkte: {v:.1%}"><i style="height:{max(1,110*v/maximum):.1f}px"></i>{i}</div>' for i,v in enumerate(pmf) if v>.001)
        st.markdown('<div class="chart">'+bars+'</div>',unsafe_allow_html=True)
        show_table(pd.DataFrame([{'Spiel':pretty(p['home'])+' – '+pretty(p['away']),'Tipp':p['tip'],'Expected Points':round(p['ep'],3),'Exakt':f"{p['prob_exact']:.1%}",'Tendenz':f"{p['prob_tendency']:.1%}"} for p in open_predictions]))
        selected=st.selectbox('Begegnung',range(len(open_predictions)),format_func=lambda i:pretty(open_predictions[i]['home'])+' – '+pretty(open_predictions[i]['away']))
        p=open_predictions[selected];details=explain(p);matrix=prediction_matrix(p)
        st.subheader(f"Einzelspiel · {p['tip']}")
        state=match_state(p,schedule,now)
        st.info(state['label']+' · '+state['score'])
        if state['finished']:
            render_match_assessment(st,review_rows.get((p['home'],p['away'])),state['game'])
        else:
            render_football_match(st,p,result['season'],result['round'],schedule,now,current_football_news())
        with st.expander('Punkteentscheidung des Modells'):
            st.write(details['qualitative'])
        show_table(pd.DataFrame([{'Expected Points':round(p['ep'],3),'Exakte Modellchance':f"{p['prob_exact']:.2%}",'Tendenzchance':f"{p['prob_tendency']:.2%}",'Heimtore λ':round(p['lambda_home'],3),'Auswärtstore λ':round(p['lambda_away'],3)}]))
        st.subheader('Alternative Tipps')
        show_table(pd.DataFrame([{'Tipp':a['tip'],'Expected Points':round(a['ep'],3),'Exakte Modellchance':f"{matrix[tuple(map(int,a['tip'].split(':')))]:.2%}"} for a in p['alternatives']]))
        st.subheader('Wahrscheinlichste Spielstände')
        scores=sorted(((float(matrix[h,a]),f'{h}:{a}') for h in range(len(matrix)) for a in range(len(matrix))),reverse=True)[:8]
        show_table(pd.DataFrame([{'Ergebnis':t,'Modellwahrscheinlichkeit':f'{v:.2%}'} for v,t in scores]))
        st.subheader('Punktechancen')
        show_table(pd.DataFrame([{'Punkte':k,'Modellwahrscheinlichkeit':f"{details['points'][k]:.2%}",'Beitrag zu Expected Points':round(k*details['points'][k],3)} for k in (4,2,1,0)]))
        st.subheader('1 / X / 2')
        show_table(pd.DataFrame([{'Heimsieg':f"{p['prob_home']:.2%}",'Remis':f"{p['prob_draw']:.2%}",'Auswärtssieg':f"{p['prob_away']:.2%}"}]))

render_site(page)
