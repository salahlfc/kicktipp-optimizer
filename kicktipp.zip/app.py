"""KickTipp: focused predictions, matchday review and model information."""
import html
import pandas as pd
import streamlit as st
from leanflow import BERLIN, OUTPUT, optimize, saved_result, point_statistics, fetch_schedule, season_now
from weekly_review import weekly_cycle, latest_round, assess_round, learning_history, calibration_summary
from presentation import traffic, summarize, explain, explain_round, team_line
from webcore import pretty
from engine import prediction_matrix
from matchday_live import matchday_result, match_state, render_match_assessment, render_round_assessment
from appearance import theme_css
from model_info import info_sections
from football_context import render_match as render_football_match, render_round as render_football_round, fetch_news

st.set_page_config(page_title='KickTipp · Häuser Buli Cup',page_icon='⚽',layout='centered',initial_sidebar_state='collapsed')
st.markdown('''<style>
.block-container{max-width:980px;padding-top:1rem;padding-bottom:3rem}
header[data-testid="stHeader"]{background:transparent}
h1{font-size:2.1rem!important;letter-spacing:-.045em}.eyebrow{color:var(--kt-muted);font-size:.7rem;letter-spacing:.16em;font-weight:750}
.stButton>button[kind="primary"]{min-height:3.3rem;border-radius:13px;font-weight:750}
.tip-card{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:16px;padding:16px;margin:12px 0}
.tip-top{color:var(--kt-muted);font-size:.74rem;margin-bottom:10px}.tip-main{display:flex;align-items:center;justify-content:space-between;gap:12px}
.team-line{display:flex;align-items:center;gap:9px;min-height:36px;font-weight:650}.crest{display:flex;align-items:center;justify-content:center;width:28px;height:29px}.crest img{width:27px;height:27px;object-fit:contain}
.tip-score{font-size:2.3rem;font-weight:800;color:var(--kt-fg);white-space:nowrap}.badge{border-radius:22px;padding:5px 9px;font-size:.72rem;font-weight:750;display:inline-block;margin-bottom:12px}
.green{background:#153d29;color:#a2e8b5}.yellow{background:#463b19;color:#ffe49c}.red{background:#42272b;color:#ffb7bc}
.tip-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;border-top:1px solid var(--kt-border);margin-top:14px;padding-top:12px}.tip-stats b{font-size:1.13rem;display:block}.tip-stats span{font-size:.7rem;color:var(--kt-muted)}
.total{background:var(--kt-card);border:1px solid var(--kt-border);border-radius:15px;padding:16px;margin:14px 0}.total b{font-size:1.9rem;color:var(--kt-fg)}.total small{display:block;color:var(--kt-muted)}
.lineups-grid,.availability-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:10px 0}.lineup-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:14px;padding:12px;min-width:0}.lineup-heading{display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:9px}.lineup-heading img{width:25px;height:25px;object-fit:contain}.lineup-pitch{border:1px solid var(--kt-border);border-radius:10px;padding:9px 4px;background:linear-gradient(90deg,transparent 49.8%,var(--kt-border) 50%,transparent 50.2%)}.lineup-row{display:flex;justify-content:center;align-items:flex-start;gap:3px;margin:8px 0}.lineup-player{width:20%;max-width:76px;min-width:0;text-align:center;font-size:.61rem;line-height:1.12;overflow-wrap:anywhere}.lineup-player img,.lineup-avatar{display:block;width:35px;height:35px;border-radius:50%;object-fit:cover;border:1px solid var(--kt-border);margin:0 auto 4px}.lineup-avatar{display:grid;place-items:center;background:var(--kt-bg);font-size:.7rem;font-weight:750}.lineup-role{font-size:.57rem;color:var(--kt-muted);text-align:center;letter-spacing:.1em;text-transform:uppercase}.lineup-empty{border:1px dashed var(--kt-border);border-radius:12px;padding:12px;color:var(--kt-muted);font-size:.86rem}.lineup-state{display:flex;align-items:center;gap:10px;border:1px solid var(--kt-border);border-radius:12px;background:var(--kt-bg);padding:12px;margin:8px 0}.lineup-state img{width:38px;height:38px;object-fit:contain}.lineup-state b{display:block}.lineup-state small{color:var(--kt-muted)}.empty-pitch{height:74px;border:1px solid var(--kt-border);border-radius:9px;margin-top:9px;position:relative;background:linear-gradient(90deg,transparent 49.6%,var(--kt-border) 50%,transparent 50.4%),linear-gradient(0deg,transparent 49.4%,var(--kt-border) 50%,transparent 50.6%)}.empty-pitch:before{content:'';position:absolute;inset:6px auto 6px 50%;width:24px;border:1px solid var(--kt-border);border-radius:50%;transform:translateX(-50%)}.availability-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:14px;padding:12px;min-width:0}.availability-title{display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:9px}.availability-title img{width:24px;height:24px;object-fit:contain}.absence-item{display:flex;align-items:center;gap:9px;padding:8px 0;border-top:1px solid var(--kt-border)}.absence-item img,.absence-avatar{width:34px;height:34px;border-radius:50%;object-fit:cover;flex:none;border:1px solid var(--kt-border)}.absence-avatar{display:grid;place-items:center;background:var(--kt-bg);font-size:.72rem;font-weight:750}.absence-copy{min-width:0}.absence-copy b{display:block;font-size:.85rem}.absence-copy small{display:block;color:var(--kt-muted);font-size:.72rem}.availability-empty{font-size:.82rem;color:var(--kt-muted);padding:7px 0}.team-update{border:1px solid var(--kt-border);border-radius:14px;background:var(--kt-card);padding:12px 14px;margin:10px 0;color:var(--kt-muted);font-size:.82rem}.team-status{display:flex;align-items:center;gap:12px;border:1px solid var(--kt-border);border-radius:15px;background:var(--kt-card);padding:12px 14px;margin:12px 0;box-shadow:var(--kt-shadow)}.team-status-icon{display:grid;place-items:center;width:31px;height:31px;flex:none;border:1px solid var(--kt-border);border-radius:11px;background:var(--kt-soft);font-weight:800}.team-status-copy{min-width:0}.team-status-copy b{display:block;font-size:.8rem}.team-status-copy small{display:block;color:var(--kt-muted);font-size:.73rem;line-height:1.4;margin-top:2px}.team-status.partial .team-status-icon{border-style:dashed}
.lineup-list{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.lineup-list .lineup-player{width:auto;max-width:none;border:1px solid var(--kt-border);border-radius:9px;background:var(--kt-bg);padding:7px 3px;font-size:.67rem}
.kpi{color:var(--kt-muted);font-size:.85rem}.chart{display:flex;align-items:end;gap:4px;height:140px;margin:10px 0 24px}.bar{flex:1;min-width:0;text-align:center;color:var(--kt-muted);font-size:.65rem}.bar i{display:block;background:var(--kt-fg);border-radius:4px 4px 0 0;margin-bottom:5px}
@media(max-width:640px){.block-container{padding-left:1rem;padding-right:1rem}.team-line{font-size:.91rem}.tip-score{font-size:2rem}.lineups-grid,.availability-grid{grid-template-columns:1fr}.lineup-player{width:19%;font-size:.58rem}.lineup-player img,.lineup-avatar{width:32px;height:32px}}
</style>''',unsafe_allow_html=True)
# Remove obsolete page state when an already-open session receives this update.
for obsolete in list(st.session_state):
    if obsolete=='portal' or obsolete.startswith(('watch_','sportbet_','betting_','open_watch','open_sportbet','open_betting','paper_','local_savings_')):
        del st.session_state[obsolete]
st.markdown('<div class="app-brand"><div class="app-brand-mark">⚽</div><div><b>KICKTIPP OPTIMIZER</b><small>Häuser Buli Cup · 4 / 2 / 1</small></div></div>',unsafe_allow_html=True)
if st.session_state.get('kicktipp_page') not in (None,'Hauptseite','Deep Dive','Info'):
    st.session_state['kicktipp_page']='Hauptseite'
page=st.radio('Seite',['Hauptseite','Deep Dive','Info'],horizontal=True,label_visibility='collapsed',key='kicktipp_page')
if page=='Info':
    modes=['System','Dunkel','Hell']
    st.session_state['design']=st.selectbox('Darstellung',modes,index=modes.index(st.session_state.get('design','System')),key='appearance_choice')
st.markdown(theme_css(st.session_state.get('design','System')),unsafe_allow_html=True)

def show_table(data,**kwargs):
    st.markdown('<div class="data-table">'+data.to_html(index=False,escape=True,border=0)+'</div>',unsafe_allow_html=True)


def lineup_markup(team,formation,logo,players):
    logo=str(logo or '')
    logo=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    groups={'Angriff':[],'Mittelfeld':[],'Abwehr':[],'Tor':[],'Spieler':[]}
    for player in players:
        pos=str(player.get('position','')).casefold()
        role='Tor' if 'goalkeeper' in pos or 'keeper' in pos or 'torwart' in pos else 'Abwehr' if 'defend' in pos or 'verteidig' in pos else 'Mittelfeld' if 'midfield' in pos or 'mittelfeld' in pos else 'Angriff' if 'forward' in pos or 'attacker' in pos or 'stürm' in pos else 'Spieler'
        groups[role].append(player)
    rows=[(k,v) for k,v in groups.items() if v]
    generic_only=len(rows)==1 and rows[0][0]=='Spieler'
    if len(rows)==1 and rows[0][0]=='Spieler':
        rows=[('Startelf',rows[0][1])]
    parts=[]
    for role,items in rows:
        cards=[]
        for player in items:
            name=str(player.get('name','Spieler'))[:80]
            image=str(player.get('image',''))
            if image.startswith('https://live-football-api.com/people/'):
                avatar=f'<img loading="lazy" src="{html.escape(image,quote=True)}" alt="">'
            else:
                initials=html.escape(''.join(w[:1] for w in name.split()[:2]).upper())
                avatar=f'<span class="lineup-avatar">{initials}</span>'
            cards.append(f'<div class="lineup-player">{avatar}{html.escape(name)}</div>')
        parts.append('<div class="lineup-role">'+html.escape(role)+'</div><div class="'+('lineup-list' if generic_only else 'lineup-row')+'">'+''.join(cards)+'</div>')
    return f'<div class="lineup-card"><div class="lineup-heading">{logo}<span>{html.escape(pretty(team))}</span><small style="margin-left:auto;color:var(--kt-muted)">{html.escape(str(formation or ""))}</small></div><div class="lineup-pitch">'+''.join(parts)+'</div></div>'


def lineup_pending_markup(team,logo):
    logo=str(logo or '')
    crest=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    return f'<div class="lineup-card"><div class="lineup-state">{crest}<div><b>{html.escape(pretty(team))}</b><small>Voraussichtliche Aufstellung</small></div></div><div class="empty-pitch" aria-hidden="true"></div><small style="display:block;color:var(--kt-muted);margin-top:8px">Noch nicht von der Datenquelle veröffentlicht.</small></div>'


def absence_markup(team,logo,players,check_complete):
    logo=str(logo or '')
    crest=f'<img src="{html.escape(logo,quote=True)}" alt="">' if logo.startswith('https://') else ''
    items=[]
    for player in players:
        name=str(player.get('name','Spieler'))[:80]
        image=str(player.get('image',''))
        if image.startswith('https://live-football-api.com/people/'):
            avatar=f'<img src="{html.escape(image,quote=True)}" alt="">'
        else:
            initials=html.escape(''.join(w[:1] for w in name.split()[:2]).upper())
            avatar=f'<span class="absence-avatar">{initials}</span>'
        details=' · '.join(x for x in (str(player.get('position','')).strip(),str(player.get('status','')).strip()) if x)
        items.append(f'<div class="absence-item">{avatar}<div class="absence-copy"><b>{html.escape(name)}</b><small>{html.escape(details or "Ausfallmeldung")}</small></div></div>')
    if not items:
        message='Keine bestätigten Ausfälle gemeldet.' if check_complete else 'In diesem Lauf nicht verlässlich geprüft.'
        items=[f'<div class="availability-empty">{message}</div>']
    return f'<div class="availability-card"><div class="availability-title">{crest}<span>{html.escape(pretty(team))}</span></div>'+''.join(items)+'</div>'

@st.cache_data(ttl=900,show_spinner=False)
def current_football_news():
    return fetch_news(pd.Timestamp.now(tz=BERLIN))

@st.cache_data(ttl=60,show_spinner=False)
def current_schedule(season):
    return fetch_schedule(season)


def review_view(review,compact=False,notes=True):
    if not review:return
    st.subheader(f"Rückblick · Spieltag {review['round']}")
    if review['evaluated']:
        a,b,c=st.columns(3)
        a.metric('Erzielte Modellpunkte',review['points'])
        b.metric('Expected Points',f"{review['expected_points']:.2f}")
        c.metric('Abweichung zu EP',f"{review['delta_points']:+.2f}")
        if notes:st.caption(f"{review['evaluated']} vorab gespeicherte Tipps bewertet · {review['finished']}/{review['games']} Endergebnisse bekannt. Expected Points beziehen sich auf dieselben bewerteten Spiele.")
    else:
        if notes:st.info(f"{review['finished']}/{review['games']} Spiele beendet. Es gibt noch keine auswertbaren, vor Anpfiff gespeicherten Tipps für diesen Spieltag.")
        else:st.info(f"{review['finished']}/{review['games']} beendet · 0 vorab gespeicherte Tipps")
    if not compact:
        rows=[{'Partie':f"{pretty(r['home'])} – {pretty(r['away'])}",'Tipp':r['tip'] or '–','Ergebnis':r['actual'] or '–',
               'Punkte':str(r['points']) if r['points'] is not None else '–',
               'Expected Points':f"{r['ep']:.2f}" if r['ep'] is not None else '–',
               'Abweichung':f"{r['delta_points']:+.2f}" if r.get('delta_points') is not None else '–','Stand':r['status']} for r in review['rows']]
        show_table(pd.DataFrame(rows),hide_index=True,width='stretch')
    if notes:st.caption('Bewertet werden gespeicherte Modelltipps, nicht automatisch deine tatsächlich bei Kicktipp abgegebenen Tipps. Bei mehreren Läufen gilt pro Spiel der letzte gültige Tipp vor Anpfiff.')


@st.fragment(run_every=60)
def render_site(page):
    now=pd.Timestamp.now(tz=BERLIN)
    result=st.session_state.get('v3_result') or saved_result()
    schedule=None;cycle=None;review=None;current_review=None
    try:
        schedule=current_schedule(season_now(now))
        cycle=weekly_cycle(schedule,now)
        if cycle['review_round'] is not None:
            review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now) if cycle['round'] is not None else None
        if cycle['round'] is not None:
            current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    except Exception as exc:
        st.warning(f'Wochenstatus und Ergebnisse konnten gerade nicht online geprüft werden: {exc}')

    if page=='Info':
        st.title('Info')
        st.markdown('<div class="page-intro"><div class="page-intro-copy">Das Modell, seine Daten und seine Grenzen – klar erklärt und an einem Ort.</div><div class="page-intro-chip">MODELLE · DATEN · METHODIK</div></div>',unsafe_allow_html=True)
        for section in info_sections(result):
            with st.expander(section['title']):st.write(section['body'])
        if result:
            audit=result.get('model_audit',{})
            market=result.get('market_audit',{})
            st.subheader('Gewichte dieses Laufs')
            rows=[{'Spiel':pretty(p['home'])+' – '+pretty(p['away']),'Ergebnismodell':f"{1-p.get('market',{}).get('weight',0):.0%}",'Wettmarkt':f"{p.get('market',{}).get('weight',0):.0%}"} for p in result['results']]
            show_table(pd.DataFrame(rows))
            components=result['results'][0].get('components',[]) if result['results'] else []
            if components:show_table(pd.DataFrame([{'Modell':c['spec']['family'],'Anteil im Ergebnismodell':f"{c['weight']:.0%}",'Halbwertszeit (Tage)':c['spec']['half_life'],'Rückblick (Tage)':c['spec']['lookback'],'Ruhezeit-Koeffizient':c['spec']['rest_coef']} for c in components]))
            if market.get('trials'):
                with st.expander('Historischer Quotenvergleich'):
                    show_table(pd.DataFrame(market['trials']))
                    st.write(f"{market['validation_games']} passende Validierungsspiele · {market['test_games']} separate Testspiele. Test: {market['test_market']['points_per_game']:.3f} Punkte/Spiel mit Quoten gegenüber {market['test_model']['points_per_game']:.3f} ohne Quoten. Historisches Verfügbarkeitsszenario; keine verifizierten Dienstagsquoten.")
            if audit:
                with st.expander('Modellprüfung und Grenzen'):
                    st.write(f"Test: {audit['holdout_chosen']['points_per_game']:.3f} Punkte/Spiel · Vergleichsmethode {audit['holdout_baseline']['points_per_game']:.3f}.")
                    ci=audit['holdout_delta_ci'];st.write(f"95-%-Intervall des Punktvorteils: {ci['ci95_low']:+.3f} bis {ci['ci95_high']:+.3f}. Ein Intervall über null allein wäre noch keine Zukunftsgarantie.")
                    show_table(pd.DataFrame(audit['candidates'])[['family','half_life','ridge','points_per_game','score_log_loss','brier_1x2']])
            st.subheader('Warum diese Tipps?')
            for p in result['results']:
                with st.expander(pretty(p['home'])+' – '+pretty(p['away'])+' · '+p['tip']):
                    st.write(explain(p)['summary'])
                    m=p.get('market',{});st.write(f"Ergebnismodell {1-m.get('weight',0):.0%} · Wettmarkt {m.get('weight',0):.0%}. Gewählt wird der höchste erwartete Punktewert, kein sicherer Endstand.")
        if review:
            st.subheader('Einordnung der Abweichungen')
            for r in review['rows']:
                if r.get('explanation'):
                    with st.expander(pretty(r['home'])+' – '+pretty(r['away'])):st.write(r['explanation'])
        calibration=calibration_summary(learning_history(OUTPUT))
        st.subheader('Laufende Wahrscheinlichkeitsprüfung')
        if calibration['games']:
            show_table(pd.DataFrame(calibration['buckets']))
        else:st.caption('Noch keine vorab gespeicherten Tipps mit späteren Endergebnissen auswertbar. Die Wahrscheinlichkeitseinschätzungen werden über viele Spiele geprüft.')
        st.markdown('[Quoten-Dokumentation](https://www.football-data.co.uk/notes.txt) · [Zeitpunkt der Quotenveröffentlichung](https://www.football-data.co.uk/matches.php) · [OpenLigaDB](https://www.openligadb.de/)')
        return

    reviewing=cycle is not None and cycle['phase']=='review'
    if page=='Hauptseite':
        st.title('Dein Spieltag im Blick.' if reviewing else 'Dein nächster Spieltag.')
        round_chip=f"SPIELTAG {cycle['round']}" if cycle and cycle.get('round') is not None else 'BUNDESLIGA'
        st.markdown(f'<div class="page-intro"><div class="page-intro-copy">Deine Tipps, Chancen und Live-Stände kompakt an einem Ort.</div><div class="page-intro-chip">{round_chip}</div></div>',unsafe_allow_html=True)
        if cycle:
            if reviewing:
                switch=pd.Timestamp(cycle['next_tuesday']).strftime('%d.%m. · %H:%M')
                st.info(f"Rückblick · Spieltag {cycle['round']} · Wechsel {switch} Uhr")
            else:
                st.caption(f"Planung · Spieltag {cycle['round']}")
        has_open=schedule is not None and cycle is not None and any(r['round']==cycle['round'] and not r['finished'] and pd.Timestamp(r['kickoff'])>now+pd.Timedelta(minutes=15) for r in schedule)
        label='Spieltag bewerten & aktualisieren' if reviewing and not has_open else 'Tipps erstellen & optimieren →'
        clicked=st.button(label,type='primary',width='stretch')
        needs_cycle_forecast=cycle and not reviewing and (result is None or pd.Timestamp(result['created_at'])<pd.Timestamp(cycle['anchor']))
        auto_key=(season_now(now),cycle['anchor'],cycle['round']) if cycle else None
        retry=st.session_state.get('weekly_auto_attempt')
        auto=needs_cycle_forecast and (not retry or retry[0]!=auto_key or (now-pd.Timestamp(retry[1])).total_seconds()>300)
        if clicked or auto:
            st.session_state.pop('v3_error',None)
            if auto:st.session_state['weekly_auto_attempt']=(auto_key,now.isoformat())
            try:
                if reviewing and not has_open:
                    current_schedule.clear()
                    schedule=current_schedule(season_now(now))
                    review=assess_round(schedule,OUTPUT,season_now(now),cycle['review_round'],now)
                    st.success('Gespeicherte Tipps mit den aktuellen Endergebnissen abgeglichen.')
                else:
                    with st.status('Neuer Dienstagszyklus: Tipps werden berechnet …' if auto and not clicked else 'Optimierung läuft …',expanded=True) as state:
                        message=st.empty()
                        result=optimize(progress=message.write,now=now.to_pydatetime())
                        st.session_state['v3_result']=result
                        current_schedule.clear()
                        state.update(label='Tipps optimiert · neue Ergebnisse im Training berücksichtigt',state='complete',expanded=False)
            except Exception as exc:
                st.session_state['v3_error']=str(exc)
                st.error(str(exc))
        if reviewing:
            review_view(review,notes=False)
        elif review:
            with st.expander(f"Letzter Spieltag · Rückblick {review['round']}"):
                review_view(review,compact=False,notes=False)
    else:
        st.title('Deep Dive')
        st.markdown('<div class="page-intro"><div class="page-intro-copy">Ergebnis für Ergebnis: Prognose, Teamnews, Chancen und Spieltagsbilanz.</div><div class="page-intro-chip">DETAILS & RÜCKBLICK</div></div>',unsafe_allow_html=True)
        if reviewing:review_view(review,notes=False)
        elif review:
            with st.expander(f"Letzter Spieltag · Rückblick {review['round']}"):
                review_view(review,notes=False)
        history=learning_history(OUTPUT)
        if history:
            with st.expander('Bewertete Spieltage'):
                show_table(pd.DataFrame([{'Saison':r['season'],'Spieltag':r['round'],'Tipps':r['evaluated'],'Punkte':r['points'],'Expected Points':round(r['expected_points'],2),'Abweichung':round(r['points']-r['expected_points'],2)} for r in history]))
    # Rebuild the display after every run: later partial runs must not hide earlier tips.
    if schedule is not None and cycle and cycle['round'] is not None:
        result=matchday_result(OUTPUT,season_now(now),cycle['round'],schedule,now)
        current_review=assess_round(schedule,OUTPUT,season_now(now),cycle['round'],now,persist=False)
    if page=='Deep Dive':
        render_round_assessment(st,current_review if reviewing else review)
        reviewed_round=current_review if reviewing else review
        if reviewed_round:
            for row in reviewed_round['rows']:
                if row.get('points') is not None:
                    game=next((g for g in schedule if (g['home'],g['away'])==(row['home'],row['away'])),None)
                    with st.expander(pretty(row['home'])+' – '+pretty(row['away'])+' · '+row['actual']):
                        render_match_assessment(st,row,game)
    if not result:
        if page=='Deep Dive':st.info('Für diesen Spieltag liegt noch kein Prognoselauf vor. Neue Tipps werden im Planungsmodus erstellt; ein Rückblick erzeugt keine Tipps im Nachhinein.')
        return
    created=pd.Timestamp(result['created_at']).tz_convert(BERLIN)
    open_predictions=result['results']
    review_rows={(r['home'],r['away']):r for r in (current_review or {}).get('rows',[])}
    if not reviewing and ((now-created).total_seconds()>3600 or st.session_state.get('v3_error')):
        st.warning('Gespeicherter Stand: Auf der Hauptseite erneut optimieren, um Ergebnisse und Termine zu aktualisieren.')
    if not open_predictions:
        return
    stats=point_statistics(open_predictions)
    summary=summarize(stats['pmf'])
    if page=='Hauptseite':
        st.caption(f"Spieltag {result['round']} · {len(open_predictions)} Spiele · Stand {created.strftime('%d.%m. %H:%M')}")
        st.markdown(f'<div class="total"><small>Expected Points gesamt</small><b>{stats["expected_points"]:.2f}</b></div>',unsafe_allow_html=True)
        checked=next((r.get('feed_checked_at') for r in (schedule or []) if r.get('feed_checked_at')),None)
        if checked:st.caption('Spielstände: OpenLigaDB · abgerufen '+pd.Timestamp(checked).tz_convert(BERLIN).strftime('%d.%m. %H:%M')+' Uhr · Aktualisierung etwa jede Minute bei geöffneter Seite; Meldungen können verzögert sein.')
        context=result.get('team_context_status',{})
        if context:
            credits=context.get('credits_remaining')
            credit_note=f' · {credits} Gratis-Credits übrig' if credits is not None else ''
            reason=html.escape(context.get('reason','Status unbekannt'))
            credit=html.escape(credit_note)
            partial=any(x in reason.casefold() for x in ('zeitüberschreitung','nicht erreichbar','nicht zugeordnet','fehler'))
            official_fallback='bundesliga.com' in reason.casefold() and int(context.get('official_matches',0) or 0)>0
            state_class='ready' if official_fallback else 'partial' if partial else 'ready'
            state_label='Offizieller Bundesliga-Vorbericht aktiv' if official_fallback else 'Teamnews teilweise offen' if partial else 'Teamnews-Status'
            state_icon='✓' if official_fallback or not partial else '!'
            st.markdown(f'<div class="team-status {state_class}"><div class="team-status-icon">{state_icon}</div><div class="team-status-copy"><b>{state_label}</b><small>{reason}{credit}</small></div></div>',unsafe_allow_html=True)
        for p in open_predictions:
            state=match_state(p,schedule,now)
            row=review_rows.get((p['home'],p['away']))
            points=f" · {row['points']} Punkte" if row and row.get('points') is not None else ''
            scoreline=html.escape(state['label']+' · '+state['score']+points)
            color,emoji,label,_=traffic(p['prob_tendency'])
            dt=pd.Timestamp(p['kickoff']).tz_convert(BERLIN)
            teams=team_line(p['home'],p.get('home_logo',''))+team_line(p['away'],p.get('away_logo',''))
            st.markdown(f'''<div class="tip-card"><div class="tip-top">{dt.strftime('%d.%m. · %H:%M')} Uhr</div>
    <div class="kpi">{scoreline}</div>
    <div class="badge {color}">{emoji} {label} · {p['prob_tendency']:.0%} Tendenzchance</div>
    <div class="tip-main"><div>{teams}</div><div class="tip-score"><small style="display:block;font-size:.7rem;font-weight:500">Tipp</small>{p['tip']}</div></div>
    <div class="tip-stats"><div><b>{p['ep']:.2f}</b><span>Expected Points</span></div><div><b>{p['prob_exact']:.1%}</b><span>Modellwahrscheinlichkeit · exakt</span></div></div></div>''',unsafe_allow_html=True)
    else:
        st.subheader('Gesamter Spieltag')
        render_football_round(st,result,now)
        with st.expander('Statistische Einordnung'):
            st.write(explain_round(open_predictions,stats))
        a,b,c=st.columns(3)
        a.metric('Expected Points',f"{stats['expected_points']:.2f}")
        b.metric('Median Punkte',summary['median'])
        c.metric('Chance ≥ 10 Punkte',f"{summary['at_least_ten']:.1%}")
        show_table(pd.DataFrame([{'Bereich':'Zentral','Punkte von':summary['central_low'],'Punkte bis':summary['central_high'],'Modellwahrscheinlichkeit':f"{summary['central_mass']:.1%}"},{'Bereich':'Zentral 80 %','Punkte von':stats['points_low'],'Punkte bis':stats['points_high'],'Modellwahrscheinlichkeit':'≥ 80 %'}]))
        pmf=stats['pmf'];maximum=max(pmf)
        bars=''.join(f'<div class="bar" title="{i} Punkte: {v:.1%}"><i style="height:{max(1,110*v/maximum):.1f}px"></i>{i}</div>' for i,v in enumerate(pmf) if v>.001)
        st.markdown('<div class="chart">'+bars+'</div>',unsafe_allow_html=True)
        show_table(pd.DataFrame([{'Spiel':pretty(p['home'])+' – '+pretty(p['away']),'Tipp':p['tip'],'Expected Points':round(p['ep'],3),'Exakt':f"{p['prob_exact']:.1%}",'Tendenz':f"{p['prob_tendency']:.1%}"} for p in open_predictions]))
        selected=st.selectbox('Begegnung',range(len(open_predictions)),format_func=lambda i:pretty(open_predictions[i]['home'])+' – '+pretty(open_predictions[i]['away']))
        p=open_predictions[selected];details=explain(p);matrix=prediction_matrix(p)
        st.subheader(f"Einzelspiel · {p['tip']}")
        state=match_state(p,schedule,now)
        st.info(state['label']+' · '+state['score'])
        if state['finished']:
            render_match_assessment(st,review_rows.get((p['home'],p['away'])),state['game'])
        else:
            render_football_match(st,p,result['season'],result['round'],schedule,now,current_football_news())
        with st.expander('Punkteentscheidung des Modells'):
            st.write(details['qualitative'])
        team_context=p.get('team_context') or {}
        with st.expander('Teamnews & Aufstellungen',expanded=True):
            lineup_data=team_context.get('lineups') or {}
            home_data=lineup_data.get('home') or {};away_data=lineup_data.get('away') or {}
            home_line=home_data.get('starting',[]);away_line=away_data.get('starting',[])
            logos=team_context.get('team_logos') or {}
            optimization_label=created.strftime('%d.%m.%Y · %H:%M')+' Uhr'
            checked_raw=team_context.get('injuries_checked_at') or team_context.get('checked_at')
            if checked_raw:
                checked=pd.Timestamp(checked_raw)
                if checked.tzinfo is None:checked=checked.tz_localize('UTC')
                checked=checked.tz_convert(BERLIN)
                data_age=(now-checked).total_seconds()
                data_label='Teamdaten aktuell' if 0<=data_age<=86400 else 'Teamdaten älter als 24 Stunden'
                checked_label=checked.strftime('%d.%m. · %H:%M')+' Uhr'
            else:
                data_label='Kein Personalcheck im letzten Lauf'
                checked_label='–'
            st.markdown(f'<div class="team-update"><b>Letzte Optimierung: {optimization_label}</b><br>{data_label} · Datenquelle geprüft: {checked_label}</div>',unsafe_allow_html=True)
            if lineup_data.get('is_projected'):
                st.caption('VORAUSSICHTLICH · vorläufige Meldung der Datenquelle')
            elif len(home_line)>=11 and len(away_line)>=11:
                st.caption('BESTÄTIGT · beide Startelfen veröffentlicht')
            elif home_line or away_line:
                st.caption('TEILWEISE · eine oder beide Startelfen unvollständig')
            else:
                st.caption('STARTELF NOCH NICHT VERFÜGBAR · voraussichtliche und bestätigte Teams erscheinen, sobald die Datenquelle sie veröffentlicht.')
            if home_line:
                cards=lineup_markup(p['home'],home_data.get('formation'),logos.get('home') or p.get('home_logo'),home_line)
            else:
                cards=lineup_pending_markup(p['home'],logos.get('home') or p.get('home_logo'))
            if away_line:
                cards+=lineup_markup(p['away'],away_data.get('formation'),logos.get('away') or p.get('away_logo'),away_line)
            else:
                cards+=lineup_pending_markup(p['away'],logos.get('away') or p.get('away_logo'))
            st.markdown('<div class="lineups-grid">'+cards+'</div>',unsafe_allow_html=True)
            source_url=team_context.get('source_url') or lineup_data.get('source_url')
            if team_context.get('source')=='Bundesliga.com' and source_url and source_url.startswith('https://www.bundesliga.com/'):
                st.markdown(f'[Offizieller Bundesliga-Vorbericht ↗]({source_url})')
                st.caption('Erwartete Startelfen und Personalmeldungen · redaktionelle Vorschau, keine bestätigte Aufstellung. Diese Angaben verändern die Modellwahrscheinlichkeiten nicht.')
            absences=team_context.get('absences_by_team') or {}
            complete=bool(team_context.get('injury_check_complete'))
            home_out=absences.get('home') or [];away_out=absences.get('away') or []
            st.markdown('**Bekannte Ausfälle & Fragezeichen**')
            absence_cards=absence_markup(p['home'],logos.get('home') or p.get('home_logo'),home_out,complete)
            absence_cards+=absence_markup(p['away'],logos.get('away') or p.get('away_logo'),away_out,complete)
            st.markdown('<div class="availability-grid">'+absence_cards+'</div>',unsafe_allow_html=True)
            adjustment=team_context.get('adjustment')
            if adjustment and (adjustment.get('home') or adjustment.get('away')):
                st.caption(f"Vorsichtiger Prognoseeffekt: {pretty(p['home'])} −{adjustment['home']:.2f} · {pretty(p['away'])} −{adjustment['away']:.2f} erwartete Tore. Dieser Zusatz ist noch nicht separat historisch kalibriert.")
            st.caption('Teamnews werden beim Optimieren geprüft und zwischengespeichert. Startelfen kommen nahe am Anpfiff. Redaktionelle Vorschauen sind klar als voraussichtlich markiert; fehlende Informationen werden nicht geraten.')
        show_table(pd.DataFrame([{'Expected Points':round(p['ep'],3),'Exakte Modellchance':f"{p['prob_exact']:.2%}",'Tendenzchance':f"{p['prob_tendency']:.2%}",'Heimtore λ':round(p['lambda_home'],3),'Auswärtstore λ':round(p['lambda_away'],3)}]))
        st.subheader('Alternative Tipps')
        show_table(pd.DataFrame([{'Tipp':a['tip'],'Expected Points':round(a['ep'],3),'Exakte Modellchance':f"{matrix[tuple(map(int,a['tip'].split(':')))]:.2%}"} for a in p['alternatives']]))
        st.subheader('Wahrscheinlichste Spielstände')
        scores=sorted(((float(matrix[h,a]),f'{h}:{a}') for h in range(len(matrix)) for a in range(len(matrix))),reverse=True)[:8]
        show_table(pd.DataFrame([{'Ergebnis':t,'Modellwahrscheinlichkeit':f'{v:.2%}'} for v,t in scores]))
        st.subheader('Punktechancen')
        show_table(pd.DataFrame([{'Punkte':k,'Modellwahrscheinlichkeit':f"{details['points'][k]:.2%}",'Beitrag zu Expected Points':round(k*details['points'][k],3)} for k in (4,2,1,0)]))
        st.subheader('1 / X / 2')
        show_table(pd.DataFrame([{'Heimsieg':f"{p['prob_home']:.2%}",'Remis':f"{p['prob_draw']:.2%}",'Auswärtssieg':f"{p['prob_away']:.2%}"}]))

render_site(page)
