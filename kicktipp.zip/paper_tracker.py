"""Read-only settlement of ONE supplied paper slip. No new betting picks."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlsplit
import hashlib
import html
import json
import re

import requests
import streamlit as st

ROOT=Path(__file__).resolve().parent
BASE='https://site.api.espn.com/apis/site/v2/sports/'
LEAGUES={'soccer/uefa.nations':'Nations League','hockey/nhl':'NHL','basketball/nba':'NBA'}


def stamp(value):
    try:
        dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return dt.astimezone(timezone.utc) if dt.tzinfo is not None else None
    except (ValueError,TypeError):return None


def definition():
    path=ROOT/'data/paper_slip_2026_11_12.json';raw=path.read_bytes();slip=json.loads(raw)
    if slip.get('schema')!=1 or slip.get('comparison_stake_cents')!=2000 or len(slip.get('legs',[]))!=10:
        raise ValueError('Ungültiger vorhandener Papierschein')
    keys=set()
    for leg in slip['legs']:
        key=(leg['league'],leg['event_id'])
        if key in keys or leg['league'] not in LEAGUES or not re.fullmatch(r'\d+',leg['event_id']):raise ValueError('Uneindeutiges Spiel')
        keys.add(key)
        if stamp(leg['kickoff']) is None or not re.fullmatch(r'\d{8}',leg['scoreboard_date']):raise ValueError('Datum fehlt')
        if leg['home']['id']==leg['away']['id']:raise ValueError('Teilnehmer fehlen')
        odds=Decimal(leg['odds_assumption'])
        if not odds.is_finite() or not Decimal(1)<odds<=Decimal(100):raise ValueError('Ungültige Annahmequote')
        if leg['market']=='winner':
            if leg['selected_team_id'] not in (leg['home']['id'],leg['away']['id']):raise ValueError('Anderes Team ausgewählt')
        elif leg['market'] in ('over','under'):
            line=Decimal(leg['line'])
            if not line.is_finite() or line%1!=Decimal('.5') or line<0:raise ValueError('Nur halbe Torgrenzen unterstützt')
        else:raise ValueError('Unbekannte feste Auswahl')
        if leg['regulation_only']!=leg['league'].startswith('soccer/'):raise ValueError('Unklare Spielzeitregel')
    return dict(slip,fingerprint=hashlib.sha256(raw).hexdigest())


@st.cache_data(ttl=60,show_spinner=False)
def fetch_board(league,day):
    if league not in LEAGUES or not re.fullmatch(r'\d{8}',day):raise ValueError('Ungültige Datenabfrage')
    checked=datetime.now(timezone.utc).isoformat()
    try:
        with requests.get(BASE+league+'/scoreboard',params={'dates':day,'limit':100},timeout=(3,9),stream=True) as response:
            response.raise_for_status();parts=[];size=0
            for part in response.iter_content(65536):
                size+=len(part)
                if size>3_000_000:raise ValueError('Antwort zu groß')
                parts.append(part)
        events=json.loads(b''.join(parts)).get('events')
        if not isinstance(events,list):raise ValueError('Unbekanntes Format')
        return {'ok':True,'events':events,'checked':checked}
    except (requests.RequestException,ValueError,TypeError):
        return {'ok':False,'events':[],'checked':checked}


def score(value):
    if isinstance(value,dict):value=value.get('value')
    return int(value) if re.fullmatch(r'\d{1,3}',str(value)) else None


def parse_event(raw,leg,now):
    if str(raw.get('id'))!=leg['event_id']:raise ValueError('Andere Ereignis-ID')
    comps=raw.get('competitions',[])
    if len(comps)!=1:raise ValueError('Uneindeutige Begegnung')
    comp=comps[0];sides={v['homeAway']:v for v in comp.get('competitors',[])}
    if len(comp.get('competitors',[]))!=2 or set(sides)!={'home','away'}:raise ValueError('Teilnehmer fehlen')
    if any(str(sides[s].get('team',{}).get('id'))!=leg[s]['id'] for s in sides):raise ValueError('Andere Teilnehmer')
    start=stamp(comp.get('date') or raw.get('date'))
    if start is None or start!=stamp(leg['kickoff']):raise ValueError('Geänderter Spieltermin, erneut prüfen')
    status=comp.get('status') or raw.get('status') or {};typ=status.get('type',{});state=typ.get('state','unknown')
    name=str(typ.get('name','')).upper()
    blocked=any(v in name for v in ('CANCEL','POSTPON','DELAY','SUSPEND','ABANDON','AWARD','FORFEIT'))
    values={s:score(c.get('score')) for s,c in sides.items()}
    if state=='pre':values={'home':None,'away':None}
    if blocked or state not in ('pre','in','post'):state='unknown'
    if state=='post':
        if typ.get('completed') is not True or now<start or any(v is None for v in values.values()):state='unknown'
        elif leg['regulation_only']:
            # Never settle football 1X2/total from an extra-time/penalty score.
            if status.get('period') not in (1,2) or name not in ('STATUS_FULL_TIME','STATUS_FINAL'):state='unknown'
        elif values['home']==values['away']:state='unknown'
    return {'state':state,'scores':values,'clock':str(status.get('displayClock','')),'period':status.get('period'),
            'detail':str(typ.get('shortDetail') or typ.get('description') or ''),'kickoff':start.isoformat()}


def leg_result(leg,event):
    if not event or event['state']=='unknown':return 'unknown'
    if event['state']!='post':return 'open'
    values=event['scores']
    if any(v is None for v in values.values()):return 'unknown'
    if leg['market']=='winner':
        side='home' if leg['selected_team_id']==leg['home']['id'] else 'away'
        won=values[side]>values['away' if side=='home' else 'home']
    else:
        total=Decimal(sum(values.values()));line=Decimal(leg['line'])
        won=total>line if leg['market']=='over' else total<line
    return 'won' if won else 'lost'


def settle(slip,rows):
    if len(rows)!=len(slip['legs']):raise ValueError('Unvollständige Auswertung')
    codes=[row['result'] for row in rows]
    state='lost' if 'lost' in codes else 'won' if all(v=='won' for v in codes) else 'unknown' if 'unknown' in codes else 'open'
    amount=slip['comparison_stake_cents'];product=Decimal(1)
    for leg in slip['legs']:product*=Decimal(leg['odds_assumption'])
    payout=0 if state=='lost' else int((Decimal(amount)*product).quantize(Decimal('1'),rounding=ROUND_HALF_UP)) if state=='won' else None
    net=payout-amount if payout is not None else None
    return {'state':state,'won':codes.count('won'),'lost':codes.count('lost'),'open':codes.count('open'),
            'unknown':codes.count('unknown'),'completed':codes.count('won')+codes.count('lost'),
            'stake_cents':amount,'payout_cents':payout,'net_cents':net,
            'avoided_loss_cents':max(0,-net) if net is not None else None,
            'assumed_combined_odds':str(product)}


def snapshot(slip,now=None):
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None:raise ValueError('Zeitzone fehlt')
    keys=sorted({(r['league'],r['scoreboard_date']) for r in slip['legs']})
    def get(key):return key,fetch_board(*key)
    with ThreadPoolExecutor(max_workers=3) as pool:boards=dict(pool.map(get,keys))
    rows=[]
    for leg in slip['legs']:
        board=boards[(leg['league'],leg['scoreboard_date'])];event=None;reason=None
        candidates=[v for v in board['events'] if str(v.get('id'))==leg['event_id']]
        if board['ok'] and len(candidates)==1:
            try:event=parse_event(candidates[0],leg,now)
            except (ValueError,KeyError,TypeError) as exc:reason=str(exc)
        else:reason='Quelle nicht erreichbar' if not board['ok'] else 'Spiel nicht eindeutig zugeordnet'
        rows.append({'leg':leg,'event':event,'result':leg_result(leg,event),'reason':reason})
    checks=[stamp(b['checked']) for b in boards.values()]
    checked=min((c for c in checks if c is not None),default=now)
    return {'rows':rows,'summary':settle(slip,rows),'checked':checked.isoformat(),'source_errors':sum(not b['ok'] for b in boards.values())}


def euro(cents):
    if cents is None:return 'Noch offen'
    return f'{Decimal(cents)/100:,.2f}'.replace(',','X').replace('.',',').replace('X','.')+' €'


def logo(value):
    url=urlsplit(value or '')
    return value if url.scheme=='https' and url.hostname=='a.espncdn.com' else ''


def render_card(row):
    from zoneinfo import ZoneInfo
    esc=lambda v:html.escape(str(v),quote=True)
    leg=row['leg'];event=row['event'];code=row['result'];start=stamp(leg['kickoff']).astimezone(ZoneInfo('Europe/Berlin'))
    label,color={'won':('Hätte getroffen','green'),'lost':('Hätte nicht getroffen','red'),'open':('Noch offen','neutral'),'unknown':('Nicht bestätigt','neutral')}[code]
    live=event and event['state']=='in'
    phase='Live' if live else 'Beendet' if code in ('won','lost') else 'Geplant' if event and event['state']=='pre' else 'Status offen'
    if live and event['clock']:
        prefix=('Q'+str(event['period'])+' · ') if leg['league']=='basketball/nba' else ('Drittel '+str(event['period'])+' · ') if leg['league']=='hockey/nhl' else ''
        phase+=' · '+prefix+event['clock']
    values=event['scores'] if event else {'home':None,'away':None}
    scoreline='– : –' if any(v is None for v in values.values()) else f"{values['home']} : {values['away']}"
    def team(side):
        t=leg[side];src=logo(t.get('logo'))
        return ('<img src="'+esc(src)+'" alt="">' if src else '')+'<span>'+esc(t['name'])+'</span>'
    return '<div class="paper-card"><div class="paper-meta"><span>'+esc(LEAGUES[leg['league']])+' · '+start.strftime('%d.%m. · %H:%M')+'</span><span>'+esc(phase)+'</span></div><div class="paper-game"><div class="paper-team">'+team('home')+'</div><b>'+scoreline+'</b><div class="paper-team paper-away">'+team('away')+'</div></div><div class="paper-pick"><small>Vorhandener Tipp aus deinem Chat</small><strong>'+esc(leg['selection_label'])+'</strong><span class="paper-badge '+color+'">'+label+'</span></div></div>'


def render():
    from zoneinfo import ZoneInfo
    st.markdown('''<style>.paper-total{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:16px;padding:18px;margin:12px 0}.paper-total h3{font-size:1.1rem!important;margin:0 0 14px}.paper-kpis{display:grid;grid-template-columns:1fr 1fr;gap:16px}.paper-kpis small{display:block;font-size:.7rem;color:var(--kt-muted)}.paper-kpis b{display:block;font-size:1.65rem;margin-top:3px}.paper-counts{font-size:.8rem;color:var(--kt-muted);margin:14px 0}.paper-card{border:1px solid var(--kt-border);background:var(--kt-card);border-radius:14px;padding:14px;margin:10px 0}.paper-meta{display:flex;justify-content:space-between;gap:10px;color:var(--kt-muted);font-size:.65rem;margin-bottom:14px}.paper-game{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);gap:8px;align-items:center}.paper-game>b{font-size:1.5rem;white-space:nowrap}.paper-team{display:flex;align-items:center;gap:6px;font-size:.8rem;line-height:1.3;overflow-wrap:anywhere}.paper-team img{width:26px;height:26px;object-fit:contain;flex-shrink:0}.paper-away{flex-direction:row-reverse;text-align:right}.paper-pick{border-top:1px solid var(--kt-border);margin-top:14px;padding-top:12px}.paper-pick small{display:block;color:var(--kt-muted);font-size:.64rem}.paper-pick strong{display:block;font-size:.88rem;margin:5px 0 10px}.paper-badge{padding:4px 8px;border-radius:20px;font-size:.68rem;font-weight:700;display:inline-block}.paper-badge.neutral{background:var(--kt-bg);color:var(--kt-muted);border:1px solid var(--kt-border)}</style>''',unsafe_allow_html=True)
    try:slip=definition();data=snapshot(slip)
    except (OSError,ValueError,KeyError,TypeError,InvalidOperation):
        st.warning('Der vorhandene Papierschein kann gerade nicht sicher ausgewertet werden. Es wird kein Ergebnis erfunden.');return
    summary=data['summary'];state=summary['state']
    title={'open':'Der Papierschein ist noch offen','unknown':'Auswertung teilweise unbestätigt','lost':'Der Papierschein hätte verloren','won':'Der Papierschein hätte gewonnen'}[state]
    st.markdown('<div class="paper-total"><h3>'+title+'</h3><div class="paper-kpis"><div><small>Fiktiver Vergleichseinsatz</small><b>'+euro(summary['stake_cents'])+'</b></div><div><small>Hypothetischer Verlust vermieden</small><b>'+euro(summary['avoided_loss_cents'])+'</b></div><div><small>Papierbilanz nach Annahmequoten</small><b>'+euro(summary['net_cents'])+'</b></div><div><small>Echter Geldeinsatz in dieser App</small><b>0 €</b></div></div></div>',unsafe_allow_html=True)
    st.caption('Festgelegter Schein · 20 € fiktiv · Annahmequoten unbestätigt')
    if state=='lost':
        st.info('Mindestens ein festgelegter Tipp ist nach bestätigtem Spielende falsch. Mit 20 € fiktivem Einsatz wäre der Schein damit gescheitert – diesen hypothetischen Verlust hast du durch Nichtwetten vermieden.')
    elif state=='won':
        st.info('Alle zehn Auswahlen sind nach bestätigtem Spielende richtig. Die Papierbilanz verwendet die unbestätigten Annahmequoten aus dem Chat. Ein vermiedener Verlust wird für diesen Schein nicht gezählt.')
    else:st.caption('Nur bestätigte Endergebnisse zählen.')
    st.markdown(f'<div class="paper-counts">{summary["won"]} getroffen · {summary["lost"]} nicht getroffen · {summary["open"]} offen · {summary["unknown"]} unbestätigt</div>',unsafe_allow_html=True)
    for row in data['rows']:st.markdown(render_card(row),unsafe_allow_html=True)
    checked=stamp(data['checked']).astimezone(ZoneInfo('Europe/Berlin')).strftime('%d.%m. · %H:%M')
    st.caption('Spielstände: ESPN · geprüft '+checked+' Uhr · Aktualisierung etwa minütlich bei geöffneter Seite. Nach erneutem Öffnen werden auch frühere Spieltage wieder abgefragt. Kein unbeaufsichtigter Hintergrundlauf.')
    if data['source_errors'] or summary['unknown']:st.warning('Einige Angaben sind gerade nicht bestätigt. Fehlende Spielstände werden nicht als 0:0 oder als Treffer gewertet.')
    with st.expander('Feste Auswahlen, Quoten und Auswertungsregeln'):
        st.write('Vergleich mit 20 € fiktivem Einsatz. Im ursprünglichen Chat standen 10 €. Die zehn Tipps wurden unverändert übernommen; die Annahmequoten sind nicht als tatsächlich verfügbare Quoten bestätigt.')
        st.write(slip['quote_note'])
        st.write('Fußball: reguläre Spielzeit einschließlich Nachspielzeit. NBA und NHL: Sieger einschließlich Verlängerung, bei NHL auch Shootout. Verschiebungen, Abbrüche, fehlende Daten und unklare Spielzeitregeln bleiben unbestätigt; es wird keine Buchmacher-Stornierung erfunden.')
        st.write('Ein bestätigter falscher Tipp lässt diesen vorhandenen Kombischein scheitern. Ein hypothetischer Gewinn wird erst gezählt, wenn alle zehn Auswahlen nach bestätigtem Spielende richtig sind. Die Rechenbilanz enthält keine behaupteten Steuern, Gebühren oder tatsächliche Bwin-Abrechnung.')
        st.write('Die Auswahl stammt aus dem vorgelegten Chat und wurde erst beim Einbau hier festgeschrieben. Das ist kein nachgewiesener Vorab-Modelltest. Es werden keine neuen Tipps oder Quoten erzeugt, keine Auswahlen ausgetauscht und keine Echtgeld-Wetten abgegeben.')
        st.write('Definition: '+slip['fingerprint'][:16]+' · importiert '+stamp(slip['definition_created_at']).astimezone(ZoneInfo('Europe/Berlin')).strftime('%d.%m.%Y %H:%M'))
        st.dataframe([{'Partie':r['home']['name']+' – '+r['away']['name'],'Vorhandene Auswahl':r['selection_label'],'Annahmequote':r['odds_assumption']} for r in slip['legs']],hide_index=True,width='stretch')
