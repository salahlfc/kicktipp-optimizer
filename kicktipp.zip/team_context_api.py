"""Cautious Bundesliga availability enrichment via Live Football API.

All provider requests are server-side, cached and strictly credit bounded by
the user supplied balance. The local model remains the fallback on any error.
"""
from __future__ import annotations

from datetime import timedelta
from html.parser import HTMLParser
import html
import math
import re
import unicodedata
from urllib.parse import urljoin, urlsplit

import numpy as np
import pandas as pd
import requests
import streamlit as st

from engine import canonical, optimal_from_matrix, prediction_matrix

BASE = 'https://live-football-api.com/api/v1'
LEAGUE_ID = '6by3h89i2eykc341oz7lv1ddd'
MAX_ABSENCE_LAMBDA_DELTA = 0.14
OFFICIAL_NEWS = 'https://www.bundesliga.com/en/bundesliga/news'
OFFICIAL_ROOT = 'https://www.bundesliga.com/'
OFFICIAL_PLAYERS = 'https://www.bundesliga.com/en/bundesliga/player'
OFFICIAL_PLAYERS = 'https://www.bundesliga.com/en/bundesliga/player'

_CLUB_SHORT = {
    'bayern':'bayern', 'munich':'bayern', 'cologne':'koln', 'köln':'koln',
    'union':'union', 'gladbach':'gladbach', 'leverkusen':'leverkusen',
    'frankfurt':'frankfurt', 'hoffenheim':'hoffenheim', 'freiburg':'freiburg',
    'schalke':'schalke', 'stuttgart':'stuttgart', 'augsburg':'augsburg',
    'mainz':'mainz', 'bremen':'bremen', 'hamburg':'hsv', 'leipzig':'leipzig',
    'elversberg':'elversberg', 'paderborn':'paderborn', 'dortmund':'dortmund',
}


class ProviderError(Exception):
    """Sanitized provider status; never includes request URLs or credentials."""


class _PageText(HTMLParser):
    """Extract readable article blocks and links without another dependency."""
    BLOCKS = {'h1','h2','h3','h4','p','li'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks, self.links = [], []
        self._block = None
        self._block_text = []
        self._link_href = None
        self._link_text = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in self.BLOCKS and self._block is None:
            self._block, self._block_text = tag, []
        if tag == 'a':
            self._link_href, self._link_text = attrs.get('href'), []
        if tag == 'br':
            if self._block is not None:self._block_text.append('\n')
            if self._link_href is not None:self._link_text.append(' ')

    def handle_data(self, data):
        if self._block is not None:self._block_text.append(data)
        if self._link_href is not None:self._link_text.append(data)

    def handle_endtag(self, tag):
        if tag in self.BLOCKS and self._block == tag:
            text=' '.join(' '.join(self._block_text).split())
            if text:self.blocks.append(text)
            self._block, self._block_text = None, []
        if tag == 'a' and self._link_href is not None:
            text=' '.join(' '.join(self._link_text).split())
            self.links.append((self._link_href,text))
            self._link_href, self._link_text = None, []


class _PlayerImages(HTMLParser):
    """Extract official player portrait links from the public league roster."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.images = {}
        self._player = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and '/en/player/' in str(attrs.get('href', '')):
            self._player = {'name': '', 'image': ''}
        elif tag == 'img' and self._player is not None:
            alt = str(attrs.get('alt', '')).strip()
            src = str(attrs.get('src') or attrs.get('data-src') or '').strip()
            if alt:
                self._player['name'] = alt
            if src:
                self._player['image'] = src

    def handle_endtag(self, tag):
        if tag == 'a' and self._player is not None:
            name, image = self._player['name'], self._player['image']
            host = urlsplit(image).hostname or ''
            if (name and image.startswith('https://') and host in {'assets.bundesliga.com', 'www.bundesliga.com'}
                    and '/player/' in urlsplit(image).path and 'placeholder' not in image.casefold()):
                self.images[_player_key(name)] = image
            self._player = None


def _player_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    return ' '.join(re.sub(r'[^a-z0-9 ]', ' ', value).split())


@st.cache_data(ttl=604800, show_spinner=False)
def _official_player_images():
    """Fetch one weekly cached set of free official player portrait links."""
    try:
        response = requests.get(OFFICIAL_PLAYERS, headers={'User-Agent': 'Mozilla/5.0 (compatible; KickTippOptimizer/1.0)'}, timeout=(3, 10))
        if response.status_code != 200 or len(response.content) > 12_000_000:
            return {}
        parser = _PlayerImages()
        parser.feed(response.text)
        return parser.images
    except (requests.RequestException, ValueError, TypeError):
        return {}


def _match_official_image(name, images):
    key = _player_key(name)
    if key in images:
        return images[key]
    words = key.split()
    if not words:
        return ''
    matches = []
    for candidate, image in images.items():
        parts = candidate.split()
        if not parts:
            continue
        if len(words) == 1 and parts[-1] == words[-1]:
            matches.append(image)
        elif len(words) >= 2 and parts[-len(words):] == words[1:] and parts[0].startswith(words[0][:1]):
            matches.append(image)
    return matches[0] if len(matches) == 1 else ''


class _PlayerImages(HTMLParser):
    """Read official Bundesliga player portraits from the public squad page."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.images = {}
        self._player = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and '/en/player/' in str(attrs.get('href', '')):
            self._player = {'name': '', 'image': ''}
        elif tag == 'img' and self._player is not None:
            alt = str(attrs.get('alt', '')).strip()
            src = str(attrs.get('src') or attrs.get('data-src') or '').strip()
            if alt:
                self._player['name'] = alt
            if src:
                self._player['image'] = src

    def handle_endtag(self, tag):
        if tag == 'a' and self._player is not None:
            name, image = self._player['name'], self._player['image']
            host = urlsplit(image).hostname or ''
            if (name and image.startswith('https://') and host in {'assets.bundesliga.com', 'www.bundesliga.com'}
                    and '/player/' in urlsplit(image).path and 'placeholder' not in image.casefold()):
                self.images[_player_key(name)] = image
            self._player = None


def _player_key(value):
    value = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().casefold()
    return ' '.join(re.sub(r'[^a-z0-9 ]', ' ', value).split())


@st.cache_data(ttl=604800, show_spinner=False)
def _official_player_images():
    """One free, weekly cached request for consistent official player portraits."""
    try:
        response = requests.get(OFFICIAL_PLAYERS, headers={'User-Agent': 'Mozilla/5.0 (compatible; KickTippOptimizer/1.0)'}, timeout=(3, 10))
        if response.status_code != 200 or len(response.content) > 12_000_000:
            return {}
        parser = _PlayerImages()
        parser.feed(response.text)
        return parser.images
    except (requests.RequestException, ValueError, TypeError):
        return {}


def _match_official_image(name, images):
    key = _player_key(name)
    if key in images:
        return images[key]
    words = key.split()
    if not words:
        return ''
    matches = []
    for candidate, image in images.items():
        parts = candidate.split()
        if not parts:
            continue
        if len(words) == 1 and parts[-1] == words[-1]:
            matches.append(image)
        elif len(words) >= 2 and parts[-len(words):] == words[1:] and parts[0].startswith(words[0][:1]):
            matches.append(image)
    return matches[0] if len(matches) == 1 else ''


def _key():
    try:
        return str(st.secrets.get('LIVE_FOOTBALL_API_KEY', '')).strip()
    except Exception:
        return ''


def _request(path, params, key):
    try:
        timeout = (3, 10)
        response = requests.get(BASE + path, params={**params, 'api_key': key}, timeout=timeout)
    except requests.Timeout:
        raise ProviderError('Zeitüberschreitung beim Team-News-Abruf.') from None
    except requests.RequestException:
        raise ProviderError('Team-News-Dienst ist gerade nicht erreichbar.') from None
    code = response.status_code
    if code == 401:
        raise ProviderError('Der gespeicherte Live-Football-Schlüssel ist ungültig.')
    if code == 403:
        raise ProviderError('Der Gratis-Creditstand ist aufgebraucht oder der Dienst hat den Zugriff pausiert.')
    if code == 429:
        raise ProviderError('Abruflimit des Team-News-Dienstes erreicht; später erneut versuchen.')
    if code == 503:
        raise ProviderError('Die externe Datenquelle ist vorübergehend nicht verfügbar.')
    if code != 200:
        raise ProviderError(f'Team-News-Dienst antwortet mit HTTP {code}.')
    try:
        payload = response.json()
    except ValueError:
        raise ProviderError('Die externe Datenquelle lieferte keine lesbaren Daten.') from None
    if not isinstance(payload, dict) or payload.get('success') is False:
        raise ProviderError('Der Abruf wurde von der Datenquelle abgelehnt.')
    return payload


@st.cache_data(ttl=86400, show_spinner=False)
def _matches_on_date(day, key):
    """Fetch only the UTC date needed, instead of a slow full-season schedule."""
    payload = _request('/matches', {'date': day, 'lang': 'de'}, key)
    data = payload.get('data', {})
    matches = data.get('matches', []) if isinstance(data, dict) else []
    if not isinstance(matches, list):
        raise ProviderError('Der Tages-Spielplan hat ein unerwartetes Format.')
    rows = []
    for match in matches:
        if not isinstance(match, dict):
            continue
        row = dict(match)
        row['_utc_day'] = str(day)
        rows.append(row)
    return rows, payload.get('credits_remaining'), payload.get('timestamp') or pd.Timestamp.now(tz='UTC').isoformat()


@st.cache_data(ttl=86400, show_spinner=False)
def _injuries(match_id, key):
    payload = _request('/injuries', {'match_id': match_id, 'lang': 'de'}, key)
    data = payload.get('data', {})
    checked_at = payload.get('timestamp') or (data.get('last_updated') if isinstance(data, dict) else None)
    return data if isinstance(data, dict) else {}, payload.get('credits_remaining'), checked_at or pd.Timestamp.now(tz='UTC').isoformat()


@st.cache_data(ttl=7200, show_spinner=False)
def _lineups(match_id, phase, key):
    payload = _request('/lineups', {'match_id': match_id, 'lang': 'de'}, key)
    data = payload.get('data', {})
    checked_at = payload.get('timestamp') or (data.get('last_updated') if isinstance(data, dict) else None)
    return data if isinstance(data, dict) else {}, payload.get('credits_remaining'), checked_at or pd.Timestamp.now(tz='UTC').isoformat()


def _club_key(value):
    text = str(value or '').strip().casefold().rstrip(':')
    return _CLUB_SHORT.get(text, canonical(text))


@st.cache_data(ttl=21600, show_spinner=False)
def _official_matchday_preview(season, round_number):
    """Free official fallback; projected XI and absences are display-only."""
    season_digits = re.sub(r'[^0-9]', '', str(season))
    try:
        year = int(season_digits[:4])
        round_number = int(round_number)
    except (ValueError, TypeError):
        return {'matches': {}, 'reason': 'Saison oder Spieltag nicht eindeutig.'}
    if not (2000 <= year <= 2100 and 1 <= round_number <= 34):
        return {'matches': {}, 'reason': 'Saison oder Spieltag außerhalb des gültigen Bereichs.'}
    headers = {'User-Agent': 'Mozilla/5.0 (compatible; KickTippOptimizer/1.0)', 'Accept-Language': 'en'}
    try:
        listing = requests.get(OFFICIAL_NEWS, headers=headers, timeout=(3, 8))
        if listing.status_code != 200 or len(listing.content) > 5_000_000:
            return {'matches': {}, 'reason': 'Offizieller Bundesliga-Newsbereich nicht erreichbar.'}
        listing_parser = _PageText()
        listing_parser.feed(listing.text)
        wanted = f'matchday {round_number} probable teams'
        article_url = ''
        for href, title in listing_parser.links:
            title_clean = ' '.join(html.unescape(title).casefold().split())
            candidate = urljoin(OFFICIAL_ROOT, href)
            if wanted in title_clean and urlsplit(candidate).hostname == 'www.bundesliga.com':
                article_url = candidate
                break
        if not article_url:
            # News pages sometimes omit article text from their initial HTML.
            # Do not guess another round's article if no exact title is found.
            return {'matches': {}, 'reason': 'Noch kein offizieller Vorbericht für diesen Spieltag gefunden.'}
        article = requests.get(article_url, headers=headers, timeout=(3, 8))
        if article.status_code != 200 or len(article.content) > 5_000_000:
            return {'matches': {}, 'reason': 'Offizieller Bundesliga-Vorbericht nicht lesbar.'}
    except requests.RequestException:
        return {'matches': {}, 'reason': 'Bundesliga.com ist derzeit nicht erreichbar.'}

    parser = _PageText()
    parser.feed(article.text)
    player_images = _official_player_images()
    matches, pair = {}, None
    home_label = away_label = active_team = None
    fixture_re = re.compile(r'^(.+?)\s+vs\.?\s+(.+?)(?:\s*\([^)]*\))?$', re.I)
    team_re = re.compile(r'^([^:]{2,45}):\s*(.*)$')
    report_field_re = re.compile(r'\b(Out|Doubtful|Coach)\s*:\s*', re.I)
    def parse_report_fields(content, target):
        fields = list(report_field_re.finditer(content))
        for index, field in enumerate(fields):
            label = field.group(1).casefold()
            if label == 'coach':
                continue
            end = fields[index + 1].start() if index + 1 < len(fields) else len(content)
            values = content[field.end():end].strip()
            key = 'out_listed' if label == 'out' else 'doubtful_listed'
            target[key] = True
            if not values or values == '-':
                continue
            for item in re.split(r'\s*,\s*', values):
                match = re.match(r'^(.+?)\s*\(([^)]*)\)\s*$', item)
                name, note = (match.group(1).strip(), match.group(2).strip()) if match else (item.strip(), '')
                if name and name != '-':
                    target['absences'].append({'name': name[:80], 'position': '',
                        'status': ('Ausfall' if label == 'out' else 'Fraglich') + (f' · {note[:60]}' if note else ''), 'image': ''})
    def flush_side():
        nonlocal active_team
        if pair and active_team:
            matches.setdefault(pair, {}).setdefault(active_team, {'starting': [], 'formation': '', 'absences': [], 'out_listed': False, 'doubtful_listed': False})
        active_team = None

    raw_blocks = [line for block in parser.blocks for line in re.split(r'[\r\n]+', block)]
    for raw in raw_blocks:
        text = ' '.join(html.unescape(raw).replace('\xa0', ' ').split()).strip()
        if not text:
            continue
        game = fixture_re.match(text)
        if game:
            flush_side()
            left, right = _club_key(game.group(1)), _club_key(game.group(2))
            if left and right:
                pair = (left, right)
                home_label, away_label = left, right
            else:
                pair = None
            continue
        if pair is None:
            continue
        team_match = team_re.match(text)
        if team_match:
            label, content = team_match.group(1).strip(), team_match.group(2).strip()
            key = _club_key(label)
            if key in (home_label, away_label):
                flush_side()
                active_team = 'home' if key == home_label else 'away'
                target = matches.setdefault(pair, {}).setdefault(active_team, {'starting': [], 'formation': '', 'absences': [], 'out_listed': False, 'doubtful_listed': False})
                # Article lineups use en dashes between positional groups and commas within groups.
                parse_report_fields(content, target)
                lineup_text = report_field_re.split(content, maxsplit=1)[0].strip()
                position_groups = []
                for block in re.split(r'\s*[–—]\s*', lineup_text):
                    names = [re.sub(r'\s*\(c\)\s*$', '', n).strip() for n in re.split(r'\s*,\s*', block)]
                    names = [n for n in names if n and n != '-']
                    if names:
                        position_groups.append(names)
                names = [n for group in position_groups for n in group]
                if len(names) >= 8:
                    structured = len(position_groups) in (4, 5) and len(position_groups[0]) == 1 and sum(len(g) for g in position_groups[1:]) == 10
                    if structured:
                        formation_counts = [len(g) for g in position_groups[1:]]
                        target['formation'] = '-'.join(str(n) for n in formation_counts)
                        starters = []
                        for group_index, group in enumerate(position_groups):
                            if group_index == 0:
                                role, line_group = 'Goalkeeper', -1
                            elif group_index == 1:
                                role, line_group = 'Defender', 0
                            elif group_index == len(position_groups)-1:
                                role, line_group = 'Forward', group_index-1
                            else:
                                role, line_group = 'Midfielder', group_index-1
                            for player_name in group:
                                starters.append({'name': player_name[:80], 'position': role, 'line_group': line_group,
                                                 'image': _match_official_image(player_name, player_images)})
                        target['starting'] = starters[:15]
                    else:
                        target['starting'] = [{'name': n[:80], 'position': '', 'image': _match_official_image(n, player_images)} for n in names[:15]]
                continue
        if active_team and text.casefold().startswith(('out:', 'doubtful:')):
            target = matches.setdefault(pair, {}).setdefault(active_team, {'starting': [], 'formation': '', 'absences': [], 'out_listed': False, 'doubtful_listed': False})
            parse_report_fields(text, target)
    flush_side()
    return {'matches': matches, 'source_url': article_url, 'source': 'Bundesliga.com',
            'checked_at': pd.Timestamp.now(tz='UTC').isoformat(), 'reason': ''}


def _official_context(preview, prediction):
    pair = (_club_key(prediction['home']), _club_key(prediction['away']))
    sides = (preview.get('matches') or {}).get(pair)
    if not sides:
        return None
    home = sides.get('home') or {}; away = sides.get('away') or {}
    if not home.get('starting') and not away.get('starting') and not home.get('absences') and not away.get('absences'):
        return None
    both_out_checked = bool(home.get('out_listed') and home.get('doubtful_listed') and away.get('out_listed') and away.get('doubtful_listed'))
    records = {side: {'starting': data.get('starting', []), 'formation': data.get('formation', '')} for side, data in (('home', home), ('away', away))}
    absences = {side: data.get('absences', []) for side, data in (('home', home), ('away', away))}
    return {'source': 'Bundesliga.com', 'source_url': preview.get('source_url'),
            'source_name': 'Offizieller Bundesliga-Vorbericht',
            'status': 'Offizieller Vorbericht · erwartete Aufstellungen und Personalmeldungen',
            'checked_at': preview.get('checked_at'), 'injuries_checked_at': preview.get('checked_at'),
            'injury_check_complete': both_out_checked, 'absences_by_team': absences,
            'absences': [f"{prediction[side]}: {x['name']} ({x['status']})" for side in ('home', 'away') for x in absences[side]],
            'lineup': 'Voraussichtliche Aufstellungen aus dem offiziellen Bundesliga-Vorbericht.',
            'lineups': {'is_projected': True, 'checked_at': preview.get('checked_at'), 'source_url': preview.get('source_url'), **records},
            'team_logos': {'home': prediction.get('home_logo', ''), 'away': prediction.get('away_logo', '')},
            'adjustment': None, 'method': 'Informationsanzeige; erwartete Aufstellungen und Ausfälle ändern die Modellwahrscheinlichkeiten nicht.'}


def _as_utc(value):
    ts = pd.Timestamp(value)
    return ts.tz_localize('UTC') if ts.tzinfo is None else ts.tz_convert('UTC')


def _is_bundesliga(row):
    league = row.get('league') or {}
    name = str(league.get('name', '')).strip().casefold()
    country = str(league.get('country', '')).strip().casefold()
    league_id = str(league.get('id', ''))
    # The request itself is scoped to LEAGUE_ID. Provider display names can
    # vary by language, so trust that stable ID even when its label changes.
    return league_id == LEAGUE_ID or (name in ('bundesliga', '1. bundesliga') and country in ('germany', 'deutschland'))


def _find_fixture(rows, prediction):
    target_home, target_away = canonical(prediction['home']), canonical(prediction['away'])
    target_time = _as_utc(prediction['kickoff'])
    by_pair = []
    for row in rows:
        # /matches contains all leagues; require the Bundesliga ID or its
        # explicit German league label before considering a fixture.
        if not _is_bundesliga(row):
            continue
        if canonical((row.get('home') or {}).get('name', '')) != target_home:
            continue
        if canonical((row.get('away') or {}).get('name', '')) != target_away:
            continue
        kickoff = row.get('kickoff')
        day = row.get('_utc_day')
        if not kickoff or not day:
            continue
        when = _as_utc(f'{day}T{kickoff}:00+00:00')
        delta = abs((when - target_time).total_seconds())
        by_pair.append((delta, row))
    # Team pair uniquely identifies the home fixture during a season. Use the
    # nearest schedule entry when feeds differ on UTC/local kickoff handling,
    # but never attach team news to a fixture more than 36 hours away.
    by_pair.sort(key=lambda item: item[0])
    if not by_pair or by_pair[0][0] > 36 * 3600:
        return None
    nearest = by_pair[0][0]
    tied = [row for delta, row in by_pair if delta == nearest]
    return tied[0] if len(tied) == 1 else None


def _absence_impact(injuries, starters):
    """Return a small, capped lambda adjustment for evidenced attacking output."""
    starter_ids = {str(x.get('id', '')).casefold() for x in starters if isinstance(x, dict)}
    details, impact = [], 0.0
    for player in injuries:
        if not isinstance(player, dict):
            continue
        name = str(player.get('name', '')).strip()
        if not name:
            continue
        if str(player.get('id', '')).casefold() in starter_ids:
            continue  # do not count an availability flag contradicted by the XI
        stats = player.get('stats') or {}
        appearances = stats.get('appearence', stats.get('appearances', stats.get('matches', 0)))
        try:
            appearances = float(appearances or 0)
            goals = float(stats.get('goals', 0) or 0)
            assists = float(stats.get('assists', 0) or 0)
        except (TypeError, ValueError):
            appearances, goals, assists = 0, 0, 0
        position = str(player.get('position', '')).casefold()
        contribution = (goals + assists) / appearances if appearances >= 5 else 0.0
        position_factor = 1.0 if any(x in position for x in ('forward', 'stürmer', 'attacker')) else .45 if any(x in position for x in ('midfield', 'mittelfeld')) else .15 if any(x in position for x in ('defend', 'verteidig')) else 0.0
        increment = min(.07, max(0.0, contribution - .12) * .045) * position_factor
        impact = min(MAX_ABSENCE_LAMBDA_DELTA, impact + increment)
        label = f'{name} ({player.get("status", "Ausfall")})'
        if increment:
            label += ' · leichter Tor-Erwartungsfaktor'
        details.append(label)
    return impact, details


def _tilt_matrix(matrix, old_home, old_away, new_home, new_away):
    """Shift goal marginals while retaining market blend and score dependence."""
    m = np.asarray(matrix, dtype=float).copy()
    goals = np.arange(m.shape[0], dtype=float)
    for axis, old, new in ((0, old_home, new_home), (1, old_away, new_away)):
        if old <= 0 or new <= 0 or abs(new - old) < 1e-10:
            continue
        ratio = new / old
        factors = np.exp(np.clip(goals * math.log(ratio) - (new - old), -20, 20))
        m *= factors[:, None] if axis == 0 else factors[None, :]
    total = float(m.sum())
    if not np.isfinite(total) or total <= 0:
        raise ValueError('Invalid adjusted score matrix')
    return m / total


def _with_official_fallback(predictions, season, round_number, now, base_reason):
    preview = _official_matchday_preview(str(season), int(round_number))
    updated, used, projected, reported = [], 0, 0, 0
    for original in predictions:
        p = dict(original)
        context = _official_context(preview, p)
        if context:
            p['team_context'] = context
            used += 1
            projected += bool((context.get('lineups') or {}).get('home', {}).get('starting') or
                              (context.get('lineups') or {}).get('away', {}).get('starting'))
            reported += len(context.get('absences', []))
        updated.append(p)
    if used:
        reason = f'{base_reason} Offizieller Bundesliga-Vorbericht für {used}/{len(predictions)} Spiele übernommen; {projected} mit erwarteter Startelf, {reported} Personalmeldungen. Nur Information, keine Modellanpassung.'
    else:
        detail = preview.get('reason') or 'kein passender offizieller Spielbericht gefunden'
        reason = f'{base_reason} Bundesliga-Vorbericht: {detail} Tipps bleiben unverändert.'
    return updated, {'enabled': True, 'reason': reason, 'checked_at': now.isoformat(),
                     'official_source': 'Bundesliga.com' if used else None,
                     'official_matches': used, 'projected_lineups': projected, 'official_absences': reported}


def enrich(predictions, season, now, round_number=None):
    """Add current team context; use the free official preview if the API fails."""
    key = _key()
    round_number = round_number or (predictions[0].get('round') if predictions else None)
    if not key:
        if round_number is not None:
            return _with_official_fallback(predictions, season, round_number, now,
                                           'Live Football API-Schlüssel fehlt.')
        return predictions, {'enabled': False, 'reason': 'Team-News-Schlüssel und Spieltag fehlen; Modell läuft unverändert.'}
    now_utc = _as_utc(now)
    fixtures, remaining = None, None
    try:
        updated, matched, injury_count, lineup_count, adjusted = [], 0, 0, 0, 0
        injury_checks, lineup_checks, injury_errors, lineup_errors = 0, 0, 0, 0
        # Pull only the match dates being optimized; the full-season endpoint
        # was timing out and was unnecessary for identifying these fixtures.
        fixtures_by_day, feed_errors, feed_timestamps = {}, {}, {}
        dates = sorted({_as_utc(p['kickoff']).strftime('%Y-%m-%d') for p in predictions
                        if _as_utc(p['kickoff']) >= now_utc})
        for day in dates:
            try:
                day_rows, rem, feed_timestamp = _matches_on_date(day, key)
                fixtures_by_day[day] = day_rows
                feed_timestamps[day] = feed_timestamp
                if rem is not None:
                    remaining = int(rem)
            except ProviderError as exc:
                feed_errors[day] = str(exc)
        for original in predictions:
            p = dict(original)
            kickoff = _as_utc(p['kickoff'])
            hours = (kickoff - now_utc).total_seconds() / 3600
            if hours < 0:
                p['team_context'] = {'source': 'Live Football API', 'status': 'Spiel bereits angepfiffen', 'absences': [], 'lineup': 'Personalcheck wird nicht nachträglich als Vorabinformation behandelt.', 'adjustment': None}
                updated.append(p)
                continue
            day = kickoff.strftime('%Y-%m-%d')
            if day in feed_errors:
                p['team_context'] = {'source': 'Live Football API', 'status': feed_errors[day], 'absences': [], 'lineup': 'Der Tages-Spielplan war nicht erreichbar; keine Teamdaten geraten.', 'adjustment': None}
                if round_number is not None:
                    p['team_context'] = _official_context(_official_matchday_preview(str(season), int(round_number)), p) or p['team_context']
                updated.append(p)
                continue
            fixture = _find_fixture(fixtures_by_day.get(day, []), p)
            if not fixture or not fixture.get('id'):
                p['team_context'] = {'source': 'Live Football API', 'status': 'Spiel nicht eindeutig zugeordnet', 'absences': [], 'lineup': 'Keine sicheren Teamdaten zugeordnet.', 'adjustment': None}
                if round_number is not None:
                    p['team_context'] = _official_context(_official_matchday_preview(str(season), int(round_number)), p) or p['team_context']
                updated.append(p)
                continue
            matched += 1
            match_id = str(fixture['id'])
            if remaining is not None and remaining <= 0:
                p['team_context'] = {'source': 'Live Football API', 'status': 'Gratis-Credits aufgebraucht', 'absences': [], 'lineup': 'Kein weiterer Abruf wurde gestartet.', 'adjustment': None}
                updated.append(p)
                continue
            try:
                data, rem, injuries_checked_at = _injuries(match_id, key)
            except ProviderError as exc:
                injury_errors += 1
                p['team_context'] = {
                    'source': 'Live Football API', 'status': str(exc), 'absences': [],
                    'lineup': 'Ausfallprüfung fehlgeschlagen; keine Teamdaten geraten.',
                    'injury_check_complete': False,
                    'checked_at': now_utc.isoformat(),
                    'team_logos': {'home': (fixture.get('home') or {}).get('logo',''), 'away': (fixture.get('away') or {}).get('logo','')},
                    'adjustment': None,
                }
                if round_number is not None:
                    p['team_context'] = _official_context(_official_matchday_preview(str(season), int(round_number)), p) or p['team_context']
                updated.append(p)
                continue
            injury_checks += 1
            if rem is not None:
                remaining = int(rem)
            injury_block = data.get('injuries') or {}
            home_abs = injury_block.get('home', []) if isinstance(injury_block, dict) else []
            away_abs = injury_block.get('away', []) if isinstance(injury_block, dict) else []
            absences = [
                f"{team}: {str(item.get('name', '')).strip()} ({item.get('status', 'Ausfall')})"
                for team, group in ((p['home'], home_abs), (p['away'], away_abs))
                for item in group
                if isinstance(item, dict) and str(item.get('name', '')).strip()
            ]
            def clean_absences(players):
                return [{'id': str(x.get('id',''))[:80],
                         'name': str(x.get('name',''))[:80],
                         'position': str(x.get('position',''))[:30],
                         'status': str(x.get('status','Ausfall'))[:80],
                         'image': str(x.get('image',''))[:300]}
                        for x in players if isinstance(x,dict) and str(x.get('name','')).strip()]
            home_absences=clean_absences(home_abs);away_absences=clean_absences(away_abs)
            injury_count += len(absences)
            lineup_summary = 'Noch nicht veröffentlicht.'
            home_starters = away_starters = []
            lineup_records = {}
            if 0 < hours <= 1.5 and (remaining is None or remaining > 0):
                phase = 'confirmed' if hours <= .5 else 'projected'
                try:
                    lineups, rem, lineups_checked_at = _lineups(match_id, phase, key)
                    lineup_checks += 1
                    if rem is not None:
                        remaining = int(rem)
                    home_data, away_data = lineups.get('home') or {}, lineups.get('away') or {}
                    home_starters, away_starters = home_data.get('starting') or [], away_data.get('starting') or []
                    projected = bool(lineups.get('is_projected'))
                    if len(home_starters) >= 11 and len(away_starters) >= 11 and not projected:
                        lineup_summary = 'Bestätigte Startelfen für beide Teams.'
                        lineup_count += 1
                    elif home_starters or away_starters:
                        lineup_summary = 'Aufstellung teilweise oder nur vorläufig veröffentlicht.'
                    else:
                        lineup_summary = 'Aufstellungen noch nicht verfügbar.'
                    def clean_players(players):
                        return [{'name': str(x.get('name',''))[:80],
                                 'position': str(x.get('position',''))[:30],
                                 'image': str(x.get('image',''))[:300]}
                                for x in players if isinstance(x,dict) and x.get('name')]
                    lineup_records = {
                        'is_projected': projected,
                        'checked_at': lineups_checked_at,
                        'home': {'starting': clean_players(home_starters), 'formation': str((lineups.get('formation') or {}).get('home',''))[:12]},
                        'away': {'starting': clean_players(away_starters), 'formation': str((lineups.get('formation') or {}).get('away',''))[:12]},
                    }
                except ProviderError:
                    lineup_errors += 1
                    lineup_summary = 'Aufstellungsquelle gerade nicht erreichbar; Ausfallprüfung bleibt erhalten.'
            home_delta, home_names = _absence_impact(home_abs, home_starters)
            away_delta, away_names = _absence_impact(away_abs, away_starters)
            old_home, old_away = float(p['lambda_home']), float(p['lambda_away'])
            new_home, new_away = max(.05, old_home - home_delta), max(.05, old_away - away_delta)
            matrix = _tilt_matrix(prediction_matrix(p), old_home, old_away, new_home, new_away)
            choice = optimal_from_matrix(matrix)
            p.update(choice)
            p['probability_matrix'] = matrix.tolist()
            p['lambda_home'], p['lambda_away'] = new_home, new_away
            p['team_context'] = {
                'source': 'Live Football API',
                'status': 'Aktuelle Daten geprüft',
                'checked_at': now_utc.isoformat(),
                'injuries_checked_at': injuries_checked_at,
                'lineups_checked_at': lineup_records.get('checked_at'),
                'injury_check_complete': True,
                'absences_by_team': {'home': home_absences, 'away': away_absences},
                'absences': absences,
                'lineup': lineup_summary,
                'lineups': lineup_records,
                'team_logos': {'home': (fixture.get('home') or {}).get('logo',''), 'away': (fixture.get('away') or {}).get('logo','')},
                'adjustment': {'home': round(home_delta, 3), 'away': round(away_delta, 3)},
                'adjusted_names': {'home': home_names, 'away': away_names},
                'method': 'Nur bestätigte Ausfälle mit mindestens fünf Einsätzen und ausgewiesenen Tor-/Assistdaten wirken auf λ; Kappung 0,14 Tore je Team. Diese Zusatzregel ist noch nicht separat historisch kalibriert.'
            }
            if home_delta or away_delta:
                adjusted += 1
            updated.append(p)
        window_text = f'{injury_checks}/{len(predictions)} kommende Spiele beim letzten Optimierungslauf auf Ausfälle geprüft'
        unavailable_days = len(feed_errors)
        feed_note = f' Tages-Spielplan für {unavailable_days} Datum/Daten nicht erreichbar.' if unavailable_days else ''
        partial_note = f' {injury_errors} Ausfallabruf/-abrufe und {lineup_errors} Aufstellungsabruf/-abrufe nicht erreichbar.' if injury_errors or lineup_errors else ''
        reason = f'Live Football API verbunden; {len(dates)-unavailable_days}/{len(dates)} Tages-Spielpläne geprüft; {window_text}; {injury_count} Ausfallmeldungen, {lineup_count} bestätigte Aufstellungen, {adjusted} Tipps vorsichtig angepasst.{feed_note}{partial_note}'
        official_status = {}
        if (feed_errors or injury_errors) and round_number is not None:
            # Only the fallback request is cached; dates and API failures are not re-requested here.
            fallback, official_status = _with_official_fallback(updated, season, round_number, now_utc, '')
            for i, prediction in enumerate(fallback):
                if (prediction.get('team_context', {}).get('source') == 'Bundesliga.com'
                        and prediction.get('team_context', {}).get('status') != 'Aktuelle Daten geprüft'):
                    updated[i] = prediction
            reason = reason + ' ' + official_status['reason']
        return updated, {'enabled': True, 'reason': reason, 'checked_at': now_utc.isoformat(), 'feed_checked_at': feed_timestamps, 'feed_errors': feed_errors, 'games_checked': injury_checks, 'lineup_checks': lineup_checks, 'injury_errors': injury_errors, 'lineup_errors': lineup_errors, 'injuries': injury_count, 'confirmed_lineups': lineup_count, 'adjusted_games': adjusted, 'credits_remaining': remaining, 'official_matches': official_status.get('official_matches',0), 'projected_lineups': official_status.get('projected_lineups',0), 'official_absences': official_status.get('official_absences',0)}
    except ProviderError as exc:
        if round_number is not None:
            return _with_official_fallback(predictions, season, round_number, now_utc, f'{exc}')
        return predictions, {'enabled': True, 'reason': f'{exc} Tipps bleiben unverändert.'}
    except (ValueError, TypeError, KeyError, OverflowError, IndexError) as exc:
        # Only exception type is exposed. Request parameters and response details stay private.
        kind = type(exc).__name__
        return predictions, {'enabled': True, 'reason': f'Team-News-Antwort konnte nicht sicher zugeordnet werden ({kind}); Tipps bleiben unverändert.'}
