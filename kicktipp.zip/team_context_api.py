"""Optional, cached Bundesliga context via API-Football's free API plan.

Never logs or returns the API key. Provider 1X2 forecasts are blended at a small,
explicit 10% weight; all 196 scorelines are re-optimized under the private 4/2/1
scoring rule. Missing or ambiguous fixtures leave the local model untouched.
"""
from __future__ import annotations
import re
import requests
import streamlit as st
import pandas as pd
from engine import canonical, prediction_matrix, optimal_from_matrix, SCORE_GRID, TIPS

BASE='https://v3.football.api-sports.io'
LEAGUE_ID=78
BLEND_WEIGHT=.10

class ProviderError(Exception):
    """A deliberately sanitized provider failure suitable for the app status."""


def _error_category(errors):
    """Map API-Football's free-form errors to fixed, non-sensitive messages."""
    if not errors:
        return None
    if isinstance(errors, dict):
        keys=' '.join(str(k).lower() for k in errors)
        values=' '.join(str(v).lower() for v in errors.values())
        raw=keys+' '+values
    elif isinstance(errors, (list, tuple)):
        raw=' '.join(str(v).lower() for v in errors)
    else:
        raw=str(errors).lower()
    # Never return provider text: it may contain request details or credentials.
    if any(x in raw for x in ('invalid api key','invalid key','unauthorized','token')):
        return 'API-Football weist den Schlüssel zurück; Secret-Namen und gespeicherten Schlüssel prüfen.'
    if any(x in raw for x in ('plan','subscription','access denied','not allowed','permission','endpoint')):
        return 'API-Schlüssel erkannt, aber der Gratisplan erlaubt mindestens einen benötigten Endpunkt nicht.'
    if any(x in raw for x in ('limit','quota','too many requests')):
        return 'API-Tageslimit oder Abrufquote erreicht; bitte später erneut versuchen.'
    if any(x in raw for x in ('date','season','league','fixture')):
        return 'API-Abfrage wurde wegen Liga-, Saison- oder Datumsangaben abgelehnt.'
    return 'API-Football meldet einen Fehler in der Abfrage (Antwort sicher ausgeblendet).'


def _get_json(path, params, key):
    r=requests.get(BASE+path,params=params,headers={'x-apisports-key':key},timeout=(3,8))
    try:
        r.raise_for_status()
    except requests.HTTPError as exc:
        code=r.status_code
        if code==401:
            reason='API-Football weist den Schlüssel zurück (HTTP 401); Secret-Eintrag prüfen.'
        elif code==403:
            reason='API-Schlüssel erkannt, Zugriff auf diesen Endpunkt verweigert (HTTP 403); Gratisplan-Abdeckung prüfen.'
        elif code==429:
            reason='API-Tageslimit oder Abrufquote erreicht (HTTP 429); später erneut versuchen.'
        elif code==404:
            reason='API-Endpunkt nicht gefunden (HTTP 404); API-Adresse prüfen.'
        else:
            reason=f'API-Football antwortet mit HTTP {code}.'
        raise ProviderError(f'{path}: {reason}') from None
    try:
        data=r.json()
    except (ValueError, requests.RequestException):
        raise ProviderError(f'{path}: Antwort ist kein gültiges JSON.') from None
    if not isinstance(data,dict):
        raise ProviderError(f'{path}: Antwort hat ein unerwartetes Format.')
    category=_error_category(data.get('errors'))
    if category:
        raise ProviderError(f'{path}: {category}')
    return data

def _key():
    try:return str(st.secrets.get('API_FOOTBALL_KEY','')).strip()
    except Exception:return ''

@st.cache_data(ttl=21600,show_spinner=False)
def _fixtures(day,season,key):
    j=_get_json('/fixtures',{'league':LEAGUE_ID,'season':season,'date':day},key)
    if j.get('results',0)>100:raise ProviderError('/fixtures: Antwort überschreitet die erwartete Größe.')
    rows=j.get('response',[])
    if not isinstance(rows,list):raise ProviderError('/fixtures: Spielplan-Antwort hat ein unerwartetes Format.')
    return rows

@st.cache_data(ttl=21600,show_spinner=False)
def _prediction(fid,key):
    j=_get_json('/predictions',{'fixture':fid},key)
    entries=j.get('response',[])
    if len(entries)!=1:return None
    raw=entries[0].get('predictions',{}).get('percent',{})
    def pct(x):
        m=re.search(r'\d+(?:\.\d+)?',str(x));return float(m.group())/100 if m else None
    values=[pct(raw.get(k)) for k in ('home','draw','away')]
    if any(v is None for v in values) or not .98<=sum(values)<=1.02:return None
    total=sum(values);return [v/total for v in values]

@st.cache_data(ttl=3600,show_spinner=False)
def _injuries(day,season,key):
    j=_get_json('/injuries',{'league':LEAGUE_ID,'season':season,'date':day},key)
    return j.get('response',[]) if isinstance(j.get('response',[]),list) else []

@st.cache_data(ttl=900,show_spinner=False)
def _lineups(fid,key):
    j=_get_json('/fixtures/lineups',{'fixture':fid},key)
    return j.get('response',[]) if isinstance(j.get('response',[]),list) else []

def enrich(predictions,season,now):
    key=_key()
    if not key:return predictions,{'enabled':False,'reason':'API-Schlüssel fehlt; Tipps unverändert.'}
    days=sorted({pd.Timestamp(p['kickoff']).strftime('%Y-%m-%d') for p in predictions})
    try:
        games=[]
        for day in days:games.extend(_fixtures(day,season,key))
        updated=[];used=0;injury_count=0;lineup_count=0
        injury_rows={day:_injuries(day,season,key) for day in days}
        for p in predictions:
            home,away=canonical(p['home']),canonical(p['away'])
            found=[]
            for g in games:
                t=g.get('teams',{});h=canonical(t.get('home',{}).get('name',''));a=canonical(t.get('away',{}).get('name',''))
                when=pd.Timestamp(g.get('fixture',{}).get('date'))
                if (h,a)==(home,away) and when.tz_convert('UTC')==pd.Timestamp(p['kickoff']).tz_convert('UTC'):found.append(g)
            if len(found)!=1:updated.append(p);continue
            fid=int(found[0]['fixture']['id']);external=_prediction(fid,key)
            injury_count+=sum(1 for item in injury_rows.get(pd.Timestamp(p['kickoff']).strftime('%Y-%m-%d'),[]) if item.get('fixture',{}).get('id')==fid)
            kickoff=pd.Timestamp(p['kickoff'])
            if pd.Timestamp(now)<kickoff and (kickoff-pd.Timestamp(now)).total_seconds()<=7200:
                lineups=_lineups(fid,key)
                if len(lineups)>=2 and all(len(x.get('startXI',[]))>=11 for x in lineups[:2]):lineup_count+=1
            if not external:updated.append(p);continue
            mat=prediction_matrix(p)
            local=[float(__import__('numpy').tril(mat,-1).sum()),float(__import__('numpy').trace(mat)),float(__import__('numpy').triu(mat,1).sum())]
            target=[(1-BLEND_WEIGHT)*x+BLEND_WEIGHT*y for x,y in zip(local,external)]
            import numpy as np
            factors=[target[i]/local[i] if local[i]>1e-12 else 1. for i in range(3)]
            mat=np.where(np.tril(np.ones_like(mat),-1,dtype=bool),mat*factors[0],mat)
            mat=np.where(np.eye(mat.shape[0],dtype=bool),mat*factors[1],mat)
            mat=np.where(np.triu(np.ones_like(mat),1,dtype=bool),mat*factors[2],mat)
            mat=mat/mat.sum();q=optimal_from_matrix(mat);q.update({k:p[k] for k in p if k not in q})
            q['probability_matrix']=mat.tolist();q['context_source']='API-Football';q['context_weight']=BLEND_WEIGHT
            q['context_fixture_id']=fid
            updated.append(q);used+=1
        return updated,{'enabled':True,'reason':f'API-Football automatisch geprüft: Prognose mit 10% Zusatzgewicht bei {used}/{len(predictions)} Spielen; {injury_count} gemeldete Ausfall-Einträge, bestätigte Startelf bei {lineup_count}/{len(predictions)} Spielen. Personalinformationen wirken nur über die Zusatzprognose; unbestätigte/fehlende Daten bleiben ohne Einfluss.','games':used,'injuries':injury_count,'confirmed_lineups':lineup_count}
    except ProviderError as exc:
        return predictions,{'enabled':True,'reason':f'{exc}; Tipps unverändert.'}
    except (requests.RequestException,ValueError,TypeError,KeyError,OverflowError) as exc:
        # Exception class is safe to show; response bodies and request headers may contain secrets.
        kind=type(exc).__name__
        reason={'Timeout':'Zeitüberschreitung beim API-Abruf.','ConnectionError':'API-Football nicht erreichbar.','ValueError':'Unerwartete API-Antwort oder Zeitformat.','KeyError':'Unerwartetes Format der API-Antwort.','TypeError':'Unerwarteter Datentyp der API-Antwort.','OverflowError':'Ungültiger Zahlenwert der API-Antwort.'}.get(kind,'API-Abruf fehlgeschlagen.')
        return predictions,{'enabled':True,'reason':f'{reason} ({kind}); Tipps unverändert.'}
