"""Cautious Bundesliga availability enrichment via Live Football API.

All provider requests are server-side, cached and strictly credit bounded by
the user supplied balance. The local model remains the fallback on any error.
"""
from __future__ import annotations

from datetime import timedelta
import math
import re

import numpy as np
import pandas as pd
import requests
import streamlit as st

from engine import canonical, optimal_from_matrix, prediction_matrix

BASE = 'https://live-football-api.com/api/v1'
LEAGUE_ID = '6by3h89i2eykc341oz7lv1ddd'
MAX_ABSENCE_LAMBDA_DELTA = 0.14


class ProviderError(Exception):
    """Sanitized provider status; never includes request URLs or credentials."""


def _key():
    try:
        return str(st.secrets.get('LIVE_FOOTBALL_API_KEY', '')).strip()
    except Exception:
        return ''


def _request(path, params, key):
    try:
        timeout = (3, 10)
        response = requests.get(BASE + path, params={**params, 'api_key': key}, timeout=timeout)
    except requests.Timeout:
        raise ProviderError('Zeitüberschreitung beim Team-News-Abruf.') from None
    except requests.RequestException:
        raise ProviderError('Team-News-Dienst ist gerade nicht erreichbar.') from None
    code = response.status_code
    if code == 401:
        raise ProviderError('Der gespeicherte Live-Football-Schlüssel ist ungültig.')
    if code == 403:
        raise ProviderError('Der Gratis-Creditstand ist aufgebraucht oder der Dienst hat den Zugriff pausiert.')
    if code == 429:
        raise ProviderError('Abruflimit des Team-News-Dienstes erreicht; später erneut versuchen.')
    if code == 503:
        raise ProviderError('Die externe Datenquelle ist vorübergehend nicht verfügbar.')
    if code != 200:
        raise ProviderError(f'Team-News-Dienst antwortet mit HTTP {code}.')
    try:
        payload = response.json()
    except ValueError:
        raise ProviderError('Die externe Datenquelle lieferte keine lesbaren Daten.') from None
    if not isinstance(payload, dict) or payload.get('success') is False:
        raise ProviderError('Der Abruf wurde von der Datenquelle abgelehnt.')
    return payload


@st.cache_data(ttl=86400, show_spinner=False)
def _matches_on_date(day, key):
    """Fetch only the UTC date needed, instead of a slow full-season schedule."""
    payload = _request('/matches', {'date': day, 'lang': 'de'}, key)
    data = payload.get('data', {})
    matches = data.get('matches', []) if isinstance(data, dict) else []
    if not isinstance(matches, list):
        raise ProviderError('Der Tages-Spielplan hat ein unerwartetes Format.')
    rows = []
    for match in matches:
        if not isinstance(match, dict):
            continue
        row = dict(match)
        row['_utc_day'] = str(day)
        rows.append(row)
    return rows, payload.get('credits_remaining'), payload.get('timestamp') or pd.Timestamp.now(tz='UTC').isoformat()


@st.cache_data(ttl=86400, show_spinner=False)
def _injuries(match_id, key):
    payload = _request('/injuries', {'match_id': match_id, 'lang': 'de'}, key)
    data = payload.get('data', {})
    checked_at = payload.get('timestamp') or (data.get('last_updated') if isinstance(data, dict) else None)
    return data if isinstance(data, dict) else {}, payload.get('credits_remaining'), checked_at or pd.Timestamp.now(tz='UTC').isoformat()


@st.cache_data(ttl=7200, show_spinner=False)
def _lineups(match_id, phase, key):
    payload = _request('/lineups', {'match_id': match_id, 'lang': 'de'}, key)
    data = payload.get('data', {})
    checked_at = payload.get('timestamp') or (data.get('last_updated') if isinstance(data, dict) else None)
    return data if isinstance(data, dict) else {}, payload.get('credits_remaining'), checked_at or pd.Timestamp.now(tz='UTC').isoformat()


def _as_utc(value):
    ts = pd.Timestamp(value)
    return ts.tz_localize('UTC') if ts.tzinfo is None else ts.tz_convert('UTC')


def _is_bundesliga(row):
    league = row.get('league') or {}
    name = str(league.get('name', '')).strip().casefold()
    country = str(league.get('country', '')).strip().casefold()
    league_id = str(league.get('id', ''))
    # The request itself is scoped to LEAGUE_ID. Provider display names can
    # vary by language, so trust that stable ID even when its label changes.
    return league_id == LEAGUE_ID or (name in ('bundesliga', '1. bundesliga') and country in ('germany', 'deutschland'))


def _find_fixture(rows, prediction):
    target_home, target_away = canonical(prediction['home']), canonical(prediction['away'])
    target_time = _as_utc(prediction['kickoff'])
    by_pair = []
    for row in rows:
        # /matches contains all leagues; require the Bundesliga ID or its
        # explicit German league label before considering a fixture.
        if not _is_bundesliga(row):
            continue
        if canonical((row.get('home') or {}).get('name', '')) != target_home:
            continue
        if canonical((row.get('away') or {}).get('name', '')) != target_away:
            continue
        kickoff = row.get('kickoff')
        day = row.get('_utc_day')
        if not kickoff or not day:
            continue
        when = _as_utc(f'{day}T{kickoff}:00+00:00')
        delta = abs((when - target_time).total_seconds())
        by_pair.append((delta, row))
    # Team pair uniquely identifies the home fixture during a season. Use the
    # nearest schedule entry when feeds differ on UTC/local kickoff handling,
    # but never attach team news to a fixture more than 36 hours away.
    by_pair.sort(key=lambda item: item[0])
    if not by_pair or by_pair[0][0] > 36 * 3600:
        return None
    nearest = by_pair[0][0]
    tied = [row for delta, row in by_pair if delta == nearest]
    return tied[0] if len(tied) == 1 else None


def _absence_impact(injuries, starters):
    """Return a small, capped lambda adjustment for evidenced attacking output."""
    starter_ids = {str(x.get('id', '')).casefold() for x in starters if isinstance(x, dict)}
    details, impact = [], 0.0
    for player in injuries:
        if not isinstance(player, dict):
            continue
        name = str(player.get('name', '')).strip()
        if not name:
            continue
        if str(player.get('id', '')).casefold() in starter_ids:
            continue  # do not count an availability flag contradicted by the XI
        stats = player.get('stats') or {}
        appearances = stats.get('appearence', stats.get('appearances', stats.get('matches', 0)))
        try:
            appearances = float(appearances or 0)
            goals = float(stats.get('goals', 0) or 0)
            assists = float(stats.get('assists', 0) or 0)
        except (TypeError, ValueError):
            appearances, goals, assists = 0, 0, 0
        position = str(player.get('position', '')).casefold()
        contribution = (goals + assists) / appearances if appearances >= 5 else 0.0
        position_factor = 1.0 if any(x in position for x in ('forward', 'stürmer', 'attacker')) else .45 if any(x in position for x in ('midfield', 'mittelfeld')) else .15 if any(x in position for x in ('defend', 'verteidig')) else 0.0
        increment = min(.07, max(0.0, contribution - .12) * .045) * position_factor
        impact = min(MAX_ABSENCE_LAMBDA_DELTA, impact + increment)
        label = f'{name} ({player.get("status", "Ausfall")})'
        if increment:
            label += ' · leichter Tor-Erwartungsfaktor'
        details.append(label)
    return impact, details


def _tilt_matrix(matrix, old_home, old_away, new_home, new_away):
    """Shift goal marginals while retaining market blend and score dependence."""
    m = np.asarray(matrix, dtype=float).copy()
    goals = np.arange(m.shape[0], dtype=float)
    for axis, old, new in ((0, old_home, new_home), (1, old_away, new_away)):
        if old <= 0 or new <= 0 or abs(new - old) < 1e-10:
            continue
        ratio = new / old
        factors = np.exp(np.clip(goals * math.log(ratio) - (new - old), -20, 20))
        m *= factors[:, None] if axis == 0 else factors[None, :]
    total = float(m.sum())
    if not np.isfinite(total) or total <= 0:
        raise ValueError('Invalid adjusted score matrix')
    return m / total


def enrich(predictions, season, now):
    """Add current verified team context; preserve original forecast if unavailable."""
    del season  # The provider always serves its current-season match feed.
    key = _key()
    if not key:
        return predictions, {'enabled': False, 'reason': 'Team-News-Schlüssel fehlt; Modell läuft unverändert.'}
    now_utc = _as_utc(now)
    fixtures, remaining = None, None
    try:
        updated, matched, injury_count, lineup_count, adjusted = [], 0, 0, 0, 0
        injury_checks, lineup_checks, injury_errors, lineup_errors = 0, 0, 0, 0
        # Pull only the match dates being optimized; the full-season endpoint
        # was timing out and was unnecessary for identifying these fixtures.
        fixtures_by_day, feed_errors, feed_timestamps = {}, {}, {}
        dates = sorted({_as_utc(p['kickoff']).strftime('%Y-%m-%d') for p in predictions
                        if _as_utc(p['kickoff']) >= now_utc})
        for day in dates:
            try:
                day_rows, rem, feed_timestamp = _matches_on_date(day, key)
                fixtures_by_day[day] = day_rows
                feed_timestamps[day] = feed_timestamp
                if rem is not None:
                    remaining = int(rem)
            except ProviderError as exc:
                feed_errors[day] = str(exc)
        for original in predictions:
            p = dict(original)
            kickoff = _as_utc(p['kickoff'])
            hours = (kickoff - now_utc).total_seconds() / 3600
            if hours < 0:
                p['team_context'] = {'source': 'Live Football API', 'status': 'Spiel bereits angepfiffen', 'absences': [], 'lineup': 'Personalcheck wird nicht nachträglich als Vorabinformation behandelt.', 'adjustment': None}
                updated.append(p)
                continue
            day = kickoff.strftime('%Y-%m-%d')
            if day in feed_errors:
                p['team_context'] = {'source': 'Live Football API', 'status': feed_errors[day], 'absences': [], 'lineup': 'Der Tages-Spielplan war nicht erreichbar; keine Teamdaten geraten.', 'adjustment': None}
                updated.append(p)
                continue
            fixture = _find_fixture(fixtures_by_day.get(day, []), p)
            if not fixture or not fixture.get('id'):
                p['team_context'] = {'source': 'Live Football API', 'status': 'Spiel nicht eindeutig zugeordnet', 'absences': [], 'lineup': 'Keine sicheren Teamdaten zugeordnet.', 'adjustment': None}
                updated.append(p)
                continue
            matched += 1
            match_id = str(fixture['id'])
            if remaining is not None and remaining <= 0:
                p['team_context'] = {'source': 'Live Football API', 'status': 'Gratis-Credits aufgebraucht', 'absences': [], 'lineup': 'Kein weiterer Abruf wurde gestartet.', 'adjustment': None}
                updated.append(p)
                continue
            try:
                data, rem, injuries_checked_at = _injuries(match_id, key)
            except ProviderError as exc:
                injury_errors += 1
                p['team_context'] = {
                    'source': 'Live Football API', 'status': str(exc), 'absences': [],
                    'lineup': 'Ausfallprüfung fehlgeschlagen; keine Teamdaten geraten.',
                    'injury_check_complete': False,
                    'checked_at': now_utc.isoformat(),
                    'team_logos': {'home': (fixture.get('home') or {}).get('logo',''), 'away': (fixture.get('away') or {}).get('logo','')},
                    'adjustment': None,
                }
                updated.append(p)
                continue
            injury_checks += 1
            if rem is not None:
                remaining = int(rem)
            injury_block = data.get('injuries') or {}
            home_abs = injury_block.get('home', []) if isinstance(injury_block, dict) else []
            away_abs = injury_block.get('away', []) if isinstance(injury_block, dict) else []
            absences = [
                f"{team}: {str(item.get('name', '')).strip()} ({item.get('status', 'Ausfall')})"
                for team, group in ((p['home'], home_abs), (p['away'], away_abs))
                for item in group
                if isinstance(item, dict) and str(item.get('name', '')).strip()
            ]
            def clean_absences(players):
                return [{'id': str(x.get('id',''))[:80],
                         'name': str(x.get('name',''))[:80],
                         'position': str(x.get('position',''))[:30],
                         'status': str(x.get('status','Ausfall'))[:80],
                         'image': str(x.get('image',''))[:300]}
                        for x in players if isinstance(x,dict) and str(x.get('name','')).strip()]
            home_absences=clean_absences(home_abs);away_absences=clean_absences(away_abs)
            injury_count += len(absences)
            lineup_summary = 'Noch nicht veröffentlicht.'
            home_starters = away_starters = []
            lineup_records = {}
            if 0 < hours <= 1.5 and (remaining is None or remaining > 0):
                phase = 'confirmed' if hours <= .5 else 'projected'
                try:
                    lineups, rem, lineups_checked_at = _lineups(match_id, phase, key)
                    lineup_checks += 1
                    if rem is not None:
                        remaining = int(rem)
                    home_data, away_data = lineups.get('home') or {}, lineups.get('away') or {}
                    home_starters, away_starters = home_data.get('starting') or [], away_data.get('starting') or []
                    projected = bool(lineups.get('is_projected'))
                    if len(home_starters) >= 11 and len(away_starters) >= 11 and not projected:
                        lineup_summary = 'Bestätigte Startelfen für beide Teams.'
                        lineup_count += 1
                    elif home_starters or away_starters:
                        lineup_summary = 'Aufstellung teilweise oder nur vorläufig veröffentlicht.'
                    else:
                        lineup_summary = 'Aufstellungen noch nicht verfügbar.'
                    def clean_players(players):
                        return [{'name': str(x.get('name',''))[:80],
                                 'position': str(x.get('position',''))[:30],
                                 'image': str(x.get('image',''))[:300]}
                                for x in players if isinstance(x,dict) and x.get('name')]
                    lineup_records = {
                        'is_projected': projected,
                        'checked_at': lineups_checked_at,
                        'home': {'starting': clean_players(home_starters), 'formation': str((lineups.get('formation') or {}).get('home',''))[:12]},
                        'away': {'starting': clean_players(away_starters), 'formation': str((lineups.get('formation') or {}).get('away',''))[:12]},
                    }
                except ProviderError:
                    lineup_errors += 1
                    lineup_summary = 'Aufstellungsquelle gerade nicht erreichbar; Ausfallprüfung bleibt erhalten.'
            home_delta, home_names = _absence_impact(home_abs, home_starters)
            away_delta, away_names = _absence_impact(away_abs, away_starters)
            old_home, old_away = float(p['lambda_home']), float(p['lambda_away'])
            new_home, new_away = max(.05, old_home - home_delta), max(.05, old_away - away_delta)
            matrix = _tilt_matrix(prediction_matrix(p), old_home, old_away, new_home, new_away)
            choice = optimal_from_matrix(matrix)
            p.update(choice)
            p['probability_matrix'] = matrix.tolist()
            p['lambda_home'], p['lambda_away'] = new_home, new_away
            p['team_context'] = {
                'source': 'Live Football API',
                'status': 'Aktuelle Daten geprüft',
                'checked_at': now_utc.isoformat(),
                'injuries_checked_at': injuries_checked_at,
                'lineups_checked_at': lineup_records.get('checked_at'),
                'injury_check_complete': True,
                'absences_by_team': {'home': home_absences, 'away': away_absences},
                'absences': absences,
                'lineup': lineup_summary,
                'lineups': lineup_records,
                'team_logos': {'home': (fixture.get('home') or {}).get('logo',''), 'away': (fixture.get('away') or {}).get('logo','')},
                'adjustment': {'home': round(home_delta, 3), 'away': round(away_delta, 3)},
                'adjusted_names': {'home': home_names, 'away': away_names},
                'method': 'Nur bestätigte Ausfälle mit mindestens fünf Einsätzen und ausgewiesenen Tor-/Assistdaten wirken auf λ; Kappung 0,14 Tore je Team. Diese Zusatzregel ist noch nicht separat historisch kalibriert.'
            }
            if home_delta or away_delta:
                adjusted += 1
            updated.append(p)
        window_text = f'{injury_checks}/{len(predictions)} kommende Spiele beim letzten Optimierungslauf auf Ausfälle geprüft'
        unavailable_days = len(feed_errors)
        feed_note = f' Tages-Spielplan für {unavailable_days} Datum/Daten nicht erreichbar.' if unavailable_days else ''
        partial_note = f' {injury_errors} Ausfallabruf/-abrufe und {lineup_errors} Aufstellungsabruf/-abrufe nicht erreichbar.' if injury_errors or lineup_errors else ''
        reason = f'Live Football API verbunden; {len(dates)-unavailable_days}/{len(dates)} Tages-Spielpläne geprüft; {window_text}; {injury_count} Ausfallmeldungen, {lineup_count} bestätigte Aufstellungen, {adjusted} Tipps vorsichtig angepasst.{feed_note}{partial_note}'
        return updated, {'enabled': True, 'reason': reason, 'checked_at': now_utc.isoformat(), 'feed_checked_at': feed_timestamps, 'feed_errors': feed_errors, 'games_checked': injury_checks, 'lineup_checks': lineup_checks, 'injury_errors': injury_errors, 'lineup_errors': lineup_errors, 'injuries': injury_count, 'confirmed_lineups': lineup_count, 'adjusted_games': adjusted, 'credits_remaining': remaining}
    except ProviderError as exc:
        return predictions, {'enabled': True, 'reason': f'{exc} Tipps bleiben unverändert.'}
    except (ValueError, TypeError, KeyError, OverflowError, IndexError) as exc:
        # Only exception type is exposed. Request parameters and response details stay private.
        kind = type(exc).__name__
        return predictions, {'enabled': True, 'reason': f'Team-News-Antwort konnte nicht sicher zugeordnet werden ({kind}); Tipps bleiben unverändert.'}
