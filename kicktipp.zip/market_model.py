"""Bounded market correction, selected before the separate test season.

Only non-closing average 1X2 odds. Historic publication times are unknown:
this is an odds-availability scenario, never a validated Tuesday snapshot.
"""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
import pandas as pd
import requests
from engine import canonical, ModelSpec, optimal_from_matrix, prediction_matrix
from advanced_model import evaluate_matrices, calibrate, scored

WEIGHTS=(0.,.1,.2,.3)
SOURCE='https://www.football-data.co.uk/fixtures.csv'

def club(text):
    return {'m gladbach':'gladbach','nott m forest':'nottingham'}.get(canonical(text),canonical(text))

def fair_odds(values):
    odds=np.asarray(values,dtype=float)
    if odds.shape!=(3,) or not np.isfinite(odds).all() or np.any(odds<=1):raise ValueError('Ungültige 1X2-Quoten')
    raw=1/odds;margin=float(raw.sum())
    if not .98<=margin<=1.30:raise ValueError('Unplausible Quotenmarge')
    return raw/margin

def correct(matrix,market,weight):
    p=np.asarray(matrix,dtype=float)
    q=np.asarray(market,dtype=float)
    if p.ndim!=2 or p.shape[0]!=p.shape[1] or not np.isfinite(p).all() or (p<0).any() or not np.isclose(p.sum(),1):raise ValueError('Ungültige Ergebnismatrix')
    if not 0<=weight<=.3 or q.shape!=(3,) or not np.isfinite(q).all() or (q<=0).any() or not np.isclose(q.sum(),1):raise ValueError('Ungültige Marktgewichtung')
    if not weight:return p.copy()
    i,j=np.indices(p.shape);masks=[i>j,i==j,i<j]
    base=np.array([p[m].sum() for m in masks]);target=(1-weight)*base+weight*q
    out=p.copy()
    for mask,b,t in zip(masks,base,target):
        if b<=0:raise ValueError('Leere Tendenzklasse')
        out[mask]*=t/b
    return out/out.sum()

def read_csv(content):
    if len(content)>3_000_000:raise ValueError('Quotendatei zu groß')
    d=pd.read_csv(io.BytesIO(content),encoding='utf-8-sig')
    required={'Div','Date','HomeTeam','AwayTeam','AvgH','AvgD','AvgA'}
    if not required.issubset(d.columns):raise ValueError('Unbekanntes Quotenformat')
    d=d[d.Div=='D1'].copy()
    d['date']=pd.to_datetime(d.Date,dayfirst=True,format='mixed',errors='coerce').dt.strftime('%Y-%m-%d')
    d['home']=d.HomeTeam.map(club);d['away']=d.AwayTeam.map(club)
    return d

def choose_market(history,bundle,outdir,progress=lambda s:None):
    from leanflow import atomic_json
    outdir=Path(outdir);folder=outdir/'market_data';folder.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256((json.dumps(bundle,sort_keys=True)+Path(__file__).read_text()).encode())
    digest.update(pd.util.hash_pandas_object(history[['date','home','away','hg','ag']],index=False).values.tobytes())
    frames=[]
    for y in range(2021,2026):
        path=folder/f'{y}.csv'
        if not path.exists():
            r=requests.get(f'https://www.football-data.co.uk/mmz4281/{str(y)[2:]}{str(y+1)[2:]}/D1.csv',timeout=(5,25));r.raise_for_status()
            read_csv(r.content);path.write_bytes(r.content)
        content=path.read_bytes();digest.update(content);frames.append(read_csv(content))
    key=digest.hexdigest();target=outdir/'market_report.json'
    try:
        cached=json.loads(target.read_text())
        if cached['signature']==key:return cached
    except (OSError,ValueError,KeyError):pass
    quotes=pd.concat(frames,ignore_index=True)
    quotes=quotes.drop_duplicates(['date','home','away'],keep=False)
    quote_map={tuple(r[k] for k in ('date','home','away')):r for r in quotes.to_dict('records')}
    def matrices_for(seasons):
        pieces=[];records=None
        for item in bundle['models']:
            progress(f'Wettmarkt-Gewichtung prüfen · Saisons {seasons[0]}–{seasons[-1]} …')
            rec,m=evaluate_matrices(history,seasons,ModelSpec(**item['spec']))
            if records is not None and not records.equals(rec):raise ValueError('Abweichende Vergleichsspiele')
            records=rec;pieces.append(item['weight']*m)
        return records,calibrate(np.sum(pieces,axis=0),bundle.get('temperature',1.))
    def match(records,matrices):
        rr=[];mm=[];qq=[]
        for r,m in zip(records.to_dict('records'),matrices):
            q=quote_map.get((r['date'],r['home'],r['away']))
            if q is None or q.get('FTHG')!=r['hg'] or q.get('FTAG')!=r['ag']:continue
            try:fair=fair_odds([q['AvgH'],q['AvgD'],q['AvgA']])
            except ValueError:continue
            rr.append(r);mm.append(m);qq.append(fair)
        return pd.DataFrame(rr),np.asarray(mm),np.asarray(qq)
    records,matrices=matrices_for([2021,2022,2023,2024]);records,matrices,qs=match(records,matrices)
    if len(records)<900:raise ValueError('Zu wenige passende historische Quoten')
    ages=(pd.to_datetime(records.date).max()-pd.to_datetime(records.date)).dt.days.to_numpy()
    recency=np.exp(-np.log(2)*ages/365.)
    def logloss(p):return -np.log(np.maximum(p[np.arange(len(records)),records.hg,records.ag],1e-12))
    def uncertainty(delta):
        # Cluster by forecast week, not by individual correlated match.
        df=pd.DataFrame({'week':pd.to_datetime(records.date).dt.to_period('W-THU'),'d':delta,'w':recency})
        blocks=np.array([np.average(g.d,weights=g.w) for _,g in df.groupby('week')])
        bw=np.array([g.w.sum() for _,g in df.groupby('week')]);mean=np.average(blocks,weights=bw)
        neff=bw.sum()**2/np.square(bw).sum()
        return float(np.sqrt(np.average((blocks-mean)**2,weights=bw)/max(neff-1,1)))
    base=logloss(matrices);trials=[]
    for w in WEIGHTS:
        mixed=np.asarray([correct(m,q,w) for m,q in zip(matrices,qs)])
        loss=logloss(mixed);delta=loss-base
        trials.append({'weight':w,'weighted_log_loss':float(np.average(loss,weights=recency)),
            'delta':float(np.average(delta,weights=recency)),'cluster_se':uncertainty(delta),
            'points_per_game':float(scored(records,mixed).points.mean())})
    best=min(trials,key=lambda t:t['weighted_log_loss'])
    eligible=[t for t in trials if t['weight']>0 and t['delta'] < -t['cluster_se'] and t['weighted_log_loss']<=best['weighted_log_loss']+max(best['cluster_se'],1e-12)]
    chosen=min(eligible,key=lambda t:t['weight']) if eligible else trials[0]
    weight=chosen['weight'] # Freeze before loading/scoring the separate test season.
    test,tm=matrices_for([2025]);test,tm,tq=match(test,tm)
    if len(test)<250:raise ValueError('Zu wenige separate Quoten-Testspiele')
    mixed=np.asarray([correct(m,q,weight) for m,q in zip(tm,tq)])
    from engine import metric
    report={'signature':key,'weight':weight,'maximum_weight':.3,'validation_games':len(records),'test_games':len(test),
        'validation_recency_half_life':365,'selection':'smallest weight within one clustered SE of best, with >1 SE improvement vs 0; validation 2021–2024 only',
        'trials':trials,'test_model':metric(scored(test,tm)),'test_market':metric(scored(test,mixed)),
        'timing_limit':'Historical non-closing odds have no verified publication timestamp. These results assume odds availability and do not validate Tuesday forecasts.',
        'source':'https://www.football-data.co.uk/notes.txt'}
    atomic_json(target,report);return report

def live_quotes(fixtures,now,outdir):
    from leanflow import atomic_json
    now=pd.Timestamp(now);status={'source':SOURCE,'fetched_at':now.isoformat(),'matched':0,'available':False}
    try:
        r=requests.get(SOURCE,timeout=(5,15),headers={'User-Agent':'Kicktipp-local/3'});r.raise_for_status()
        d=read_csv(r.content);lookup={}
        for _,row in d.iterrows():
            try:
                kickoff=pd.Timestamp(str(row.date)+' '+str(row.get('Time',''))).tz_localize('Europe/London').tz_convert('UTC')
                fair=fair_odds([row.AvgH,row.AvgD,row.AvgA])
                key=(row.date,row.home,row.away)
                if kickoff<=now.tz_convert('UTC') or key in lookup:continue
                lookup[key]={'probabilities':fair.tolist(),'kickoff':kickoff.isoformat()}
            except (ValueError,TypeError):continue
        matched={}
        for f in fixtures:
            key=(f['date'],f['home'],f['away']);q=lookup.get(key)
            if q and abs((pd.Timestamp(q['kickoff'])-pd.Timestamp(f['kickoff'])).total_seconds())<=900:
                matched[(f['home'],f['away'])]=q
        status.update(matched=len(matched),available=bool(matched),reason='Passende vor Anpfiff abgerufene Durchschnittsquoten.' if matched else 'Aktuelle Quotendatei enthält keine passenden Bundesliga-Paarungen. Marktgewicht für diese Spiele: 0 %.')
        # Immutable fetched snapshot provides real timing provenance for future tests.
        atomic_json(Path(outdir)/'market_snapshots'/f"quotes_{now.strftime('%Y%m%d_%H%M%S_%f')}.json",{'status':status,'quotes':[{'home':h,'away':a,**q} for (h,a),q in matched.items()]})
        return matched,status
    except (requests.RequestException,ValueError,KeyError,TypeError) as exc:
        status['reason']='Quotenquelle nicht erreichbar oder ungültig. Es wird nur das Ergebnismodell verwendet.'
        return {},status

def apply_market(prediction,quote,weight,status):
    p=dict(prediction);matrix=prediction_matrix(p)
    applied=weight if quote else 0.
    if quote and applied:
        matrix=correct(matrix,quote['probabilities'],applied)
        p.update(optimal_from_matrix(matrix));p['probability_matrix']=matrix.tolist()
        p['lambda_home']=float(np.dot(np.arange(len(matrix)),matrix.sum(axis=1)))
        p['lambda_away']=float(np.dot(np.arange(len(matrix)),matrix.sum(axis=0)))
    p['market']={'weight':applied,'model_weight':1-applied,'probabilities':quote['probabilities'] if quote else None,'fetched_at':status['fetched_at'],'source':status['source']}
    return p
