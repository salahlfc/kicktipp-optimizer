"""Monochrome surfaces; colors are reserved for traffic-light signals."""
DARK='--kt-bg:#000000;--kt-fg:#ffffff;--kt-card:#111111;--kt-border:#303030;--kt-muted:#aaaaaa;'
LIGHT='--kt-bg:#ffffff;--kt-fg:#000000;--kt-card:#f5f5f5;--kt-border:#dddddd;--kt-muted:#555555;'

def theme_css(mode='System'):
    palette=LIGHT if mode=='Hell' else DARK
    auto='@media(prefers-color-scheme:light){:root{'+LIGHT+'}}' if mode=='System' else ''
    return '<style>:root{'+palette+'}'+auto+'''
.stApp,.stMain,header[data-testid="stHeader"]{background:var(--kt-bg)!important;color:var(--kt-fg)!important}
.stApp h1,.stApp h2,.stApp h3,.stApp [data-testid="stMarkdownContainer"],.stApp label,.stApp [role="radiogroup"]{color:var(--kt-fg)!important}
.stApp [data-testid="stCaptionContainer"]{color:var(--kt-muted)!important}
.stApp [data-baseweb="select"]>div,.stApp [data-testid="stExpander"],.stApp [data-testid="stMetric"],.stApp [data-testid="stAlert"]{background:var(--kt-card)!important;color:var(--kt-fg)!important;border-color:var(--kt-border)!important}
.stApp [data-baseweb="select"] input,.stApp [data-baseweb="select"] span{color:var(--kt-fg)!important}
[data-testid="stAlertContainer"]{background:var(--kt-card)!important;color:var(--kt-fg)!important}
.stApp [data-testid="stMetricValue"],.stApp [data-testid="stMetricLabel"]{color:var(--kt-fg)!important}
.stButton>button[kind="primary"]{background:var(--kt-fg)!important;color:var(--kt-bg)!important;border:1px solid var(--kt-border)!important}
.stButton>button[kind="primary"] *{color:var(--kt-bg)!important}
.data-table{overflow-x:auto;margin:12px 0;border:1px solid var(--kt-border);border-radius:12px}
.data-table table{width:100%;border-collapse:collapse;background:var(--kt-bg);color:var(--kt-fg);font-size:.82rem}
.data-table th,.data-table td{padding:10px;text-align:left;border-bottom:1px solid var(--kt-border);white-space:nowrap}
.data-table th{background:var(--kt-card);font-weight:650}.data-table tr:last-child td{border-bottom:0}
[role="listbox"],[data-baseweb="popover"] ul{background:var(--kt-card)!important;color:var(--kt-fg)!important}
[role="option"]{color:var(--kt-fg)!important}
</style>'''
