"""Monochrome surfaces; colors are reserved for traffic-light signals."""
DARK='--kt-bg:#050505;--kt-fg:#f7f7f7;--kt-card:#111111;--kt-border:#292929;--kt-muted:#a5a5a5;--kt-soft:#191919;--kt-shadow:0 18px 50px rgba(0,0,0,.22);'
LIGHT='--kt-bg:#ffffff;--kt-fg:#090909;--kt-card:#f7f7f7;--kt-border:#e5e5e5;--kt-muted:#646464;--kt-soft:#f0f0f0;--kt-shadow:0 18px 50px rgba(0,0,0,.07);'

def theme_css(mode='System'):
    palette=LIGHT if mode=='Hell' else DARK
    auto='@media(prefers-color-scheme:light){:root{'+LIGHT+'}}' if mode=='System' else ''
    return '<style>:root{'+palette+'}'+auto+'''
.stApp,.stMain,header[data-testid="stHeader"]{background:var(--kt-bg)!important;color:var(--kt-fg)!important}
.stApp{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.block-container{padding-top:1.1rem!important}
.stApp h1,.stApp h2,.stApp h3,.stApp [data-testid="stMarkdownContainer"],.stApp label,.stApp [role="radiogroup"]{color:var(--kt-fg)!important}
.stApp h1{letter-spacing:-.055em;font-weight:780;line-height:1.02}
.stApp h2{letter-spacing:-.035em;font-weight:730}
.stApp [data-testid="stCaptionContainer"]{color:var(--kt-muted)!important}
.stApp [data-baseweb="select"]>div,.stApp [data-testid="stExpander"],.stApp [data-testid="stMetric"],.stApp [data-testid="stAlert"]{background:var(--kt-card)!important;color:var(--kt-fg)!important;border-color:var(--kt-border)!important}
.stApp [data-testid="stExpander"]{border-radius:16px;overflow:hidden;box-shadow:var(--kt-shadow)}
.stApp [data-testid="stMetric"]{border:1px solid var(--kt-border);border-radius:16px;padding:14px 16px;box-shadow:var(--kt-shadow)}
.stApp [data-baseweb="select"] input,.stApp [data-baseweb="select"] span{color:var(--kt-fg)!important}
[data-testid="stAlertContainer"]{background:var(--kt-card)!important;color:var(--kt-fg)!important}
.stApp [data-testid="stMetricValue"],.stApp [data-testid="stMetricLabel"]{color:var(--kt-fg)!important}
.stButton>button[kind="primary"]{background:var(--kt-fg)!important;color:var(--kt-bg)!important;border:1px solid var(--kt-border)!important}
.stButton>button[kind="primary"] *{color:var(--kt-bg)!important}
.stButton>button{border-radius:13px!important;transition:transform .16s ease,opacity .16s ease}
.stButton>button:hover{transform:translateY(-1px);opacity:.9}
.stRadio [role="radiogroup"]{display:flex;flex-wrap:nowrap;gap:5px;background:var(--kt-card);border:1px solid var(--kt-border);padding:5px;border-radius:16px}
.stRadio [role="radiogroup"]>label{flex:1 1 0%;min-width:0;justify-content:center;gap:6px;white-space:nowrap!important;border-radius:12px;padding:8px 10px!important;margin:0!important;transition:background .15s ease}
.stRadio [role="radiogroup"]>label p,.stRadio [role="radiogroup"]>label [data-testid="stMarkdownContainer"]{white-space:nowrap!important;overflow-wrap:normal!important;word-break:keep-all!important}
.stRadio [role="radiogroup"]>label:has(input:checked){background:var(--kt-fg);color:var(--kt-bg)!important}
.stRadio [role="radiogroup"]>label:has(input:checked) *{color:var(--kt-bg)!important}
.app-brand{display:flex;align-items:center;gap:11px;padding:11px 0 18px;border-bottom:1px solid var(--kt-border);margin-bottom:20px}
.app-brand-mark{display:grid;place-items:center;width:38px;height:38px;border:1px solid var(--kt-border);background:var(--kt-card);border-radius:13px;font-size:19px}
.app-brand b{display:block;font-size:.91rem;letter-spacing:.04em}
.app-brand small{display:block;color:var(--kt-muted);font-size:.68rem;letter-spacing:.15em;text-transform:uppercase;margin-top:2px}
.page-intro{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:-5px 0 16px;padding:13px 15px;border:1px solid var(--kt-border);border-radius:16px;background:linear-gradient(135deg,var(--kt-card),var(--kt-bg));box-shadow:var(--kt-shadow)}
.page-intro-copy{color:var(--kt-muted);font-size:.85rem;line-height:1.45}
.page-intro-chip{white-space:nowrap;border:1px solid var(--kt-border);background:var(--kt-soft);border-radius:999px;padding:7px 10px;font-size:.72rem;font-weight:700}
.total{background:linear-gradient(130deg,var(--kt-card),var(--kt-soft))!important;box-shadow:var(--kt-shadow);padding:20px!important}
.total small{font-size:.74rem;letter-spacing:.09em;text-transform:uppercase}
.total b{font-size:2.5rem!important;letter-spacing:-.06em}
.tip-card{box-shadow:var(--kt-shadow);transition:transform .15s ease,border-color .15s ease}
.tip-card:hover{transform:translateY(-2px);border-color:var(--kt-muted)}
.team-update{box-shadow:var(--kt-shadow)}
.data-table{overflow-x:auto;margin:12px 0;border:1px solid var(--kt-border);border-radius:12px}
.data-table table{width:100%;border-collapse:collapse;background:var(--kt-bg);color:var(--kt-fg);font-size:.82rem}
.data-table th,.data-table td{padding:10px;text-align:left;border-bottom:1px solid var(--kt-border);white-space:nowrap}
.data-table th{background:var(--kt-card);font-weight:650}.data-table tr:last-child td{border-bottom:0}
[role="listbox"],[data-baseweb="popover"] ul{background:var(--kt-card)!important;color:var(--kt-fg)!important}
[role="option"]{color:var(--kt-fg)!important}
@media(max-width:640px){.page-intro{align-items:flex-start;flex-direction:column}.page-intro-chip{white-space:normal}.stApp h1{font-size:1.85rem!important}.stRadio [role="radiogroup"]{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}.stRadio [role="radiogroup"]>label{width:100%;min-width:0;padding:8px 6px!important;font-size:.83rem}}
</style>'''
